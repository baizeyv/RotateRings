# Levels 备用词库

从 Assets/Levels 的所有 .level 文件解压提取 target_words 和 extra_words 的 word 字段。包括所有词类型，按完整单词去重并按字母排序；不应用自有筛选词库的复数、口语或敏感词排除规则。

文件数：3459。目标词去重数：4278。额外词去重数：2616。两者合并后：6791。

SHA-256：`1cdb4c9ec95d3a43729c9aff6c0c40989a76c2e12a9a27abc41f86194cb47a65`。

此词库来自项目现有关卡，并非 SCOWL 衍生词库；来源记录不赋予额外授权。只提取单词，不将原关卡棋盘或目标词组合当作生成模板。

在项目根目录运行 `python -X utf8 Tools/Prepare-LevelsDictionary.py` 可重新构建。读取异常或非法词条会停止构建，不静默遗漏关卡。

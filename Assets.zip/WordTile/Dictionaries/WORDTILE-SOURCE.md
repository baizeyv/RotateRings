# WordTile 自有筛选词库

基于 SCOWL 固定版本 rel-2026.02.25、size 35、美式英语、variant level 1。词库为衍生筛选版本，保留上游许可及署名；完整许可见 SCOWL-Copyright.txt。

原始词数：38602；保留：28598；删除：10004。

## 生效规则

- 名词复数：使用 SCOWL ns/nss/nsp/nssp/ms 标注，不采用以 s 结尾的猜测。只要该拼写存在复数含义就整词删除，包括 WORKS、NEWS，以及 DEER、FISH、SHEEP 等单复数同形词。普通动词时态不会单独按复数规则删除。
- 口语：整词删除带 colloquial/informal/nonstandard 标注的词，另补充规则表中的口语及俚语。
- 不当用语：整词删除任一含义带 offensive-*/vulgar-* 标注的词，另补充脏话规则表。
- 政治：按严格规则表排除制度、党派、意识形态、政务、运动、争议议题及军政地缘相关词。有普通含义的同形词也删除，例如 PARTY、STATE、CROWN、CHINA。
- 人工规则为整词精确匹配，并沿 SCOWL lemma 关系排除已记录的词形。不会用 ASS 这样的短片段匹配 CLASS 或 GRASS，也不根据拼写相似度猜测衍生词。

## 分类统计

- plural: 9450
- colloquial: 53
- profanity: 54
- political: 691

一个词可命中多种规则，分类数不能直接相加。完整删除理由见 wordtile-removed.tsv。

严格复数规则同时删除了 508 个具有名词单数或动词原形记录的同形词。

## 维护与复现

规则表：wordtile-filter-policy.json。人工分类是可审查的项目词表，不是 SCOWL 提供的政治分类；SCOWL 的口语和不当用语标注并不完整，当前规则是初版筛选，后续发现遗漏时增补精确词条后重新构建。

在项目根目录运行 `python -X utf8 Tools/Prepare-WordTileDictionary.py <SCOWL generated.db>`。数据库来自 Tools/Prepare-WordDictionary.py 使用的同一固定版本，不读取任何关卡内容。脚本包含复数、同形词、后缀误判、子串误判和词形联动的断言检查。

若 Temp 中的数据库已被清理，先获取固定版本源码，在项目根目录运行 `python -X utf8 Tools/Prepare-WordDictionary.py <源码目录>` 重新构建 generated.db，再运行自有词库构建命令。

词库 SHA-256：`2b2e53d7c202ef7b5af99b033441429183eb6358e955cc5e41447c62c7494dd1`。

规则表 SHA-256：`8a3127c7e65e72ebae1d71c7a5687be23591686fb9fa77dfed6f84f051fa7b02`。

现有词频数据覆盖 27276/28598 个保留词；其余沿用难度分析器的未知词频处理。

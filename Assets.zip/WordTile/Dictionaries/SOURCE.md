# English word dictionary

Source: https://github.com/en-wl/wordlist/tree/rel-2026.02.25

Pinned release: `rel-2026.02.25`. Size 35, American spelling A, variant level 1.

Prepared using upstream libscowl, excluding special categories, abbreviations, proper-name classes, and marked offensive/vulgar/nonstandard usage. Only lowercase ASCII source entries are retained, then uppercased, deduplicated and sorted. This is a spelling dictionary, not a guarantee of familiarity or suitability for every audience; the generator accepts an exclusion list.

Entries: 38602. SHA-256: `251f71b011207b56db067bd6c43f7bea8906520d82532236fa6c5151d8171156`.

The complete upstream license and source notices are in SCOWL-Copyright.txt.

Reproduce: download and extract the pinned source archive, then run `python -X utf8 Tools/Prepare-WordDictionary.py <extracted-source-directory>`. The script builds generated.db when absent. Generation in Unity is completely offline.

Upstream command:

```text
python -X utf8 -m libscowl word-list --db generated.db 35 A 1 --categories= --wo-poses=abbr,x,pre,suf,wp,we --wo-pos-classes=person,surname,place,name,demonym,trademark,upper,name?,upper?,abbr,abbr? --wo-usage-notes=offensive-1,offensive-2,vulgar-1,vulgar-2,vulgar-3,nonstandard
```

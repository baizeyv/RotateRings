# Difficulty word-frequency lookup

Pinned package: wordfreq 3.1.1, English large. Author: Robyn Speer.

Data: CC BY-SA 4.0, https://creativecommons.org/licenses/by-sa/4.0/. The derived JSON retains its attribution, upstream source notices and license inside the asset. Preserve those fields when redistributing this asset. Original upstream code notice is included separately.

This is a C# lookup port for single ASCII words, built from the original frequency bins. Changes: intersect with the bundled SCOWL dictionary, uppercase keys, store Zipf = 9 - binIndex/100. Missing words remain unknown. No runtime Python or packages are needed.

Entries: 37001. Asset SHA-256: `e7da4698aa1fe1e0f64377387b3cca0f62ff7b3f8454c74803306dd25c07ff0f`. Original wheel SHA-256: `4b1c6ecffc6198be3396d5cf871c4423ca71c907c231348d352dd54d62b97473`.

Rebuild: download wordfreq==3.1.1 and msgpack==1.1.2 wheels into Temp/frequency-download, then run `python -X utf8 Tools/Prepare-WordFrequency.py`.

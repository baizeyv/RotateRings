# NeoRing

## Unity Editor 编辑

通过 **Tools → NeoRing → 打开关卡编辑器** 打开窗口，在隔离的 Scene 预览里编辑，不需要点击 Play，不修改当前场景中的对象。

- 选择元素，拖动位置手柄；黄色旋转圈调整角度。
- 环：拖半径和线宽；C 环另有开口起点/终点。
- 门：拖宽、线宽，左右竖段底端的手柄分别调整各自高度。7：拖宽、高及线宽。Z：拖上段长、下段长、高和线宽。直线：拖长度和线宽。
- 属性面板也支持数值输入：位置、旋转、缩放、形状尺寸，以及连接杆、连接头和炸弹参数。输入后按 Enter 或离开输入框提交，支持撤销；连接件参数变动沿用关联对象跟随逻辑。
- Scene 画布默认显示 1080×1920 竖屏边框，中心为世界原点，按生成的游玩相机尺寸映射。点击「聚焦竖屏范围」查看整体；边框只供摆放参考，不限制元件移动。
- 卡扣：拖长度、外宽、净通道；旋转圈调整方向。
- 连接件：选择连接件后，红点拖杆根，绿点拖头中心（杆长/方向）；旋转圈围绕杆根调整角度。拖杆宽、头长、头宽、净通道手柄；按钮切换向内/向外、到中心、仅杆/带头。
- 炸弹：拖位置、碰撞半径和图片尺寸。
- Ctrl 拖位置：固定本次关联组一起移动。Alt 暂时关闭吸附。Ctrl+Z 撤销，Ctrl+Shift+Z 重做。右键拖画布，滚轮缩放；窗口“聚焦”放大选中对象。另有整体缩放、游玩移动轴手柄。

环和 C 环只吸附连接头，不吸附卡扣；C 环缺口不参与吸附。连接头修改后穿入对象及关联组一起平移/旋转；相互冲突的多头约束会拒绝修改。元件尺寸不能小于几何最小值，进入试玩前校验布局。

编辑窗口支持打开/保存 JSON、复制、自定义元件库和无需 Play 的预览试玩。鼠标操作按一次手势记录撤销。关闭窗口保留编辑草稿；保存 JSON 才写入关卡文件。

自定义库位于 `Assets/NeoRing/Libraries/CustomElements.json`，首次打开自动迁移原 `Application.persistentDataPath/NeoRing/custom-elements.json`（若新库尚不存在）。实例是独立副本，包括连接件、炸弹和图片 ID。

图片卡扣示例入口：**Tools → NeoRing → 打开图片卡扣示例**。原图 `Assets/catch.png` 横向穿杆，Sprite ID 为 `catch`。

## 独立运行时

编辑代码全部位于 `Editor`，不会进入 Player 程序集。`Runtime` 保留数据、生成几何、碰撞、连接关系、显示和 `NeoLevelPlayer` 游玩控制器。

在编辑窗口保存关卡到项目 Assets 内，然后选择“创建独立游玩场景”。生成场景仅含相机、NeoLevelView 和 NeoLevelPlayer。NeoLevelPlayer.Level 引用关卡 TextAsset，NeoLevelView 配置图片/材质 ID 注册表；默认注册 catch。关卡保存几何参数，不保存 Mesh 资源。

每关只在窗口「关卡共享材质」选择一次材质；留空使用默认 NeoRing/AtlasLit，模板为 Runtime/Resources/NeoRingAtlas.mat。关卡 JSON 的顶层 MaterialId 保存材质 GUID，生成游玩场景自动带上对应引用。旧元件的 MaterialId 不再参与材质选择。自定义加载器可用 NeoLevelView.Materials 注册关卡 ID，或用 SharedShapeMaterial 指定整关材质；Resources 中的材质也可用资源路径作为关卡 ID。

相同局部实体几何与 UV 布局、精度共享一个程序化 Mesh，位置、旋转、缩放、颜色、炸弹参数不会导致 Mesh 复制。缓存按引用计数释放，修改尺寸只让该元件取得对应的新 Mesh；最后一个使用者释放时销毁。运行时 Mesh 上传 GPU 后释放 CPU 顶点副本，编辑预览保留可读数据。卡扣使用矩形 Mesh 显示图集右侧卡扣，碰撞仍使用两条轨道与开放通道。指定旧图片 ID 时显示对应图片。炸弹使用 SpriteRenderer，不生成额外程序化 Mesh。

默认材质固定绑定 NeoRingAtlasColor、NeoRingAtlasNormal、NeoRingAtlasSdf 三张 1024×128 图集。主体／杆采样左区，连接头采样中区，卡扣采样右区。UV0 是图集坐标；UV1 保留局部 XY 给旧图片映射，Mesh 带背向 Z 的法线及沿路径的切线。环/C 环用连续带状网格，C 环只在两端生成圆帽，不为每个碰撞段重复生成胶囊。三张图均禁用 mipmap，SDF 保留线性 Alpha 数据，不参与颜色空间转换。

门、7、Z 和直线同样使用连续条带；转角内外侧均为圆弧，内侧圆角默认半径为线宽的四分之一，短段自动缩小圆角。两侧切线连续，内部不使用端帽贴图。连接杆位于主体后方 0.001 局部单位，主体遮住方形杆根；仅杆模式的端帽沿杆方向映射，不再叠加独立圆形贴图。显示修正不改变数值碰撞结构；内侧圆角的细小填充不加入碰撞轮廓。

AtlasLit 是 URP 单 Pass 固定方向法线光照，不接入额外灯光、实时阴影或额外阴影 Pass。材质可调整 Normal strength、Ambient、Light strength、Light direction、Body brightness、Global tint 和 SDF edges。连接头显示完整色块，通道碰撞仍开放；卡扣默认银灰色，可用 Clasp tint 改统一颜色，或将 Use element color on clasp 调到 1 使用元件颜色。生成游玩场景采用参考图的浅米色背景。默认启用 SDF Alpha 轮廓裁切；没有轮廓外阴影或半透明混合。游玩移动只同步 Transform，没有 Mesh/UV 更新和纹理重绑。

Mesh 的 COLOR 通道为白色底色，Shader 将顶点色乘以每个实例的 _InstanceColor 和材质 _Color。独立元件颜色不能直接烘焙到同一份共享 Mesh 中；实例颜色可以避免因颜色不同复制 Mesh。默认材质开启 GPU Instancing，Shader 有实例变体。自定义 Shader 也需声明 _InstanceColor 为实例属性、读取 COLOR 通道，并在材质开启 GPU Instancing。相同 Mesh/材质且渲染条件一致的一组可实例合批，不保证整关一个 Draw Call；不同 Mesh、排序、纹理或其他渲染通道会拆批。图片覆盖通过 _MainTex 和 _MainTex_ST 属性块设置，会拆批；炸弹使用独立 SpriteRenderer 材质。

运行时左键拖动：旋转元素绕自身中心转动，滑动元素沿 MovementAxis 移动；固定或被连接头锁定的元素不移动。松开后隐藏本次操作涉及且已无连接的元素及空卡扣，隐藏对象不再参与碰撞/拾取。初始不自动隐藏无关元素。炸弹接触消除双方。

`NeoWorld.Collided` 提供碰撞双方索引/ID、碰撞件和局部 XY 接触点；NeoLevelView 在 Console 输出名称和世界坐标。接触点使用碰撞内核的表面估计。同一接触点持续受阻不重复输出，分离重碰会重新输出。自定义控制器配对调用 BeginOperation / ReleaseOperation。

## 验证

`python Assets/NeoRing/Tests/Prepare-Check.py` 建立隔离 Unity 项目。使用 Unity 的 `-projectPath Temp/NeoRingCheck -executeMethod NeoRingChecks.Run` 执行。检查覆盖核心几何/碰撞/JSON、连接跟随、吸附、库、隐藏与碰撞事件；原生 Editor 检查鼠标拖动门形尺寸及手势撤销，还验证右键画布平移不改关卡参数，之后验证独立运行时加载和渲染。

Shader "NeoRing/AtlasLit"
{
    Properties
    {
        _MainTex ("Surface atlas", 2D) = "white" {}
        [Normal] _NormalMap ("Normal atlas", 2D) = "bump" {}
        _SDFTex ("Distance atlas (Alpha)", 2D) = "white" {}
        _Color ("Global tint", Color) = (1,1,1,1)
        _SurfaceGain ("Body brightness", Range(0,3)) = 1.7
        _ClaspTint ("Clasp tint", Color) = (1,1,1,1)
        _ClaspColorBlend ("Use element color on clasp", Range(0,1)) = 0
        _NormalStrength ("Normal strength", Range(0,2)) = 1
        _Ambient ("Ambient", Range(0,1)) = 0.65
        _LightStrength ("Light strength", Range(0,2)) = 0.45
        _LightDirection ("Light direction (world)", Vector) = (-0.3,0.566,-0.767,0)
        [Toggle] _UseSDF ("SDF edges", Float) = 1
        _SDFThreshold ("SDF threshold", Range(0,1)) = 0.49
        [HideInInspector] _InstanceColor ("Instance color", Color) = (1,1,1,1)
        [HideInInspector] _UseCustomTexture ("Custom image", Float) = 0
    }
    SubShader
    {
        Tags { "RenderPipeline"="UniversalPipeline" "Queue"="AlphaTest" "RenderType"="TransparentCutout" }
        Pass
        {
            Tags { "LightMode"="SRPDefaultUnlit" }
            Cull Off ZWrite On
            HLSLPROGRAM
            #pragma target 3.5
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_instancing
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            TEXTURE2D(_MainTex); SAMPLER(sampler_MainTex);
            TEXTURE2D(_NormalMap); SAMPLER(sampler_NormalMap);
            TEXTURE2D(_SDFTex); SAMPLER(sampler_SDFTex);
            // Deliberately outside UnityPerMaterial: use ordinary GPU instancing, not SRP Batcher.
            float4 _MainTex_ST, _Color, _LightDirection, _ClaspTint;
            float _NormalStrength, _Ambient, _LightStrength, _UseSDF, _SDFThreshold, _SurfaceGain, _ClaspColorBlend;
            UNITY_INSTANCING_BUFFER_START(Props)
                UNITY_DEFINE_INSTANCED_PROP(float4, _InstanceColor)
                UNITY_DEFINE_INSTANCED_PROP(float, _UseCustomTexture)
            UNITY_INSTANCING_BUFFER_END(Props)
            struct Attributes
            {
                float4 positionOS : POSITION;
                float3 normalOS : NORMAL;
                float4 tangentOS : TANGENT;
                float2 atlasUV : TEXCOORD0;
                float2 localUV : TEXCOORD1;
                half4 color : COLOR;
                UNITY_VERTEX_INPUT_INSTANCE_ID
            };
            struct Varyings
            {
                float4 positionCS : SV_POSITION;
                float2 uv : TEXCOORD0;
                half3 tangentWS : TEXCOORD1;
                half3 bitangentWS : TEXCOORD2;
                half3 normalWS : TEXCOORD3;
                half4 color : COLOR;
                nointerpolation float customImage : TEXCOORD4;
            };
            Varyings vert(Attributes v)
            {
                UNITY_SETUP_INSTANCE_ID(v);
                Varyings o;
                o.positionCS = TransformObjectToHClip(v.positionOS.xyz);
                o.customImage = UNITY_ACCESS_INSTANCED_PROP(Props, _UseCustomTexture);
                o.uv = o.customImage > 0.5 ? v.localUV * _MainTex_ST.xy + _MainTex_ST.zw : v.atlasUV;
                o.normalWS = TransformObjectToWorldNormal(v.normalOS);
                o.tangentWS = TransformObjectToWorldDir(v.tangentOS.xyz);
                o.bitangentWS = cross(o.normalWS, o.tangentWS) * v.tangentOS.w * GetOddNegativeScale();
                o.color = v.color * UNITY_ACCESS_INSTANCED_PROP(Props, _InstanceColor) * _Color;
                if (o.customImage < 0.5 && v.atlasUV.x > 0.75)
                    o.color.rgb = lerp(v.color.rgb * _ClaspTint.rgb * _Color.rgb, o.color.rgb, _ClaspColorBlend);
                return o;
            }
            half4 frag(Varyings v) : SV_Target
            {
                half4 surface = SAMPLE_TEXTURE2D(_MainTex, sampler_MainTex, v.uv);
                if (v.customImage > 0.5) { clip(surface.a * v.color.a - 0.01); return half4(surface.rgb * v.color.rgb, 1); }
                if (_UseSDF > 0.5)
                {
                    half distance = SAMPLE_TEXTURE2D(_SDFTex, sampler_SDFTex, v.uv).a;
                    // Single opaque cutout pass; derivatives keep the threshold stable at small scales.
                    clip(distance - _SDFThreshold + min(fwidth(distance) * 0.5, 0.02));
                }
                else clip(surface.a - 0.25);
                clip(v.color.a - 0.01);
                half3 normalTS = UnpackNormalScale(SAMPLE_TEXTURE2D(_NormalMap, sampler_NormalMap, v.uv), _NormalStrength);
                half3 n = normalize(normalTS.x * v.tangentWS + normalTS.y * v.bitangentWS + normalTS.z * v.normalWS);
                half lighting = _Ambient + _LightStrength * saturate(dot(n, normalize(_LightDirection.xyz)));
                half gain = v.uv.x > 0.75 ? 1 : _SurfaceGain;
                return half4(surface.rgb * v.color.rgb * lighting * gain, 1);
            }
            ENDHLSL
        }
    }
}

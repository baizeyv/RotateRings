Shader "NeoRing/Unlit"
{
    Properties { _Color ("Color", Color) = (1,1,1,1) _MainTex ("Texture", 2D) = "white" {} [HideInInspector] _InstanceColor ("Instance color", Color) = (1,1,1,1) }
    SubShader
    {
        Tags { "Queue"="Geometry" "RenderType"="Opaque" }
        Pass
        {
            Tags { "LightMode"="SRPDefaultUnlit" }
            Cull Off ZWrite On
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_instancing
            #include "UnityCG.cginc"
            struct Input { float4 vertex : POSITION; float2 uv : TEXCOORD1; fixed4 color : COLOR; UNITY_VERTEX_INPUT_INSTANCE_ID };
            struct Output { float4 vertex : SV_POSITION; float2 uv : TEXCOORD0; fixed4 color : COLOR; };
            sampler2D _MainTex; float4 _MainTex_ST; fixed4 _Color;
            UNITY_INSTANCING_BUFFER_START(Props)
                UNITY_DEFINE_INSTANCED_PROP(float4, _InstanceColor)
            UNITY_INSTANCING_BUFFER_END(Props)
            Output vert(Input v)
            {
                UNITY_SETUP_INSTANCE_ID(v);
                Output o; o.vertex = UnityObjectToClipPos(v.vertex); o.uv = TRANSFORM_TEX(v.uv, _MainTex);
                o.color = v.color * UNITY_ACCESS_INSTANCED_PROP(Props, _InstanceColor); return o;
            }
            fixed4 frag(Output v) : SV_Target { fixed4 c = tex2D(_MainTex, v.uv) * v.color * _Color; clip(c.a - .01); c.a = 1; return c; }
            ENDCG
        }
    }
}

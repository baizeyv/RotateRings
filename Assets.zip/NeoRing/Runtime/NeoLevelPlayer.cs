using UnityEngine;

namespace WordTile.NeoRing
{
    /// <summary>Standalone gameplay input. Contains no authoring or UnityEditor dependency.</summary>
    [RequireComponent(typeof(NeoLevelView))]
    public sealed class NeoLevelPlayer : MonoBehaviour
    {
        public TextAsset Level;
        public Camera Camera;
        private NeoLevelView view;
        private int selected = -1;
        private Vector2 last;
        private void Start()
        {
            view = GetComponent<NeoLevelView>();
            if (Camera == null) Camera = UnityEngine.Camera.main;
            if (Level != null) view.Load(NeoLevelData.FromJson(Level.text));
            if (view.World != null) view.World.ResolveInitialBombContacts();
        }
        private Vector2 Pointer()
        {
            Ray ray = Camera.ScreenPointToRay(Input.mousePosition);
            var plane = new Plane(transform.forward, transform.position);
            float distance;
            return plane.Raycast(ray, out distance) ? (Vector2)transform.InverseTransformPoint(ray.GetPoint(distance)) : last;
        }
        private void Update()
        {
            if (view.World == null || Camera == null) return;
            Vector2 point = Pointer();
            if (Input.GetMouseButtonDown(0))
            { selected = view.World.Pick(point); last = point; if (selected >= 0) view.World.BeginOperation(selected); }
            if (selected >= 0 && Input.GetMouseButton(0))
            {
                var body = view.World.Bodies[selected];
                Vector2 before = last - body.Data.Position, after = point - body.Data.Position;
                float angle = before.sqrMagnitude < .0001f || after.sqrMagnitude < .0001f ? 0 : Vector2.SignedAngle(before, after);
                view.World.Move(selected, point - last, angle); view.SyncPose(selected); last = point;
                if (!body.Active) selected = -1;
            }
            if (Input.GetMouseButtonUp(0) && selected >= 0)
            { view.World.ReleaseOperation(selected); selected = -1; }
        }
        private void OnDisable()
        { if (selected >= 0 && view != null && view.World != null) view.World.ReleaseOperation(selected); selected = -1; }
    }
}

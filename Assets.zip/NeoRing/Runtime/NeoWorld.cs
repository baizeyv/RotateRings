using System;
using System.Collections.Generic;
using UnityEngine;
using C = WordTile.Game.GameCollision2D;
using K = WordTile.Game.GameCollisionKind;

namespace WordTile.NeoRing
{
    public struct NeoCollision
    {
        public int FirstIndex, SecondIndex, FirstId, SecondId, FirstPart, SecondPart;
        public Vector2 Point;
    }
    public struct NeoExplosion
    {
        public int OwnerId, BombId, OtherId, OtherBombId;
        public Vector2 Point;
    }
    /// <summary>Owns generated geometry and caches. Translation reuses the tested numeric collision kernel.</summary>
    public sealed class NeoWorld : IDisposable
    {
        public sealed class Body
        {
            public NeoElement Data;
            public NeoGeometry Geometry;
            public C.Part[] World, Channels;
            public C.Bounds Bounds;
            public int LockCount;
            public bool Active { get; internal set; } = true;
            public bool[] BombSpent { get; private set; }
            public bool Locked { get { return LockCount > 0; } }
            internal Body(NeoElement data)
            {
                Data = data; Geometry = NeoGeometry.Build(data);
                BombSpent = new bool[data.Bombs.Length];
                World = new C.Part[Geometry.Parts.Length]; Channels = new C.Part[Geometry.Channels.Length];
                Sync();
            }
            internal void Fill(C.Part[] destination, Vector2 position, float angle)
            {
                double a = angle * Math.PI / 180;
                for (int i = 0; i < destination.Length; i++) destination[i] = C.Transform(Geometry.Parts[i], position.x, position.y, Math.Cos(a), Math.Sin(a), Data.Scale);
            }
            internal void Sync()
            {
                Fill(World, Data.Position, Data.Angle); Bounds = World[0].Bounds;
                for (int i = 1; i < World.Length; i++) Bounds.Include(World[i].Bounds);
                double a = Data.Angle * Math.PI / 180;
                for (int i = 0; i < Channels.Length; i++) Channels[i] = C.Transform(Geometry.Channels[i], Data.Position.x, Data.Position.y, Math.Cos(a), Math.Sin(a), Data.Scale);
            }
        }

        public NeoLevelData Data { get; private set; }
        public Body[] Bodies { get; private set; }
        public int LastPairChecks { get; private set; }
        public int LastSweepIterations { get; private set; }
        public int LastObstacleId { get; private set; }
        public event Action<NeoExplosion> Exploded;
        public event Action<NeoCollision> Collided;
        public event Action VisibilityChanged;
        private bool[] releaseCandidates;
        private int operatedIndex = -1;
        private int reportedFirst = -1, reportedSecond = -1;
        private Vector2 reportedPoint;
        private bool[,] occupied;
        public const double OccupancyTolerance = 0.00001;

        public NeoWorld(NeoLevelData source)
        {
            Data = source.Clone(); Bodies = new Body[Data.Elements.Length]; releaseCandidates = new bool[Bodies.Length];
            try
            {
                for (int i = 0; i < Bodies.Length; i++) Bodies[i] = new Body(Data.Elements[i]);
                occupied = new bool[Bodies.Length, Bodies.Length]; RebuildRelations();
            }
            catch { Dispose(); throw; }
        }
        public void Dispose()
        {
            if (Bodies == null) return;
            foreach (var b in Bodies) if (b != null) b.Geometry.ReleaseMesh();
            Bodies = Array.Empty<Body>();
            Exploded = null;
            Collided = null; VisibilityChanged = null;
        }
        public static void Release(UnityEngine.Object o)
        { if (Application.isPlaying) UnityEngine.Object.Destroy(o); else UnityEngine.Object.DestroyImmediate(o); }

        public void ReplaceElement(int index, NeoElement element)
        {
            if (element.Id != Data.Elements[index].Id) throw new ArgumentException("Replacing dimensions cannot change element ID.");
            var copy = JsonUtility.FromJson<NeoElement>(JsonUtility.ToJson(element));
            var replacement = new Body(copy); var previous = Bodies[index];
            Bodies[index] = replacement; Data.Elements[index] = copy;
            // Recompute counts because replacing an owner resets its lock counter.
            RebuildRelations(); previous.Geometry.ReleaseMesh();
        }
        public void SetPose(int index, Vector2 position, float angle)
        {
            NeoLevelData.Finite(position.x); NeoLevelData.Finite(position.y); NeoLevelData.Finite(angle);
            if (Mathf.Abs(position.x) > 10000 || Mathf.Abs(position.y) > 10000) throw new ArgumentException("Coordinates exceed 10000 units.");
            var b = Bodies[index]; b.Data.Position = position; b.Data.Angle = Mathf.Repeat(angle + 180, 360) - 180; b.Sync(); UpdateRelations(index);
        }
        /// <summary>Undirected transitive occupancy dependencies, including occupied clasps.</summary>
        public int[] GetDependencyGroup(int index)
        {
            if (index < 0 || index >= Bodies.Length) throw new ArgumentException("Invalid selected element index.");
            if (!Bodies[index].Active) return Array.Empty<int>();
            var visited = new bool[Bodies.Length]; var members = new List<int> { index }; visited[index] = true;
            for (int next = 0; next < members.Count; next++)
            {
                int current = members[next];
                for (int other = 0; other < Bodies.Length; other++)
                    if (!visited[other] && Bodies[other].Active && (occupied[current, other] || occupied[other, current]))
                    { visited[other] = true; members.Add(other); }
            }
            return members.ToArray();
        }
        /// <summary>Authoring translation: validate the complete edit before changing any member.</summary>
        public void TranslateGroup(int[] members, Vector2 delta)
        {
            if (members == null || members.Length > Bodies.Length) throw new ArgumentException("Invalid translation group.");
            NeoLevelData.Finite(delta.x); NeoLevelData.Finite(delta.y);
            for (int i = 0; i < members.Length; i++)
            {
                int index = members[i];
                if (index < 0 || index >= Bodies.Length || !Bodies[index].Active) throw new ArgumentException("Translation group contains an invalid or inactive element.");
                for (int j = 0; j < i; j++) if (members[j] == index) throw new ArgumentException("Translation group contains duplicate elements.");
                Vector2 position = Bodies[index].Data.Position + delta;
                NeoLevelData.Finite(position.x); NeoLevelData.Finite(position.y);
                if (Mathf.Abs(position.x) > 10000 || Mathf.Abs(position.y) > 10000) throw new ArgumentException("Coordinates exceed 10000 units.");
            }
            for (int i = 0; i < members.Length; i++)
            { var body = Bodies[members[i]]; body.Data.Position += delta; body.Sync(); }
            // All geometries have their final poses before evaluating any relation.
            for (int i = 0; i < members.Length; i++) UpdateRelations(members[i]);
        }
        public void RebuildRelations()
        {
            Array.Clear(occupied, 0, occupied.Length);
            for (int i = 0; i < Bodies.Length; i++) Bodies[i].LockCount = 0;
            for (int i = 0; i < Bodies.Length; i++) for (int j = 0; j < Bodies.Length; j++) if (i != j) EvaluateRelation(i, j);
        }
        private void UpdateRelations(int index)
        {
            // ponytail: ~100 elements; update one row and column rather than adding a spatial index.
            for (int j = 0; j < Bodies.Length; j++) if (j != index) { EvaluateRelation(index, j); EvaluateRelation(j, index); }
        }
        private void EvaluateRelation(int owner, int other)
        {
            bool value = false; var a = Bodies[owner]; var b = Bodies[other];
            if (a.Active && b.Active && b.Data.Kind != NeoShapeKind.Clasp)
                for (int h = 0; h < a.Channels.Length && !value; h++)
                    for (int k = 0; k < b.Geometry.BodyCount; k++)
                        if (a.Channels[h].Bounds.Overlaps(b.World[k].Bounds) && C.Clearance(a.Channels[h], b.World[k]) < -OccupancyTolerance) { value = true; break; }
            if (occupied[owner, other] == value) return;
            occupied[owner, other] = value;
            if (a.Data.Kind != NeoShapeKind.Clasp) a.LockCount += value ? 1 : -1;
        }
        public bool ChannelOccupied(int owner, int other) { return occupied[owner, other]; }
        private void MarkReleaseNeighbors(int index)
        {
            releaseCandidates[index] = true;
            for (int other = 0; other < Bodies.Length; other++)
                if (occupied[index, other] || occupied[other, index]) releaseCandidates[other] = true;
        }
        public void BeginOperation(int index)
        {
            if (index < 0 || index >= Bodies.Length) throw new ArgumentException("Invalid operated element.");
            Array.Clear(releaseCandidates, 0, releaseCandidates.Length);
            operatedIndex = index; MarkReleaseNeighbors(index);
            reportedFirst = reportedSecond = -1;
        }
        public int ReleaseOperation(int index)
        {
            if (operatedIndex != index) BeginOperation(index);
            MarkReleaseNeighbors(index); operatedIndex = -1; int hidden = 0;
            bool changed;
            do
            {
                changed = false;
                for (int i = 0; i < Bodies.Length; i++)
                {
                    if (!releaseCandidates[i] || !Bodies[i].Active) continue;
                    bool dependent = false;
                    for (int other = 0; other < Bodies.Length; other++)
                        if (occupied[i, other] || occupied[other, i]) { dependent = true; break; }
                    if (dependent) continue;
                    Bodies[i].Active = false; UpdateRelations(i); hidden++; changed = true;
                }
            } while (changed);
            if (hidden > 0 && VisibilityChanged != null)
                foreach (Action handler in VisibilityChanged.GetInvocationList())
                    try { handler(); } catch (Exception ex) { Debug.LogException(ex); }
            return hidden;
        }
        public bool HeadOccupied(int owner, int head)
        {
            var indices = Bodies[owner].Geometry.ChannelConnectionIndices;
            for (int i = 0; i < indices.Length; i++) if (indices[i] == head) return IsChannelOccupied(owner, i);
            return false;
        }
        public bool IsChannelOccupied(int owner, int channel)
        {
            var a = Bodies[owner];
            for (int j = 0; j < Bodies.Length; j++) if (j != owner && occupied[owner, j])
                for (int k = 0; k < Bodies[j].Geometry.BodyCount; k++)
                    if (a.Channels[channel].Bounds.Overlaps(Bodies[j].World[k].Bounds) && C.Clearance(a.Channels[channel], Bodies[j].World[k]) < -OccupancyTolerance) return true;
            return false;
        }

        public int Pick(Vector2 point, float padding = 0.05f)
        {
            var probe = new C.Part { Kind = K.Capsule, A = new C.Point(point.x, point.y), B = new C.Point(point.x, point.y) }; probe.UpdateBounds();
            int result = -1;
            for (int i = 0; i < Bodies.Length; i++)
            {
                var b = Bodies[i]; if (!b.Active || (result >= 0 && b.Data.SortingOrder < Bodies[result].Data.SortingOrder)) continue;
                if (b.Bounds.GapSquared(probe.Bounds) > padding * padding) continue;
                for (int k = 0; k < b.World.Length; k++) if (C.Clearance(b.World[k], probe) <= padding) { result = i; break; }
            }
            return result;
        }

        /// <returns>Fraction of the requested operation committed. No managed allocations.</returns>
        public float Move(int index, Vector2 displacement, float degrees)
        {
            if (operatedIndex == index) MarkReleaseNeighbors(index);
            LastPairChecks = LastSweepIterations = LastObstacleId = 0;
            NeoLevelData.Finite(displacement.x); NeoLevelData.Finite(displacement.y); NeoLevelData.Finite(degrees);
            var body = Bodies[index]; var e = body.Data;
            if (!body.Active || e.Operation == NeoOperation.Fixed || body.Locked) return 0;
            if (e.Operation == NeoOperation.Rotate) displacement = Vector2.zero;
            else { degrees = 0; Vector2 axis = e.MovementAxis.normalized; displacement = axis * Vector2.Dot(displacement, axis); }
            if (Mathf.Abs(e.Position.x + displacement.x) > 10000 || Mathf.Abs(e.Position.y + displacement.y) > 10000) return 0;
            double radians = degrees * Math.PI / 180, travel = displacement.magnitude + Math.Abs(radians) * body.Geometry.MotionRadius * e.Scale;
            if (travel < 1e-12) return 1;
            double fraction = 1, contactFraction = 1;
            int contactOther = -1, contactFirstPart = -1, contactSecondPart = -1;
            for (int j = 0; j < Bodies.Length; j++)
            {
                if (j == index) continue;
                var obstacle = Bodies[j];
                if (!obstacle.Active) continue;
                for (int a = 0; a < body.World.Length; a++)
                {
                    if (degrees != 0 && body.Geometry.Parts[a].RotationInvariant) continue;
                    var swept = body.World[a].Bounds;
                    if (degrees == 0)
                    {
                        swept.MinX += Math.Min(0, displacement.x) - Data.CollisionSkin; swept.MaxX += Math.Max(0, displacement.x) + Data.CollisionSkin;
                        swept.MinY += Math.Min(0, displacement.y) - Data.CollisionSkin; swept.MaxY += Math.Max(0, displacement.y) + Data.CollisionSkin;
                    }
                    else
                    {
                        double radius = body.Geometry.MotionRadius * e.Scale + Data.CollisionSkin;
                        swept = new C.Bounds { MinX = e.Position.x - radius, MaxX = e.Position.x + radius, MinY = e.Position.y - radius, MaxY = e.Position.y + radius };
                    }
                    if (!swept.Overlaps(obstacle.Bounds)) continue;
                    for (int b = 0; b < obstacle.World.Length; b++)
                    {
                        if (!swept.Overlaps(obstacle.World[b].Bounds)) continue;
                        LastPairChecks++;
                        bool explosive = obstacle.Data.Kind != NeoShapeKind.Clasp && (body.Geometry.PartBombIndices[a] >= 0 || obstacle.Geometry.PartBombIndices[b] >= 0);
                        double next = explosive && C.Clearance(body.World[a], obstacle.World[b]) <= Data.CollisionSkin ? 0 :
                            degrees == 0 ? C.SweepTranslation(body.World[a], obstacle.World[b], new C.Point(displacement.x, displacement.y), Data.CollisionSkin) :
                            SweepRotation(body, a, obstacle.World[b], radians, fraction);
                        if (next < fraction)
                        {
                            fraction = contactFraction = next; LastObstacleId = obstacle.Data.Id;
                            contactOther = j; contactFirstPart = a; contactSecondPart = b;
                        }
                    }
                }
            }
            // A moving head must stop when it first acquires a body, even if a large input would
            // otherwise pass completely through the open channel and end with no occupancy.
            for (int h = 0; h < body.Channels.Length; h++)
                for (int j = 0; j < Bodies.Length; j++)
                {
                    if (j == index) continue;
                    var other = Bodies[j];
                    if (!other.Active) continue;
                    for (int k = 0; k < other.Geometry.BodyCount; k++)
                    {
                        var bounds = body.Channels[h].Bounds;
                        if (degrees == 0)
                        {
                            bounds.MinX += Math.Min(0, displacement.x); bounds.MaxX += Math.Max(0, displacement.x);
                            bounds.MinY += Math.Min(0, displacement.y); bounds.MaxY += Math.Max(0, displacement.y);
                        }
                        else
                        {
                            double radius = body.Geometry.MotionRadius * e.Scale;
                            bounds = new C.Bounds { MinX = e.Position.x - radius, MaxX = e.Position.x + radius, MinY = e.Position.y - radius, MaxY = e.Position.y + radius };
                        }
                        if (!bounds.Overlaps(other.World[k].Bounds)) continue;
                        LastPairChecks++;
                        double next = SweepChannel(body, h, other.World[k], displacement, radians, fraction);
                        if (next < fraction) { fraction = next; LastObstacleId = other.Data.Id; }
                    }
                }
            if (fraction > 0) SetPose(index, e.Position + displacement * (float)fraction, e.Angle + degrees * (float)fraction);
            if (operatedIndex == index) MarkReleaseNeighbors(index);
            if (contactOther >= 0 && contactFraction <= fraction + 1e-9 && C.Clearance(body.World[contactFirstPart], Bodies[contactOther].World[contactSecondPart]) <= Data.CollisionSkin + OccupancyTolerance * 2)
            {
                var obstacle = Bodies[contactOther];
                var point = body.Geometry.PartBombIndices[contactFirstPart] >= 0 ? C.CircleContact(body.World[contactFirstPart], obstacle.World[contactSecondPart]) :
                    obstacle.Geometry.PartBombIndices[contactSecondPart] >= 0 ? C.CircleContact(obstacle.World[contactSecondPart], body.World[contactFirstPart]) :
                    C.ContactPoint(body.World[contactFirstPart], obstacle.World[contactSecondPart]);
                ReportCollision(index, contactOther, contactFirstPart, contactSecondPart, point);
            }
            else reportedFirst = reportedSecond = -1;
            CheckBombContacts(index, Data.CollisionSkin + OccupancyTolerance);
            if (!body.Active && operatedIndex == index) ReleaseOperation(index);
            return (float)fraction;
        }

        private void ReportCollision(int first, int second, int firstPart, int secondPart, C.Point point)
        {
            var collision = new NeoCollision { FirstIndex = first, SecondIndex = second, FirstId = Bodies[first].Data.Id, SecondId = Bodies[second].Data.Id,
                FirstPart = firstPart, SecondPart = secondPart, Point = new Vector2((float)point.X, (float)point.Y) };
            if (reportedFirst == first && reportedSecond == second && (reportedPoint - collision.Point).sqrMagnitude <= .0001f) return;
            reportedFirst = first; reportedSecond = second; reportedPoint = collision.Point;
            if (Collided != null) foreach (Action<NeoCollision> handler in Collided.GetInvocationList())
                try { handler(collision); } catch (Exception ex) { Debug.LogException(ex); }
        }

        /// <summary>Call after runtime load. Authoring loads never detonate automatically.</summary>
        public int ResolveInitialBombContacts()
        {
            int count = 0;
            for (int i = 0; i < Bodies.Length; i++) if (CheckBombContacts(i, OccupancyTolerance)) count++;
            return count;
        }
        private bool CheckBombContacts(int index, double tolerance)
        {
            var first = Bodies[index];
            if (!first.Active || first.Data.Kind == NeoShapeKind.Clasp) return false;
            for (int j = 0; j < Bodies.Length; j++)
            {
                var second = Bodies[j];
                if (first.Data.Bombs.Length == 0 && second.Data.Bombs.Length == 0) continue;
                if (j == index || !second.Active || second.Data.Kind == NeoShapeKind.Clasp || first.Bounds.GapSquared(second.Bounds) > tolerance * tolerance) continue;
                for (int a = 0; a < first.World.Length; a++) for (int b = 0; b < second.World.Length; b++)
                {
                    int bomb = first.Geometry.PartBombIndices[a], otherBomb = second.Geometry.PartBombIndices[b];
                    if (bomb < 0 && otherBomb < 0) continue;
                    if (first.World[a].Bounds.GapSquared(second.World[b].Bounds) > tolerance * tolerance || C.Clearance(first.World[a], second.World[b]) > tolerance) continue;
                    var point = bomb >= 0 ? C.CircleContact(first.World[a], second.World[b]) : C.CircleContact(second.World[b], first.World[a]);
                    if (operatedIndex >= 0) { MarkReleaseNeighbors(index); MarkReleaseNeighbors(j); }
                    first.Active = second.Active = false;
                    if (bomb >= 0) first.BombSpent[bomb] = true;
                    if (otherBomb >= 0) second.BombSpent[otherBomb] = true;
                    UpdateRelations(index); UpdateRelations(j);
                    var explosion = new NeoExplosion { OwnerId = bomb >= 0 ? first.Data.Id : second.Data.Id, BombId = bomb >= 0 ? first.Data.Bombs[bomb].Id : second.Data.Bombs[otherBomb].Id,
                        OtherId = bomb >= 0 ? second.Data.Id : first.Data.Id, OtherBombId = bomb >= 0 && otherBomb >= 0 ? second.Data.Bombs[otherBomb].Id : 0,
                        Point = new Vector2((float)point.X, (float)point.Y) };
                    ReportCollision(index, j, a, b, point);
                    // Subscribers observe final consumed/hidden state. A bad subscriber cannot prevent others.
                    var handlers = Exploded;
                    if (handlers != null) foreach (Action<NeoExplosion> handler in handlers.GetInvocationList())
                        try { handler(explosion); } catch (Exception ex) { Debug.LogException(ex); }
                    return true;
                }
            }
            return false;
        }

        private double SweepChannel(Body body, int channel, C.Part obstacle, Vector2 displacement, double radians, double limit)
        {
            var local = body.Geometry.Channels[channel]; double gap = C.Clearance(body.Channels[channel], obstacle);
            double threshold = -OccupancyTolerance * 2;
            double travel = displacement.magnitude + Math.Abs(radians) * body.Geometry.MotionRadius * body.Data.Scale;
            double t = 0, baseAngle = body.Data.Angle * Math.PI / 180;
            for (int i = 0; i < 256 && t < limit; i++)
            {
                LastSweepIterations++;
                double next = Math.Min(limit, t + Math.Max(0, gap - threshold) * 0.9 / travel);
                if (next - t < 1e-12) break;
                double angle = baseAngle + radians * next;
                var trial = C.Transform(local, body.Data.Position.x + displacement.x * next, body.Data.Position.y + displacement.y * next, Math.Cos(angle), Math.Sin(angle), body.Data.Scale);
                double nextGap = C.Clearance(trial, obstacle);
                if (nextGap < threshold) break;
                t = next; gap = nextGap;
            }
            return t;
        }

        private double SweepRotation(Body body, int partIndex, C.Part obstacle, double radians, double limit)
        {
            var local = body.Geometry.Parts[partIndex]; double start = C.Clearance(body.World[partIndex], obstacle);
            if (start < -OccupancyTolerance) return 0;
            double threshold = Math.Min(Data.CollisionSkin, start) - 1e-9;
            var bounds = local.Bounds;
            double x = Math.Max(Math.Abs(bounds.MinX), Math.Abs(bounds.MaxX)), y = Math.Max(Math.Abs(bounds.MinY), Math.Abs(bounds.MaxY));
            double travel = Math.Abs(radians) * Math.Sqrt(x * x + y * y) * body.Data.Scale;
            if (travel < 1e-12) return limit;
            double t = 0, gap = start, baseAngle = body.Data.Angle * Math.PI / 180;
            // ponytail: bounded conservative rotation, 256 advances per primitive pair. Extremely tight tangent
            // contact can return a partial move; never take an unchecked minimum step through an obstacle.
            for (int i = 0; i < 256 && t < limit; i++)
            {
                LastSweepIterations++;
                double next = Math.Min(limit, t + Math.Max(0, gap - threshold) * 0.9 / travel);
                if (next - t < 1e-12) break;
                double angle = baseAngle + radians * next;
                var trial = C.Transform(local, body.Data.Position.x, body.Data.Position.y, Math.Cos(angle), Math.Sin(angle), body.Data.Scale);
                double nextGap = C.Clearance(trial, obstacle);
                if (nextGap < threshold) break;
                t = next; gap = nextGap;
            }
            return t;
        }

        public List<string> CheckPlayable()
        {
            var errors = new List<string>();
            for (int i = 0; i < Bodies.Length; i++)
            {
                var a = Bodies[i];
                if (!a.Active) continue;
                for (int j = i + 1; j < Bodies.Length; j++)
                {
                    var b = Bodies[j];
                    if (!b.Active || !a.Bounds.Overlaps(b.Bounds)) continue;
                    bool hit = false;
                    int aCount = b.Data.Kind == NeoShapeKind.Clasp ? a.World.Length : a.Geometry.SolidPartCount;
                    int bCount = a.Data.Kind == NeoShapeKind.Clasp ? b.World.Length : b.Geometry.SolidPartCount;
                    for (int x = 0; x < aCount && !hit; x++) for (int y = 0; y < bCount; y++)
                        if (a.World[x].Bounds.Overlaps(b.World[y].Bounds) && C.Clearance(a.World[x], b.World[y]) < -OccupancyTolerance) { hit = true; break; }
                    if (hit) errors.Add("Solid overlap: " + a.Data.Id + " / " + b.Data.Id);
                }
                for (int h = 0; h < a.Channels.Length; h++)
                {
                    for (int k = 0; k < a.Geometry.SolidPartCount; k++)
                        if (a.Channels[h].Bounds.Overlaps(a.World[k].Bounds) && C.Clearance(a.Channels[h], a.World[k]) < -OccupancyTolerance)
                        { errors.Add("Self-blocked channel: " + a.Data.Id + " channel " + h + "; move its anchor or center."); break; }
                    double width = a.Channels[h].HalfHeight * 2;
                    // Conservative passage test against the thickest possible entering rod in this level.
                    for (int j = 0; j < Bodies.Length; j++)
                    {
                        if (j == i || !Bodies[j].Active || Bodies[j].Geometry.BodyCount == 0) continue;
                        var b = Bodies[j].Data; double thickness = b.Thickness * b.Scale;
                        double margin = 2 * Data.CollisionSkin + (b.Kind == NeoShapeKind.C ? 2 * b.ArcError * b.Scale : 0);
                        if (width >= thickness && width - thickness <= margin)
                        { errors.Add("Unreliable narrow channel: " + a.Data.Id + " channel " + h + " / " + b.Id + "; increase clearance."); break; }
                    }
                }
            }
            return errors;
        }
    }
}

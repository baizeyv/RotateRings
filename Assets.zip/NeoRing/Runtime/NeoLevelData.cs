using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace WordTile.NeoRing
{
    public enum NeoShapeKind { Ring, C, Gate, Seven, Z, Clasp, Straight }
    public enum NeoOperation { Fixed, Rotate, Slide }

    [Serializable]
    public sealed class NeoBomb
    {
        public int Id;
        public bool Enabled = true;
        public Vector2 Position, CenterOffset = new Vector2(0, -0.05f);
        public float Angle, Scale = 1, Radius = 0.2f, ImageWidth = 0.5f;
        public int SortingOffset = 5;
        public string SpriteId = "";
    }

    [Serializable]
    public sealed class NeoHead
    {
        public bool AlongBody, Inward, ToCenter;
        public float AttachAngle = 90, PathPosition = 0.5f, RodLength = 0.45f, DirectionOffset;
        public bool ShowHead = true;
        public Vector2 Anchor, Center = new Vector2(0, 1.3f);
        public float Angle, StemWidth = 0.16f, Length = 0.65f, Width = 0.5f, ChannelWidth = 0.28f;
    }

    [Serializable]
    public sealed class NeoElement
    {
        public int Id;
        public string Name = "Shape";
        public NeoShapeKind Kind;
        public NeoOperation Operation = NeoOperation.Rotate;
        public Vector2 Position, MovementAxis = Vector2.right;
        public float Angle, Scale = 1, Radius = 1, Width = 2, Height = 2, BottomWidth = 2;
        // Zero inherits legacy Height, preserving existing equal-legged gates.
        public float GateLeftHeight, GateRightHeight;
        public float ResolvedGateLeftHeight { get { return GateLeftHeight == 0 ? Height : GateLeftHeight; } }
        public float ResolvedGateRightHeight { get { return GateRightHeight == 0 ? Height : GateRightHeight; } }
        public float Thickness = 0.16f, StartAngle = 35, SweepAngle = 290, ArcError = 0.005f;
        public float ClaspLength = 0.65f, ClaspWidth = 0.5f, ChannelWidth = 0.28f;
        public int SortingOrder;
        public Color Color = new Color(0.25f, 0.75f, 0.95f, 1);
        public string MaterialId = "", SpriteId = "";
        public NeoHead[] Heads = Array.Empty<NeoHead>();
        public NeoBomb[] Bombs = Array.Empty<NeoBomb>();
    }

    /// <summary>The portable source of truth. No Mesh, material objects or derived lock state.</summary>
    [Serializable]
    public sealed class NeoLevelData
    {
        public int Version = 1;
        public string Name = "NeoRing Level";
        public string MaterialId = "";
        public float CollisionSkin = 0.0005f;
        public NeoElement[] Elements = Array.Empty<NeoElement>();
        public const int MaxElements = 100;

        public void Validate()
        {
            if (Version != 1) throw new ArgumentException("Unsupported NeoRing level version: " + Version);
            Positive(CollisionSkin, "Collision skin", 0.1f);
            if (Elements == null || Elements.Length > MaxElements) throw new ArgumentException("A level supports 0–100 elements.");
            var ids = new HashSet<int>();
            foreach (var e in Elements)
            {
                if (e == null || e.Id <= 0 || !ids.Add(e.Id)) throw new ArgumentException("Element IDs must be unique positive integers.");
                ValidateElement(e);
            }
        }

        public static void ValidateElement(NeoElement e)
        {
            if (e == null || !Enum.IsDefined(typeof(NeoShapeKind), e.Kind) || !Enum.IsDefined(typeof(NeoOperation), e.Operation))
                throw new ArgumentException("Invalid shape or operation.");
            Point(e.Position); Point(e.MovementAxis); Finite(e.Angle); Positive(e.Scale, "Scale", 100);
            if (e.SortingOrder < -1000 || e.SortingOrder > 1000) throw new ArgumentException("Sorting order must be between -1000 and 1000.");
            Finite(e.Color.r); Finite(e.Color.g); Finite(e.Color.b); Finite(e.Color.a);
            if (e.Operation == NeoOperation.Slide && e.MovementAxis.sqrMagnitude < 0.000001f) throw new ArgumentException("Slide axis cannot be zero.");
            if (e.Kind == NeoShapeKind.Clasp)
            {
                Rails(e.ClaspLength, e.ClaspWidth, e.ChannelWidth);
                if (e.Operation != NeoOperation.Fixed) throw new ArgumentException("Clasps must be fixed.");
            }
            else
            {
                Positive(e.Thickness, "Thickness"); Positive(e.ArcError, "Arc error", 0.05f);
                if (e.ArcError < 0.0001f) throw new ArgumentException("Arc error must be at least 0.0001 world units before scaling.");
                if (e.Kind == NeoShapeKind.Ring || e.Kind == NeoShapeKind.C)
                {
                    Positive(e.Radius, "Radius");
                    if (e.Radius <= e.Thickness / 2) throw new ArgumentException("Ring radius must exceed half its thickness.");
                    Finite(e.StartAngle); Finite(e.SweepAngle);
                    if (e.Kind == NeoShapeKind.C && (e.SweepAngle <= 0 || e.SweepAngle >= 360)) throw new ArgumentException("C sweep must be between 0 and 360 degrees.");
                }
                else
                {
                    Positive(e.Width, "Width");
                    if (e.Kind != NeoShapeKind.Straight) Positive(e.Height, "Height");
                    if (e.Kind == NeoShapeKind.Gate)
                    { Finite(e.GateLeftHeight); Finite(e.GateRightHeight); Positive(e.ResolvedGateLeftHeight, "Gate left height"); Positive(e.ResolvedGateRightHeight, "Gate right height"); }
                    if (e.Kind == NeoShapeKind.Z) Positive(e.BottomWidth, "Bottom width");
                }
            }
            if (e.Heads == null || e.Heads.Length > 16 || (e.Kind == NeoShapeKind.Clasp && e.Heads.Length != 0)) throw new ArgumentException("Invalid head list (maximum 16; clasps have no heads).");
            NeoConnection.Resolve(e);
            foreach (var h in e.Heads)
            {
                if (h == null) throw new ArgumentException("Null connection head.");
                Point(h.Anchor); Point(h.Center); Finite(h.Angle); Positive(h.StemWidth, "Stem width");
                if (h.ShowHead) Rails(h.Length, h.Width, h.ChannelWidth);
                else if (Vector2.Distance(h.Anchor, h.Center) < h.StemWidth / 2)
                    throw new ArgumentException("A round-ended rod must be at least half its width long.");
            }
            if (e.Bombs == null || e.Bombs.Length > 16 || (e.Kind == NeoShapeKind.Clasp && e.Bombs.Length != 0))
                throw new ArgumentException("Each non-clasp shape supports up to 16 attached bombs.");
            var bombIds = new HashSet<int>();
            foreach (var b in e.Bombs)
            {
                if (b == null || b.Id <= 0 || !bombIds.Add(b.Id)) throw new ArgumentException("Bomb IDs must be unique positive integers within their owner.");
                Point(b.Position); Point(b.CenterOffset); Finite(b.Angle); Positive(b.Scale, "Bomb scale", 100);
                Positive(b.Radius, "Bomb radius"); Positive(b.ImageWidth, "Bomb image width");
                if (b.SortingOffset < -1000 || b.SortingOffset > 1000) throw new ArgumentException("Bomb sorting offset must be between -1000 and 1000.");
            }
        }

        private static void Rails(float length, float width, float channel)
        {
            Positive(length, "Channel length"); Positive(width, "Outer width"); Positive(channel, "Channel width");
            if (channel >= width) throw new ArgumentException("Channel width must be less than outer width.");
        }
        public static void Finite(float value)
        { if (float.IsNaN(value) || float.IsInfinity(value)) throw new ArgumentException("Numbers must be finite."); }
        private static void Point(Vector2 p)
        { Finite(p.x); Finite(p.y); if (Mathf.Abs(p.x) > 10000 || Mathf.Abs(p.y) > 10000) throw new ArgumentException("Coordinates exceed 10000 units."); }
        private static void Positive(float value, string label, float max = 1000)
        { Finite(value); if (value <= 0 || value > max) throw new ArgumentException(label + " must be positive and <= " + max + "."); }

        public string ToJson()
        {
            Validate(); string json = JsonUtility.ToJson(this, true);
            if (json.Length > 2 * 1024 * 1024) throw new ArgumentException("Level JSON exceeds 2 MB.");
            return json;
        }
        public NeoLevelData Clone() { return FromJson(ToJson()); }
        public static NeoLevelData FromJson(string json)
        {
            if (string.IsNullOrWhiteSpace(json) || json.Length > 2 * 1024 * 1024) throw new ArgumentException("Level JSON is empty or too large.");
            // JsonUtility silently ignores unknown fields, so do not accept legacy Mesh/PM files as empty levels.
            var header = JsonUtility.FromJson<RequiredFields>(json);
            if (header == null || header.Version == 0 || header.Elements == null) throw new ArgumentException("Expected a NeoRing parameter level, not a legacy Mesh/PM file.");
            var data = JsonUtility.FromJson<NeoLevelData>(json);
            if (data == null) throw new ArgumentException("Invalid level JSON.");
            data.Validate(); return data;
        }
        [Serializable]
        private sealed class RequiredFields
        {
            public int Version = 0;
            public NeoElement[] Elements = null;
        }
        public static NeoLevelData Load(string path)
        {
            if (new FileInfo(path).Length > 2 * 1024 * 1024) throw new ArgumentException("Level file exceeds 2 MB.");
            return FromJson(File.ReadAllText(path));
        }
        public void Save(string path)
        {
            string json = ToJson(), full = Path.GetFullPath(path);
            Directory.CreateDirectory(Path.GetDirectoryName(full));
            string temp = full + ".tmp";
            try
            {
                File.WriteAllText(temp, json);
                if (File.Exists(full)) File.Replace(temp, full, null); else File.Move(temp, full);
            }
            finally { if (File.Exists(temp)) File.Delete(temp); }
        }
    }
}

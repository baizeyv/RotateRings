using System;
using UnityEngine;

namespace WordTile.NeoRing
{
    public static class NeoConnection
    {
        public static void Resolve(NeoElement e)
        {
            foreach (var h in e.Heads)
            {
                if (h == null || !h.AlongBody) continue;
                NeoLevelData.Finite(h.AttachAngle); NeoLevelData.Finite(h.PathPosition);
                NeoLevelData.Finite(h.DirectionOffset); NeoLevelData.Finite(h.RodLength);
                if (h.PathPosition < 0 || h.PathPosition > 1 || h.RodLength <= 0 || h.RodLength > 1000)
                    throw new ArgumentException("路径位置须为 0–1，杆长须为 0–1000 的正数。");
                Vector2 normal;
                if (e.Kind == NeoShapeKind.Ring || e.Kind == NeoShapeKind.C)
                {
                    float angle = h.AttachAngle;
                    if (e.Kind == NeoShapeKind.C)
                    {
                        float offset = Mathf.Repeat(angle - e.StartAngle, 360);
                        if (offset > e.SweepAngle) offset = offset - e.SweepAngle < 360 - offset ? e.SweepAngle : 0;
                        angle = e.StartAngle + offset;
                    }
                    normal = Rotate(Vector2.right, angle); h.Anchor = normal * e.Radius;
                }
                else
                {
                    Vector2[] points, normals;
                    if (e.Kind == NeoShapeKind.Gate)
                    { points = new[] { new Vector2(-e.Width / 2, e.Height / 2 - e.ResolvedGateLeftHeight), new Vector2(-e.Width / 2, e.Height / 2), new Vector2(e.Width / 2, e.Height / 2), new Vector2(e.Width / 2, e.Height / 2 - e.ResolvedGateRightHeight) }; normals = new[] { Vector2.left, Vector2.up, Vector2.right }; }
                    else if (e.Kind == NeoShapeKind.Seven)
                    { points = new[] { new Vector2(-e.Width / 2, e.Height / 2), new Vector2(e.Width / 2, e.Height / 2), new Vector2(e.Width / 2, -e.Height / 2) }; normals = new[] { Vector2.up, Vector2.right }; }
                    else if (e.Kind == NeoShapeKind.Z)
                    { points = new[] { new Vector2(-e.Width, e.Height / 2), new Vector2(0, e.Height / 2), new Vector2(0, -e.Height / 2), new Vector2(e.BottomWidth, -e.Height / 2) }; normals = new[] { Vector2.up, Vector2.right, Vector2.down }; }
                    else
                    { points = new[] { new Vector2(-e.Width / 2, 0), new Vector2(e.Width / 2, 0) }; normals = new[] { Vector2.up }; }
                    float total = 0; for (int i = 1; i < points.Length; i++) total += Vector2.Distance(points[i - 1], points[i]);
                    float remaining = total * h.PathPosition; int segment = 0;
                    while (segment < points.Length - 2 && remaining > Vector2.Distance(points[segment], points[segment + 1]))
                    { remaining -= Vector2.Distance(points[segment], points[segment + 1]); segment++; }
                    h.Anchor = Vector2.Lerp(points[segment], points[segment + 1], remaining / Vector2.Distance(points[segment], points[segment + 1])); normal = normals[segment];
                }
                Vector2 direction = Rotate(h.Inward ? -normal : normal, h.DirectionOffset);
                if (h.Inward && h.ToCenter)
                {
                    if (h.Anchor.sqrMagnitude < .000001f) throw new ArgumentException("杆根已在中心，不能延伸到中心。");
                    direction = -h.Anchor.normalized; h.Center = Vector2.zero;
                }
                else h.Center = h.Anchor + direction * (h.RodLength + (h.ShowHead ? (h.Width + h.ChannelWidth) / 4 : 0));
                h.Angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg - 90;
            }
        }
        public static Vector2 Rotate(Vector2 point, float angle)
        { float radians = angle * Mathf.Deg2Rad; return new Vector2(point.x * Mathf.Cos(radians) - point.y * Mathf.Sin(radians), point.x * Mathf.Sin(radians) + point.y * Mathf.Cos(radians)); }
    }
}

using System;
using UnityEngine;

namespace WordTile.NeoRing
{
    [Serializable]
    public sealed class NeoMaterialEntry { public string Id; public Material Material; }
    [Serializable]
    public sealed class NeoSpriteEntry { public string Id; public Sprite Sprite; }

    /// <summary>Shared rendering resources live in the application; all shape geometry lives in JSON.</summary>
    public sealed class NeoLevelView : MonoBehaviour
    {
        public NeoMaterialEntry[] Materials = Array.Empty<NeoMaterialEntry>();
        public Material SharedShapeMaterial;
        public NeoSpriteEntry[] Sprites = Array.Empty<NeoSpriteEntry>();
        [Range(0, 31)] public int RenderLayer = 31;
        public NeoWorld World { get; private set; }
        private GameObject root;
        private Transform[] poses;
        private MeshRenderer[] renderers;
        private Material defaultMaterial;
        private MaterialPropertyBlock properties;
        private Material levelMaterial;

        public void Load(NeoLevelData data)
        {
            data.Validate(); ValidateResources(data);
            Material selectedMaterial = SharedShapeMaterial != null ? SharedShapeMaterial : MaterialFor(data.MaterialId);
            var next = new NeoWorld(data);
            GameObject newRoot = null;
            try
            {
                if (properties == null) properties = new MaterialPropertyBlock();
                if (defaultMaterial == null)
                {
                    Material template = Resources.Load<Material>("NeoRingAtlas");
                    if (template == null) throw new InvalidOperationException("Missing NeoRing atlas material.");
                    defaultMaterial = new Material(template) { name = "NeoRing shared atlas material", enableInstancing = true };
                }
                newRoot = new GameObject("NeoRing generated level"); newRoot.transform.SetParent(transform, false); newRoot.SetActive(false);
                levelMaterial = selectedMaterial != null ? selectedMaterial : defaultMaterial;
                var nextPoses = new Transform[next.Bodies.Length]; var nextRenderers = new MeshRenderer[nextPoses.Length];
                for (int i = 0; i < nextPoses.Length; i++)
                {
                    var obj = new GameObject(next.Data.Elements[i].Id + " " + next.Data.Elements[i].Name) { layer = RenderLayer };
                    obj.transform.SetParent(newRoot.transform, false);
                    obj.AddComponent<MeshFilter>().sharedMesh = next.Bodies[i].Geometry.Mesh;
                    nextPoses[i] = obj.transform; nextRenderers[i] = obj.AddComponent<MeshRenderer>();
                    Apply(next.Bodies[i], nextPoses[i], nextRenderers[i]);
                }
                if (root != null) { root.SetActive(false); NeoWorld.Release(root); }
                if (World != null) World.Dispose();
                World = next; root = newRoot; poses = nextPoses; renderers = nextRenderers; root.SetActive(true);
                World.Exploded += OnExplosion;
                World.VisibilityChanged += SyncVisibility;
                World.Collided += OnCollision;
            }
            catch { if (newRoot != null) NeoWorld.Release(newRoot); next.Dispose(); throw; }
        }
        public void ReplaceElement(int index, NeoElement data)
        {
            ValidateResources(new NeoLevelData { Elements = new[] { data } });
            World.ReplaceElement(index, data);
            poses[index].GetComponent<MeshFilter>().sharedMesh = World.Bodies[index].Geometry.Mesh;
            Apply(World.Bodies[index], poses[index], renderers[index]);
        }
        public void SyncPose(int index)
        {
            var e = World.Bodies[index].Data;
            poses[index].localPosition = new Vector3(e.Position.x, e.Position.y, -e.SortingOrder * 0.0001f);
            poses[index].localRotation = Quaternion.Euler(0, 0, e.Angle); poses[index].localScale = Vector3.one * e.Scale;
        }
        private void Apply(NeoWorld.Body body, Transform pose, MeshRenderer renderer)
        {
            var e = body.Data;
            pose.localPosition = new Vector3(e.Position.x, e.Position.y, -e.SortingOrder * 0.0001f);
            pose.localRotation = Quaternion.Euler(0, 0, e.Angle); pose.localScale = Vector3.one * e.Scale;
            renderer.sharedMaterial = levelMaterial; renderer.sortingOrder = e.SortingOrder;
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off; renderer.receiveShadows = false;
            properties.Clear(); properties.SetColor("_InstanceColor", e.Color);
            renderer.enabled = true;
            var claspVisual = pose.Find("Clasp image");
            if (claspVisual != null) { claspVisual.gameObject.SetActive(false); NeoWorld.Release(claspVisual.gameObject); }
            if (!string.IsNullOrEmpty(e.SpriteId))
            {
                Sprite sprite = SpriteFor(e.SpriteId);
                properties.SetTexture("_MainTex", sprite.texture);
                properties.SetFloat("_UseCustomTexture", 1);
                var bounds = body.Geometry.Mesh.bounds; var rect = sprite.textureRect;
                Vector2 scale = new Vector2(rect.width / sprite.texture.width / Mathf.Max(0.00001f, bounds.size.x), rect.height / sprite.texture.height / Mathf.Max(0.00001f, bounds.size.y));
                var st = new Vector4(scale.x, scale.y, rect.x / sprite.texture.width - bounds.min.x * scale.x, rect.y / sprite.texture.height - bounds.min.y * scale.y);
                properties.SetVector("_MainTex_ST", st);
            }
            renderer.SetPropertyBlock(properties);
            var oldBombs = pose.Find("Bomb visuals");
            if (oldBombs != null) { oldBombs.name = "Retired bomb visuals"; oldBombs.gameObject.SetActive(false); NeoWorld.Release(oldBombs.gameObject); }
            if (e.Bombs.Length > 0)
            {
                var container = new GameObject("Bomb visuals"); container.transform.SetParent(pose, false);
                foreach (var bomb in e.Bombs)
                {
                    var obj = new GameObject("Bomb " + bomb.Id) { layer = RenderLayer }; obj.transform.SetParent(container.transform, false);
                    obj.transform.localPosition = new Vector3(bomb.Position.x, bomb.Position.y, -0.001f);
                    obj.transform.localRotation = Quaternion.Euler(0, 0, bomb.Angle);
                    var sprite = BombSprite(bomb.SpriteId);
                    obj.transform.localScale = Vector3.one * (bomb.ImageWidth * bomb.Scale / sprite.bounds.size.x);
                    var visual = obj.AddComponent<SpriteRenderer>(); visual.sprite = sprite;
                    visual.sortingLayerID = renderer.sortingLayerID; visual.sortingOrder = e.SortingOrder + bomb.SortingOffset;
                    obj.SetActive(bomb.Enabled);
                }
            }
        }
        private void OnExplosion(NeoExplosion explosion)
        { SyncVisibility(); }
        private void SyncVisibility()
        {
            for (int i = 0; i < poses.Length; i++) poses[i].gameObject.SetActive(World.Bodies[i].Active);
        }
        private void OnCollision(NeoCollision collision)
        {
            Vector3 point = transform.TransformPoint(new Vector3(collision.Point.x, collision.Point.y, 0));
            Debug.Log("NeoRing 碰撞：" + collision.FirstId + " [" + World.Data.Elements[collision.FirstIndex].Name + "] ↔ " + collision.SecondId + " [" + World.Data.Elements[collision.SecondIndex].Name + "]；世界碰撞点=" + point.ToString("F4"), this);
        }
        private Sprite BombSprite(string id)
        {
            if (!string.IsNullOrEmpty(id)) return SpriteFor(id);
            var sprite = Resources.Load<Sprite>("NeoRingBomb");
            if (sprite == null) throw new ArgumentException("Missing default bomb sprite.");
            return sprite;
        }
        private Material MaterialFor(string id)
        {
            if (string.IsNullOrEmpty(id)) return defaultMaterial;
            foreach (var entry in Materials) if (entry != null && entry.Id == id && entry.Material != null) return entry.Material;
            var resource = Resources.Load<Material>(id);
            if (resource != null) return resource;
            throw new ArgumentException("Unknown material ID: " + id);
        }
        private Sprite SpriteFor(string id)
        {
            foreach (var entry in Sprites) if (entry != null && entry.Id == id && entry.Sprite != null) return entry.Sprite;
            throw new ArgumentException("Unknown sprite ID: " + id);
        }
        private void ValidateResources(NeoLevelData data)
        {
            foreach (var e in data.Elements)
            {
                if (!string.IsNullOrEmpty(e.SpriteId))
                {
                    var s = SpriteFor(e.SpriteId);
                    if (s.packed && s.packingRotation != SpritePackingRotation.None) throw new ArgumentException("Rotated atlas sprites are unsupported.");
                    if (s.packed && s.packingMode == SpritePackingMode.Tight) throw new ArgumentException("Use rectangle-packed sprites.");
                }
                foreach (var bomb in e.Bombs) BombSprite(bomb.SpriteId);
            }
        }
        private void OnDestroy()
        {
            if (root != null) NeoWorld.Release(root);
            if (World != null) World.Dispose();
            if (defaultMaterial != null) NeoWorld.Release(defaultMaterial);
        }
    }
}

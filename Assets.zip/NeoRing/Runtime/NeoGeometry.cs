using System;
using System.Collections.Generic;
using UnityEngine;
using C = WordTile.Game.GameCollision2D;
using K = WordTile.Game.GameCollisionKind;

namespace WordTile.NeoRing
{
    /// <summary>Mesh and collision are built from the same primitives, only when dimensions change.</summary>
    public sealed class NeoGeometry
    {
        public C.Part[] Parts, Channels;
        public int[] ChannelConnectionIndices;
        public int[] PartBombIndices;
        public int BodyCount, SolidPartCount;
        public double MotionRadius;
        public Mesh Mesh;
        private string meshKey;
        private sealed class CachedMesh { public Mesh Mesh; public int References; }
        private static readonly Dictionary<string, CachedMesh> meshes = new Dictionary<string, CachedMesh>();

        public void ReleaseMesh()
        {
            if (meshKey == null) return;
            var entry = meshes[meshKey];
            if (--entry.References == 0) { meshes.Remove(meshKey); NeoWorld.Release(entry.Mesh); }
            meshKey = null; Mesh = null;
        }

        private static string MeshKey(C.Part[] parts, int count, float error)
        {
            // Key actual solid geometry, excluding pose, color, metadata and bomb colliders.
            using (var stream = new System.IO.MemoryStream())
            using (var writer = new System.IO.BinaryWriter(stream))
            {
                writer.Write(error); writer.Write(count);
                for (int i = 0; i < count; i++)
                {
                    var p = parts[i]; writer.Write((int)p.Kind);
                    writer.Write(p.A.X); writer.Write(p.A.Y); writer.Write(p.B.X); writer.Write(p.B.Y);
                    writer.Write(p.Axis.X); writer.Write(p.Axis.Y); writer.Write(p.Radius);
                    writer.Write(p.RingRadius); writer.Write(p.HalfWidth); writer.Write(p.HalfHeight);
                }
                return Convert.ToBase64String(stream.ToArray());
            }
        }

        public static NeoGeometry Build(NeoElement e)
        {
            NeoLevelData.ValidateElement(e);
            var parts = new List<C.Part>(); var channels = new List<C.Part>();
            var channelConnections = new List<int>();
            double r = e.Thickness / 2;
            switch (e.Kind)
            {
                case NeoShapeKind.Ring:
                    parts.Add(new C.Part { Kind = K.Ring, RingRadius = e.Radius, Radius = r, RotationInvariant = true }); break;
                case NeoShapeKind.C:
                    int count = ArcSegments(e.Radius, e.SweepAngle * Mathf.Deg2Rad, e.ArcError);
                    Vector2 previous = Polar(e.Radius, e.StartAngle);
                    for (int i = 1; i <= count; i++)
                    { Vector2 next = Polar(e.Radius, e.StartAngle + e.SweepAngle * i / count); parts.Add(Capsule(previous, next, r)); previous = next; }
                    break;
                case NeoShapeKind.Gate:
                    Vector2 a = new Vector2(-e.Width / 2, e.Height / 2 - e.ResolvedGateLeftHeight), b = new Vector2(-e.Width / 2, e.Height / 2);
                    Vector2 c = new Vector2(e.Width / 2, e.Height / 2), d = new Vector2(e.Width / 2, e.Height / 2 - e.ResolvedGateRightHeight);
                    parts.Add(Capsule(a, b, r)); parts.Add(Capsule(b, c, r)); parts.Add(Capsule(c, d, r)); break;
                case NeoShapeKind.Seven:
                    a = new Vector2(-e.Width / 2, e.Height / 2); b = new Vector2(e.Width / 2, e.Height / 2); c = new Vector2(e.Width / 2, -e.Height / 2);
                    parts.Add(Capsule(a, b, r)); parts.Add(Capsule(b, c, r)); break;
                case NeoShapeKind.Z:
                    a = new Vector2(-e.Width, e.Height / 2); b = new Vector2(0, e.Height / 2);
                    c = new Vector2(0, -e.Height / 2); d = new Vector2(e.BottomWidth, -e.Height / 2);
                    parts.Add(Capsule(a, b, r)); parts.Add(Capsule(b, c, r)); parts.Add(Capsule(c, d, r)); break;
                case NeoShapeKind.Clasp:
                    AddRails(parts, channels, Vector2.zero, 0, e.ClaspLength, e.ClaspWidth, e.ChannelWidth); channelConnections.Add(-1); break;
                case NeoShapeKind.Straight:
                    parts.Add(Capsule(new Vector2(-e.Width / 2, 0), new Vector2(e.Width / 2, 0), r)); break;
            }
            int bodyCount = e.Kind == NeoShapeKind.Clasp ? 0 : parts.Count;
            for (int connection = 0; connection < e.Heads.Length; connection++)
            {
                var h = e.Heads[connection];
                Vector2 end = h.Center;
                if (h.ShowHead)
                {
                    Vector2 axis = Polar(1, h.Angle), across = new Vector2(-axis.y, axis.x);
                    // Account for the transverse projection of an angled square rod. Its highest
                    // corner ends at the outside rail's center, rather than spilling into the channel.
                    float railCenter = (h.Width + h.ChannelWidth) / 4;
                    float lower = railCenter, upper = railCenter + h.StemWidth / 2;
                    for (int i = 0; i < 32; i++)
                    {
                        float mid = (lower + upper) / 2;
                        Vector2 along = (h.Center - across * mid - h.Anchor).normalized;
                        float projected = Mathf.Abs(Vector2.Dot(new Vector2(-along.y, along.x), across)) * h.StemWidth / 2;
                        if (mid - railCenter >= projected) upper = mid; else lower = mid;
                    }
                    end -= across * upper;
                }
                Vector2 direction = end - h.Anchor;
                if (direction.sqrMagnitude < 0.00000001f) throw new ArgumentException("Connection rod length must be positive.");
                parts.Add(new C.Part { Kind = K.Box, A = Point((h.Anchor + end) / 2), Axis = Point(direction.normalized),
                    HalfWidth = direction.magnitude / 2, HalfHeight = h.StemWidth / 2 });
                if (h.ShowHead)
                { AddRails(parts, channels, h.Center, h.Angle, h.Length, h.Width, h.ChannelWidth); channelConnections.Add(connection); }
                else parts.Add(Capsule(end, end, h.StemWidth / 2)); // Round tip; the root remains a flat box end.
            }
            int solidCount = parts.Count;
            var bombIndices = new List<int>();
            for (int i = 0; i < solidCount; i++) bombIndices.Add(-1);
            for (int i = 0; i < e.Bombs.Length; i++) if (e.Bombs[i].Enabled)
            {
                var bomb = e.Bombs[i]; float angle = bomb.Angle * Mathf.Deg2Rad;
                Vector2 offset = bomb.CenterOffset * bomb.Scale;
                Vector2 center = bomb.Position + new Vector2(Mathf.Cos(angle) * offset.x - Mathf.Sin(angle) * offset.y, Mathf.Sin(angle) * offset.x + Mathf.Cos(angle) * offset.y);
                parts.Add(Capsule(center, center, bomb.Radius * bomb.Scale)); bombIndices.Add(i);
            }
            var geometry = new NeoGeometry { Parts = parts.ToArray(), Channels = channels.ToArray(), ChannelConnectionIndices = channelConnections.ToArray(),
                PartBombIndices = bombIndices.ToArray(), BodyCount = bodyCount, SolidPartCount = solidCount };
            for (int i = 0; i < geometry.Parts.Length; i++)
            {
                geometry.Parts[i].UpdateBounds(); var bounds = geometry.Parts[i].Bounds;
                double x = Math.Max(Math.Abs(bounds.MinX), Math.Abs(bounds.MaxX)), y = Math.Max(Math.Abs(bounds.MinY), Math.Abs(bounds.MaxY));
                geometry.MotionRadius = Math.Max(geometry.MotionRadius, Math.Sqrt(x * x + y * y));
            }
            C.Part[] visualParts = geometry.Parts;
            int visualCount = solidCount;
            if (e.Kind == NeoShapeKind.Clasp)
            {
                // Full horizontal artwork; collision still uses the two rails and open passage.
                visualParts = new[] { new C.Part { Kind = K.Box, Axis = new C.Point(1, 0), HalfWidth = e.ClaspLength / 2, HalfHeight = e.ClaspWidth / 2 } };
                visualCount = 1;
            }
            geometry.meshKey = ((int)e.Kind) + ":" + bodyCount + ":" + MeshKey(visualParts, visualCount, e.ArcError);
            CachedMesh cached;
            if (!meshes.TryGetValue(geometry.meshKey, out cached))
            {
                cached = new CachedMesh { Mesh = BuildMesh(e, visualParts, visualCount, e.ArcError) };
                meshes.Add(geometry.meshKey, cached);
            }
            cached.References++; geometry.Mesh = cached.Mesh;
            return geometry;
        }

        public static int ArcSegments(double radius, double radians, double error)
        {
            double step = 2 * Math.Acos(Math.Max(-1, 1 - error / radius));
            int count = Math.Max(1, (int)Math.Ceiling(Math.Abs(radians) / Math.Min(Math.PI / 8, step)));
            if (count > 2048) throw new ArgumentException("Arc precision requires more than 2048 segments; increase Arc error.");
            return count;
        }
        private static Vector2 Polar(float radius, float degrees)
        { float a = degrees * Mathf.Deg2Rad; return new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * radius; }
        private static C.Point Point(Vector2 p) { return new C.Point(p.x, p.y); }
        private static C.Part Capsule(Vector2 a, Vector2 b, double radius)
        { return new C.Part { Kind = K.Capsule, A = Point(a), B = Point(b), Radius = radius }; }
        private static void AddRails(List<C.Part> parts, List<C.Part> channels, Vector2 center, float angle, float length, float width, float channel)
        {
            C.Part lower, upper; C.TryClaspRails(length, width, channel, out lower, out upper);
            double a = angle * Math.PI / 180;
            parts.Add(C.Transform(lower, center.x, center.y, Math.Cos(a), Math.Sin(a), 1));
            parts.Add(C.Transform(upper, center.x, center.y, Math.Cos(a), Math.Sin(a), 1));
            var passage = new C.Part { Kind = K.Box, A = Point(center), Axis = new C.Point(Math.Cos(a), Math.Sin(a)), HalfWidth = length / 2, HalfHeight = channel / 2 };
            passage.UpdateBounds(); channels.Add(passage);
        }

        private sealed class MeshWriter
        {
            public readonly List<Vector3> Vertices = new List<Vector3>();
            public readonly List<Vector2> UV = new List<Vector2>();
            public readonly List<Vector4> Tangents = new List<Vector4>();
            public readonly List<int> Triangles = new List<int>();
            public void Add(Vector2 position, Vector2 uv, Vector2 tangent, float depth = 0)
            {
                Vertices.Add(new Vector3(position.x, position.y, depth)); UV.Add(uv); Tangents.Add(new Vector4(tangent.x, tangent.y, 0, -1));
            }
            public void Fan(int start)
            { for (int i = start + 1; i < Vertices.Count - 1; i++) Tri(Triangles, start, i, i + 1); }
        }

        private static Mesh BuildMesh(NeoElement e, C.Part[] parts, int partCount, float error)
        {
            var output = new MeshWriter();
            int first = 0;
            if (e.Kind == NeoShapeKind.Ring || e.Kind == NeoShapeKind.C)
            {
                AddArc(output, e); first = e.Kind == NeoShapeKind.Ring ? 1 : ArcSegments(e.Radius, e.SweepAngle * Mathf.Deg2Rad, error);
            }
            else if (e.Kind != NeoShapeKind.Clasp)
            {
                first = e.Kind == NeoShapeKind.Straight ? 1 : e.Kind == NeoShapeKind.Seven ? 2 : 3;
                var path = new Vector2[first + 1];
                path[0] = new Vector2((float)parts[0].A.X, (float)parts[0].A.Y);
                for (int i = 0; i < first; i++) path[i + 1] = new Vector2((float)parts[i].B.X, (float)parts[i].B.Y);
                AddPolyline(output, path, e.Thickness / 2, error);
            }
            int connection = 0, connectionStart = e.Kind == NeoShapeKind.Clasp ? partCount : first > 0 ? first : e.Kind == NeoShapeKind.Straight ? 1 : e.Kind == NeoShapeKind.Seven ? 2 : 3;
            for (int i = first; i < partCount; i++)
            {
                NeoHead head = null;
                bool drawHead = false;
                NeoHead rod = null;
                if (i >= connectionStart && connection < e.Heads.Length)
                {
                    var h = e.Heads[connection];
                    if (i == connectionStart) rod = h;
                    if (h.ShowHead && i > connectionStart) { head = h; drawHead = i == connectionStart + 1; }
                    int end = connectionStart + (h.ShowHead ? 2 : 1);
                    if (i == end) { connection++; connectionStart = i + 1; }
                }
                if (head != null)
                {
                    if (!drawHead) continue;
                    AddPart(output, new C.Part { Kind = K.Box, A = Point(head.Center), Axis = Point(Polar(1, head.Angle)), HalfWidth = head.Length / 2, HalfHeight = head.Width / 2 }, error, e, head);
                }
                else if (rod != null)
                {
                    int start = output.Vertices.Count;
                    AddPart(output, parts[i], error, e, null);
                    if (!rod.ShowHead)
                    {
                        Vector2 direction = (rod.Center - rod.Anchor).normalized;
                        AddCap(output, rod.Center, direction, rod.StemWidth / 2, false, error);
                        // The next collision primitive is the round tip; it is already rendered here.
                        i++; connection++; connectionStart = i + 1;
                    }
                    for (int v = start; v < output.Vertices.Count; v++)
                    { var position = output.Vertices[v]; position.z = .001f; output.Vertices[v] = position; }
                }
                else AddPart(output, parts[i], error, e, null);
            }
            if (output.Vertices.Count > 200000) throw new ArgumentException("Mesh exceeds 200000 vertices.");
            var mesh = new Mesh { name = "NeoRing shared atlas geometry (not an asset)", indexFormat = output.Vertices.Count > 65535 ? UnityEngine.Rendering.IndexFormat.UInt32 : UnityEngine.Rendering.IndexFormat.UInt16 };
            var colors = new Color32[output.Vertices.Count]; var normals = new Vector3[colors.Length];
            var localUV = new List<Vector2>(colors.Length);
            for (int i = 0; i < colors.Length; i++)
            { colors[i] = new Color32(255, 255, 255, 255); normals[i] = Vector3.back; localUV.Add(output.Vertices[i]); }
            mesh.SetVertices(output.Vertices); mesh.SetUVs(0, output.UV); mesh.SetUVs(1, localUV);
            mesh.SetTangents(output.Tangents); mesh.normals = normals; mesh.colors32 = colors;
            mesh.SetTriangles(output.Triangles, 0); mesh.RecalculateBounds();
            // Player collision uses numeric parts; it never needs a CPU copy of render vertices.
            mesh.UploadMeshData(Application.isPlaying); return mesh;
        }

        private static void AddPolyline(MeshWriter output, Vector2[] path, float radius, float error)
        {
            int start = output.Vertices.Count;
            Vector2 first = (path[1] - path[0]).normalized, last = (path[path.Length - 1] - path[path.Length - 2]).normalized;
            AddSection(output, path[0], first, radius);
            for (int i = 1; i < path.Length - 1; i++)
            {
                Vector2 incoming = (path[i] - path[i - 1]).normalized, outgoing = (path[i + 1] - path[i]).normalized;
                Vector2 n0 = new Vector2(-incoming.y, incoming.x), n1 = new Vector2(-outgoing.y, outgoing.x);
                Vector2 offset = (n0 + n1) * (radius / Mathf.Max(.001f, 1 + Vector2.Dot(n0, n1)));
                // Limit the inside intersection for unusually short/thick segments.
                float limit = Mathf.Min(Vector2.Distance(path[i], path[i - 1]), Vector2.Distance(path[i], path[i + 1])) * .5f;
                float along = Mathf.Abs(Vector2.Dot(offset, incoming));
                if (along > limit) offset *= limit / along;
                float turn = Vector2.SignedAngle(incoming, outgoing), angle = Mathf.Atan2(incoming.y, incoming.x) * Mathf.Rad2Deg;
                float sign = turn >= 0 ? 1 : -1;
                float innerRadius = Mathf.Min(radius * .5f, limit * .25f);
                Vector2 innerCenter = path[i] + offset * sign - incoming * innerRadius + outgoing * innerRadius;
                int count = ArcSegments(radius, turn * Mathf.Deg2Rad, error);
                for (int j = 0; j <= count; j++)
                {
                    Vector2 tangent = Polar(1, angle + turn * j / count), normal = new Vector2(-tangent.y, tangent.x);
                    Vector2 inner = innerCenter - normal * (innerRadius * sign);
                    if (turn >= 0)
                    {
                        output.Add(inner, new Vector2(.25f, .75f), tangent);
                        output.Add(path[i] - normal * radius, new Vector2(.25f, .25f), tangent);
                    }
                    else
                    {
                        output.Add(path[i] + normal * radius, new Vector2(.25f, .75f), tangent);
                        output.Add(inner, new Vector2(.25f, .25f), tangent);
                    }
                }
            }
            AddSection(output, path[path.Length - 1], last, radius);
            int end = output.Vertices.Count;
            for (int q = start; q < end - 2; q += 2)
            { Tri(output.Triangles, q, q + 1, q + 3); Tri(output.Triangles, q, q + 3, q + 2); }
            AddCap(output, path[0], first, radius, true, error);
            AddCap(output, path[path.Length - 1], last, radius, false, error);
        }
        private static void AddSection(MeshWriter output, Vector2 center, Vector2 tangent, float radius)
        {
            Vector2 normal = new Vector2(-tangent.y, tangent.x);
            output.Add(center + normal * radius, new Vector2(.25f, .75f), tangent);
            output.Add(center - normal * radius, new Vector2(.25f, .25f), tangent);
        }
        private static void AddArc(MeshWriter output, NeoElement e)
        {
            bool closed = e.Kind == NeoShapeKind.Ring;
            float startAngle = closed ? 0 : e.StartAngle, sweep = closed ? 360 : e.SweepAngle;
            int segments = ArcSegments(e.Radius + e.Thickness / 2, sweep * Mathf.Deg2Rad, e.ArcError), start = output.Vertices.Count;
            for (int i = 0; i <= segments; i++)
            {
                Vector2 radial = Polar(1, startAngle + sweep * i / segments), tangent = new Vector2(-radial.y, radial.x);
                output.Add(radial * (e.Radius - e.Thickness / 2), new Vector2(.25f, .75f), tangent);
                output.Add(radial * (e.Radius + e.Thickness / 2), new Vector2(.25f, .25f), tangent);
                if (i < segments) { int q = start + i * 2; Tri(output.Triangles, q, q + 1, q + 3); Tri(output.Triangles, q, q + 3, q + 2); }
            }
            if (!closed)
            {
                AddCap(output, Polar(e.Radius, startAngle), Polar(1, startAngle + 90), e.Thickness / 2, true, e.ArcError);
                AddCap(output, Polar(e.Radius, startAngle + sweep), Polar(1, startAngle + sweep + 90), e.Thickness / 2, false, e.ArcError);
            }
        }
        private static void AddCap(MeshWriter output, Vector2 center, Vector2 tangent, float radius, bool left, float error)
        {
            Vector2 across = new Vector2(-tangent.y, tangent.x); int start = output.Vertices.Count;
            float u = left ? .0625f : .4375f;
            output.Add(center, new Vector2(u, .5f), tangent);
            int segments = ArcSegments(radius, Math.PI, Math.Min(error, radius * .05));
            for (int i = 0; i <= segments; i++)
            {
                float angle = ((left ? 90 : -90) + 180f * i / segments) * Mathf.Deg2Rad;
                float x = Mathf.Cos(angle), y = Mathf.Sin(angle);
                output.Add(center + (tangent * x + across * y) * radius, new Vector2(u + x * .03125f, .5f + y * .25f), tangent);
            }
            output.Fan(start);
        }
        private static void AddPart(MeshWriter output, C.Part p, float error, NeoElement e, NeoHead head)
        {
            Vector2 a = new Vector2((float)p.A.X, (float)p.A.Y), b = new Vector2((float)p.B.X, (float)p.B.Y);
            Vector2 tangent = p.Kind == K.Box ? new Vector2((float)p.Axis.X, (float)p.Axis.Y) : (b - a).normalized;
            if (tangent.sqrMagnitude < .5f) tangent = Vector2.right;
            Vector2 across = new Vector2(-tangent.y, tangent.x); int start = output.Vertices.Count;
            if (p.Kind == K.Box)
            {
                Vector2 x = tangent * (float)p.HalfWidth, y = across * (float)p.HalfHeight;
                AddSurfaceVertex(output, a - x - y, tangent, p, e, head);
                AddSurfaceVertex(output, a + x - y, tangent, p, e, head);
                AddSurfaceVertex(output, a + x + y, tangent, p, e, head);
                AddSurfaceVertex(output, a - x + y, tangent, p, e, head);
            }
            else
            {
                int n = ArcSegments(p.Radius, Math.PI, Math.Min(error, p.Radius * .05));
                for (int i = 0; i <= n; i++)
                { float angle = (-90 + 180f * i / n) * Mathf.Deg2Rad; AddSurfaceVertex(output, b + (tangent * Mathf.Cos(angle) + across * Mathf.Sin(angle)) * (float)p.Radius, tangent, p, e, head); }
                for (int i = 0; i <= n; i++)
                { float angle = (90 + 180f * i / n) * Mathf.Deg2Rad; AddSurfaceVertex(output, a + (tangent * Mathf.Cos(angle) + across * Mathf.Sin(angle)) * (float)p.Radius, tangent, p, e, head); }
            }
            output.Fan(start);
        }
        private static void AddSurfaceVertex(MeshWriter output, Vector2 position, Vector2 tangent, C.Part p, NeoElement e, NeoHead head)
        {
            Vector2 uv, across = new Vector2(-tangent.y, tangent.x);
            Vector2 a = new Vector2((float)p.A.X, (float)p.A.Y);
            if (e.Kind == NeoShapeKind.Clasp)
            {
                tangent = Vector2.right;
                uv = new Vector2((795f + (position.x / e.ClaspLength + .5f) * 74f) / 1024f, (12f + (position.y / e.ClaspWidth + .5f) * 103f) / 128f);
            }
            else if (head != null)
            {
                tangent = Polar(1, head.Angle); across = new Vector2(-tangent.y, tangent.x);
                Vector2 local = position - head.Center;
                uv = new Vector2(.5625f + (Vector2.Dot(local, tangent) / head.Length + .5f) * .125f, .25f + (Vector2.Dot(local, across) / head.Width + .5f) * .5f);
            }
            else if (p.Kind == K.Box)
            {
                Vector2 local = position - a;
                uv = new Vector2(.125f + (Vector2.Dot(local, tangent) / (float)(p.HalfWidth * 2) + .5f) * .25f, .5f + Vector2.Dot(local, across) / (float)(p.HalfHeight * 2) * .5f);
            }
            else
            {
                Vector2 b = new Vector2((float)p.B.X, (float)p.B.Y); float length = (b - a).magnitude, x = Vector2.Dot(position - a, tangent), radius = (float)p.Radius;
                float u = x < 0 ? .0625f + x / radius * .03125f : x > length ? .4375f + (x - length) / radius * .03125f : length > .000001f ? .0625f + x / length * .375f : .25f;
                uv = new Vector2(u, .5f + Vector2.Dot(position - a, across) / radius * .25f);
            }
            output.Add(position, uv, tangent);
        }
        private static void Tri(List<int> output, int a, int b, int c) { output.Add(a); output.Add(b); output.Add(c); }
    }
}

using System;
using System.Diagnostics;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using WordTile.NeoRing;
using C = WordTile.Game.GameCollision2D;

/// <summary>Small executable checks, no new test framework. Run via menu or Unity -executeMethod.</summary>
[InitializeOnLoad]
public static class NeoRingChecks
{
    private static int checks, frames;
    static NeoRingChecks()
    {
        EditorApplication.playModeStateChanged += state =>
        {
            if (state == PlayModeStateChange.EnteredPlayMode && SessionState.GetBool("NeoRing.Check", false))
            { frames = 0; EditorApplication.update += PlayCheck; }
        };
    }
    private static void Assert(bool condition, string message)
    { checks++; if (!condition) throw new Exception("NeoRing: " + message); }
    private static void Reject(Action action, string message)
    { bool rejected = false; try { action(); } catch (ArgumentException) { rejected = true; } Assert(rejected, message); }
    private static NeoElement Shape(int id, NeoShapeKind kind, Vector2 position, NeoOperation operation = NeoOperation.Rotate)
    { return new NeoElement { Id = id, Kind = kind, Position = position, Operation = kind == NeoShapeKind.Clasp ? NeoOperation.Fixed : operation }; }
    private static NeoLevelData Level(params NeoElement[] elements) { return new NeoLevelData { Elements = elements }; }

    [MenuItem("Tools/NeoRing/运行核心检查")]
    public static void Core()
    {
        checks = 0;
        SharedRenderChecks();
        ContinuousCornerChecks();
        var asymmetricGate = Shape(1, NeoShapeKind.Gate, Vector2.zero);
        asymmetricGate.GateLeftHeight = 3; asymmetricGate.GateRightHeight = 1;
        using (var gateWorld = new NeoWorld(Level(asymmetricGate)))
        {
            Assert(Math.Abs(gateWorld.Bodies[0].Geometry.Parts[0].A.Y + 2) < .00001 && Math.Abs(gateWorld.Bodies[0].Geometry.Parts[2].B.Y) < .00001, "Independent gate heights weren't applied to collision geometry.");
            var restoredGate = NeoLevelData.FromJson(gateWorld.Data.ToJson()).Elements[0];
            Assert(restoredGate.GateLeftHeight == 3 && restoredGate.GateRightHeight == 1, "Independent gate heights lost in JSON.");
        }
        asymmetricGate.Heads = new[] { new NeoHead { AlongBody = true, PathPosition = 1 } };
        NeoLevelData.ValidateElement(asymmetricGate);
        Assert((asymmetricGate.Heads[0].Anchor - Vector2.right).magnitude < .00001f, "Gate connector path ignored independent right height.");
        asymmetricGate.GateLeftHeight = -1; Reject(() => NeoLevelData.ValidateElement(asymmetricGate), "Negative gate leg height accepted.");
        Assert(Shape(1, NeoShapeKind.Gate, Vector2.zero).ResolvedGateLeftHeight == 2, "Legacy gate height inheritance failed.");
        var example = NeoAuthoringDefaults.Example(); example.Validate();
        string json = example.ToJson();
        Assert(!json.Contains("Mesh") && !json.Contains("vertices") && !json.Contains("LockCount"), "Derived geometry leaked into JSON.");
        var restored = NeoLevelData.FromJson(json);
        Assert(restored.Elements.Length == 7 && restored.Elements[0].Heads.Length == 1 && !restored.Elements[6].Heads[1].ShowHead, "JSON roundtrip lost shapes/optional heads.");
        Assert(restored.ToJson() == json, "JSON roundtrip changed parameters.");
        string file = Path.GetFullPath("Output/NeoRing-level-check.json"); example.Save(file); example.Save(file);
        Assert(NeoLevelData.Load(file).ToJson() == json && !File.Exists(file + ".tmp"), "Atomic overwrite failed.");
        Reject(() => NeoLevelData.FromJson("{\"Version\":1,\"Mesh\":{}}"), "Legacy Mesh data silently accepted.");
        Reject(() => NeoLevelData.FromJson("{\"Other\":{\"Version\":1,\"Elements\":[]}}"), "Missing top-level fields accepted.");
        Reject(() => NeoLevelData.FromJson("{\"Version\":2,\"Elements\":[]}"), "Unsupported version accepted.");
        var duplicate = example.Clone(); duplicate.Elements[1].Id = duplicate.Elements[0].Id; Reject(duplicate.Validate, "Duplicate ID accepted.");
        var invalid = example.Clone(); invalid.Elements[0].Radius = 0; Reject(invalid.Validate, "Zero radius accepted.");
        invalid = example.Clone(); invalid.Elements[0].Scale = -1; Reject(invalid.Validate, "Negative scale accepted.");
        invalid = example.Clone(); invalid.Elements[1].SweepAngle = 360; Reject(invalid.Validate, "Closed C accepted.");
        invalid = example.Clone(); invalid.Elements[0].Heads[0].ChannelWidth = 2; Reject(invalid.Validate, "Invalid head channel accepted.");
        invalid = example.Clone(); invalid.Elements[0].Angle = float.NaN; Reject(invalid.Validate, "NaN accepted.");
        using (var world = new NeoWorld(example))
        {
            Assert(world.CheckPlayable().Count == 0, "Example has solid overlaps or unreliable channels.");
            for (int i = 0; i < example.Elements.Length; i++)
            {
                var b = world.Bodies[i];
                Assert(b.Geometry.Mesh.vertexCount > 0 && b.Geometry.Parts.Length > 0, "Shape failed to generate: " + i);
                Assert(!AssetDatabase.Contains(b.Geometry.Mesh), "Generated Mesh became an asset.");
                var generated = b.Geometry.Mesh;
                Assert(generated.normals.Length == generated.vertexCount && generated.tangents.Length == generated.vertexCount && generated.uv2.Length == generated.vertexCount, "Atlas mesh missing normal/tangent/legacy UV streams.");
                Assert(Array.TrueForAll(generated.uv, coord => coord.x >= 0 && coord.x <= .8751f && coord.y >= 0 && coord.y <= 1), "Atlas UV escaped populated regions.");
                var bounds = b.Geometry.Mesh.bounds;
                for (int k = 0; k < b.Geometry.SolidPartCount; k++)
                {
                    var p = b.Geometry.Parts[k];
                    Assert(p.Bounds.MinX >= bounds.min.x - 0.006 && p.Bounds.MaxX <= bounds.max.x + 0.006 && p.Bounds.MinY >= bounds.min.y - 0.006 && p.Bounds.MaxY <= bounds.max.y + 0.006, "Mesh/collision bounds diverged.");
                }
            }
            var old = world.Bodies[1].Geometry.Mesh; var replacement = JsonUtility.FromJson<NeoElement>(JsonUtility.ToJson(world.Data.Elements[1])); replacement.Radius = 1.2f;
            world.ReplaceElement(1, replacement); Assert(world.Bodies[1].Geometry.Mesh != old && old == null, "Parameter edit didn't replace and release Mesh.");
        }
        using (var a = new NeoWorld(example)) using (var b = new NeoWorld(restored))
            Assert(a.Bodies[1].Geometry.Mesh.vertexCount == b.Bodies[1].Geometry.Mesh.vertexCount, "Geometry cannot regenerate from JSON.");
        double step = 290 * Math.PI / 180 / NeoGeometry.ArcSegments(1, 290 * Math.PI / 180, 0.005);
        Assert(1 - Math.Cos(step / 2) <= 0.005, "C sagitta exceeds configured error.");
        CollisionChecks(); RelationChecks(); ConnectionChecks(); BombChecks(); GroupChecks(); EditorChecks(); LibraryChecks(); SnapChecks(); ConnectionEditChecks(); RuntimeInteractionChecks(); Benchmark();
        using (var curved = new NeoWorld(Level(Shape(1, NeoShapeKind.C, Vector2.zero))))
        {
            var mesh = curved.Bodies[0].Geometry.Mesh;
            Assert(mesh.vertexCount < 200, "C rendering still tessellates every collision capsule separately.");
            Assert(Array.TrueForAll(mesh.tangents, t => Mathf.Abs(t.x * t.x + t.y * t.y - 1) < .0001f && t.w == -1), "Curved tangent frames aren't normalized.");
            UnityEngine.Debug.Log("NEORING_ARC_PERF: C vertices=" + mesh.vertexCount + "; collider parts=" + curved.Bodies[0].Geometry.BodyCount);
        }
        UnityEngine.Debug.Log("NEORING_CORE_PASS: " + checks + " checks; bombs, seven shapes, square joints, optional round tips, JSON/files, continuous motion, occupancy, history, play isolation.");
    }

    private static void ContinuousCornerChecks()
    {
        foreach (var kind in new[] { NeoShapeKind.Gate, NeoShapeKind.Seven, NeoShapeKind.Z })
        using (var world = new NeoWorld(Level(Shape(1, kind, Vector2.zero))))
        {
            var mesh = world.Bodies[0].Geometry.Mesh;
            int capVertices = 2 * (NeoGeometry.ArcSegments(.08, Math.PI, .004) + 2);
            var uv = mesh.uv; var tangents = mesh.tangents;
            bool continuous = true;
            for (int i = 0; i < uv.Length - capVertices; i++) continuous &= Mathf.Abs(uv[i].x - .25f) < .00001f;
            Assert(continuous, "Internal polygon corners sampled separate end-cap textures: " + kind);
            var points = mesh.vertices;
            // The first bend starts after the two endpoint vertices. Both boundaries must curve.
            bool roundedInside = (points[2] - points[4]).sqrMagnitude > .0000001f && (points[3] - points[5]).sqrMagnitude > .0000001f;
            Assert(roundedInside, "Polygon bend still collapses its inner boundary to one sharp corner: " + kind);
            Assert(Array.TrueForAll(tangents, t => Mathf.Abs(t.x * t.x + t.y * t.y - 1) < .0001f), "Corner tangent frame isn't normalized: " + kind);
        }
        foreach (bool showHead in new[] { false, true })
        {
            var e = Shape(1, NeoShapeKind.Straight, Vector2.zero);
            e.Heads = new[] { new NeoHead { ShowHead = showHead, Anchor = Vector2.zero, Center = new Vector2(.6f, 1.2f) } };
            using (var world = new NeoWorld(Level(e)))
            {
                var mesh = world.Bodies[0].Geometry.Mesh; var vertices = mesh.vertices; var uv = mesh.uv; var tangents = mesh.tangents;
                Vector2 axis = e.Heads[0].Center.normalized;
                int behind = 0, roundedEnd = 0; bool aligned = true;
                for (int i = 0; i < vertices.Length; i++) if (vertices[i].z > 0)
                {
                    behind++;
                    aligned &= Vector2.Dot(new Vector2(tangents[i].x, tangents[i].y), axis) > .999f || showHead;
                    if (Vector2.Dot((Vector2)vertices[i] - e.Heads[0].Center, axis) > .001f)
                    { roundedEnd++; aligned &= uv[i].x >= .4374f; }
                }
                Assert(behind > 0 && aligned, "Rod wasn't below the body or tip tangent/UV didn't follow rod direction.");
                if (!showHead) Assert(roundedEnd > 0, "Bare rod lost its forward round cap.");
            }
        }
    }
    private static void SharedRenderChecks()
    {
        var ring = Shape(1, NeoShapeKind.Ring, Vector2.zero);
        var other = Shape(2, NeoShapeKind.Ring, new Vector2(4, 0));
        other.Color = Color.red; other.Angle = 45; other.Scale = 2;
        other.Bombs = new[] { new NeoBomb { Id = 1 } };
        var first = new NeoWorld(Level(ring)); var second = new NeoWorld(Level(other));
        var mesh = first.Bodies[0].Geometry.Mesh;
        try
        {
            Assert(mesh == second.Bodies[0].Geometry.Mesh, "Pose/color/bombs caused duplicate mesh generation.");
            Assert(mesh.colors32.Length == mesh.vertexCount && mesh.colors32[0].Equals(new Color32(255, 255, 255, 255)), "Shared vertex-color base missing.");
            first.Dispose(); Assert(mesh != null, "Disposing one owner destroyed a shared mesh.");
            other.Color = Color.green; second.ReplaceElement(0, other);
            Assert(mesh == second.Bodies[0].Geometry.Mesh, "Color-only edit rebuilt shared mesh.");
            other.Radius = 1.4f; second.ReplaceElement(0, other);
            Assert(mesh == null && second.Bodies[0].Geometry.Mesh != null, "Last mesh owner didn't release or dimension edit failed.");
        }
        finally { first.Dispose(); second.Dispose(); }
        var obj = new GameObject("Shared rendering checks"); Material material = null;
        try
        {
            var view = obj.AddComponent<NeoLevelView>(); view.Load(Level(ring, Shape(2, NeoShapeKind.Ring, new Vector2(4, 0))));
            var renderers = obj.GetComponentsInChildren<MeshRenderer>();
            Assert(renderers.Length == 2 && renderers[0].sharedMaterial == renderers[1].sharedMaterial && renderers[0].sharedMaterial.enableInstancing, "Default shapes don't share an instancing material.");
            var block = new MaterialPropertyBlock(); renderers[0].GetPropertyBlock(block);
            Assert(block.GetColor("_InstanceColor") == ring.Color && block.GetColor("_BaseColor") == Color.clear, "Instance color wasn't the only per-shape color property.");
            material = new Material(Resources.Load<Shader>("NeoRing")) { enableInstancing = true };
            view.Materials = new[] { new NeoMaterialEntry { Id = "shared", Material = material } };
            var data = Level(ring, other); data.MaterialId = "shared";
            data.Elements[0].MaterialId = "ignored legacy element material";
            var session = new NeoLevelEditor(view, data);
            renderers = obj.GetComponentsInChildren<MeshRenderer>();
            Assert(Array.TrueForAll(renderers, r => r.sharedMaterial == material), "Level material didn't override all element materials.");
            Assert(data.Clone().MaterialId == "shared", "Level material ID lost in JSON.");
            var defaultData = data.Clone(); defaultData.MaterialId = ""; session.Apply(defaultData); session.Undo();
            Assert(Array.TrueForAll(obj.GetComponentsInChildren<MeshRenderer>(), r => r.sharedMaterial == material), "Material selection undo didn't restore shared material.");
            var clasp = Shape(3, NeoShapeKind.Clasp, Vector2.zero); view.Load(Level(clasp));
            Assert(view.World.Bodies[0].Geometry.Mesh != null && obj.GetComponentInChildren<MeshRenderer>().enabled, "Clasp mesh wasn't generated and rendered.");
            view.Sprites = new[] { new NeoSpriteEntry { Id = "catch", Sprite = AssetDatabase.LoadAssetAtPath<Sprite>("Assets/catch.png") } };
            clasp.SpriteId = "catch";
            var claspCopy = JsonUtility.FromJson<NeoElement>(JsonUtility.ToJson(clasp)); claspCopy.Id = 4; claspCopy.Position = Vector2.right;
            view.Load(Level(clasp, claspCopy));
            Assert(view.World.Bodies[0].Geometry.Mesh.vertexCount == 4 && view.World.Bodies[0].Geometry.Mesh == view.World.Bodies[1].Geometry.Mesh, "Image clasps didn't share a horizontal quad mesh.");
            Assert(view.World.Bodies[0].Geometry.Parts.Length == 2 && obj.GetComponentsInChildren<SpriteRenderer>().Length == 0, "Image clasp lost rail colliders or still uses SpriteRenderer.");
        }
        finally { UnityEngine.Object.DestroyImmediate(obj); if (material != null) UnityEngine.Object.DestroyImmediate(material); }
    }

    private static void LibraryChecks()
    {
        string path = Path.GetFullPath("Output/Library-" + Guid.NewGuid().ToString("N") + ".json");
        var library = new NeoElementLibrary(path);
        var source = NeoAuthoringDefaults.Example().Elements[0];
        library.Add(source, "Custom ring"); source.Heads[0].Length = 2;
        Assert(library.Data.Elements[0].Heads[0].Length != 2 && library.Data.Elements[0].Position == Vector2.zero, "Template shares source or retains placement.");
        library.Add(new NeoElement { Kind = NeoShapeKind.Clasp, Operation = NeoOperation.Fixed, SpriteId = "catch" }, "Image clasp");
        var reopened = new NeoElementLibrary(path);
        Assert(reopened.Data.Elements.Length == 2 && reopened.Data.Elements[1].SpriteId == "catch", "Persistent library lost image clasp.");
        Reject(() => reopened.Add(source, "Custom ring"), "Duplicate template name accepted.");
        Assert(new NeoElementLibrary(path).Data.Elements.Length == 2, "Failed save changed library.");
        var obj = new GameObject("Library check");
        try
        {
            var session = new NeoLevelEditor(obj.AddComponent<NeoLevelView>(), new NeoLevelData());
            session.AddCustom(reopened.Data.Elements[0], new Vector2(2, 3));
            session.AddCustom(reopened.Data.Elements[0], new Vector2(-2, 3));
            Assert(session.View.World.Data.Elements[0].Id != session.View.World.Data.Elements[1].Id, "Template instances share ID.");
            var edit = JsonUtility.FromJson<NeoElement>(JsonUtility.ToJson(session.View.World.Data.Elements[1]));
            edit.Heads[0].Length = 1.8f; edit.Bombs[0].Radius = .3f; session.ReplaceSelected(edit);
            Assert(session.View.World.Data.Elements[0].Heads[0].Length == reopened.Data.Elements[0].Heads[0].Length && reopened.Data.Elements[0].Bombs[0].Radius != .3f, "Editing instance changed template/other copy.");
            session.Undo(); session.Undo(); Assert(session.View.World.Bodies.Length == 1, "Template insertion undo failed.");
            session.Redo(); Assert(session.View.World.Bodies.Length == 2, "Template insertion redo failed.");
        }
        finally { UnityEngine.Object.DestroyImmediate(obj); }
        reopened.Remove(0);
        Assert(new NeoElementLibrary(path).Data.Elements.Length == 1 && new NeoElementLibrary(path).Data.Elements[0].Kind == NeoShapeKind.Clasp, "Template deletion not persisted.");
        File.Delete(path);
    }
    private static void SnapChecks()
    {
        var rod = Shape(1, NeoShapeKind.Straight, new Vector2(0, .12f)); rod.Width = 4;
        var clasp = Shape(2, NeoShapeKind.Clasp, Vector2.zero);
        bool snapped;
        using (var world = new NeoWorld(Level(rod, clasp)))
        {
            Vector2 delta = NeoSnap.Translation(world, new[] { 0 }, Vector2.zero, .2f, out snapped);
            Assert(snapped && Mathf.Abs(delta.y + .12f) < .00001f, "Rod failed to snap to clasp center.");
            world.TranslateGroup(new[] { 0 }, delta);
            Assert(world.ChannelOccupied(1, 0) && world.CheckPlayable().Count == 0, "Snapped clasp connection invalid.");
            delta = NeoSnap.Translation(world, new[] { 0 }, new Vector2(0, .5f), .2f, out snapped);
            Assert(!snapped && delta.y == .5f, "Drag can't leave snap radius.");
            delta = NeoSnap.Translation(world, new[] { 0 }, new Vector2(0, .1f), 0, out snapped);
            Assert(!snapped && delta.y == .1f, "Snap disabling ignored.");
        }
        using (var world = new NeoWorld(Level(rod, clasp)))
        {
            Vector2 delta = NeoSnap.Translation(world, new[] { 1 }, Vector2.zero, .2f, out snapped);
            Assert(snapped && Mathf.Abs(delta.y - .12f) < .00001f, "Moving clasp failed to snap to rod.");
        }
        var companion = Shape(3, NeoShapeKind.Clasp, new Vector2(-1.5f, .12f));
        using (var world = new NeoWorld(Level(rod, clasp, companion)))
        {
            Vector2 delta = NeoSnap.Translation(world, new[] { 0, 2 }, Vector2.zero, .2f, out snapped);
            Assert(snapped && Mathf.Abs(delta.y + .12f) < .00001f, "Group ignored external clasp or snapped internally.");
            world.TranslateGroup(new[] { 0, 2 }, delta);
            Assert(Mathf.Abs(world.Bodies[2].Data.Position.y) < .00001f && world.ChannelOccupied(2, 0), "Group snap separated companion clasp.");
        }
        rod.Angle = 90;
        using (var world = new NeoWorld(Level(rod, clasp)))
        { NeoSnap.Translation(world, new[] { 0 }, Vector2.zero, .2f, out snapped); Assert(!snapped, "Perpendicular rod snapped into channel."); }
        rod.Angle = 0; clasp.ChannelWidth = .1f;
        using (var world = new NeoWorld(Level(rod, clasp)))
        { NeoSnap.Translation(world, new[] { 0 }, Vector2.zero, .2f, out snapped); Assert(!snapped, "Rod snapped into narrow channel."); }
        clasp.ChannelWidth = .28f;
        var owner = Shape(4, NeoShapeKind.Gate, new Vector2(0, -2));
        owner.Heads = new[] { new NeoHead { Anchor = new Vector2(0, 1), Center = new Vector2(0, 2) } };
        using (var world = new NeoWorld(Level(rod, owner)))
        { NeoSnap.Translation(world, new[] { 0 }, Vector2.zero, .2f, out snapped); Assert(snapped, "Rod did not snap to connection head."); }
        var obstacle = Shape(5, NeoShapeKind.Straight, Vector2.zero); obstacle.Width = 1; obstacle.Angle = 90;
        using (var world = new NeoWorld(Level(rod, clasp, obstacle)))
        { NeoSnap.Translation(world, new[] { 0 }, Vector2.zero, .2f, out snapped); Assert(!snapped, "Snap introduced obstacle overlap."); }
        rod.Angle = 90; rod.Position = new Vector2(.12f, 0); clasp.Angle = 90;
        using (var world = new NeoWorld(Level(rod, clasp)))
        { Vector2 delta = NeoSnap.Translation(world, new[] { 0 }, Vector2.zero, .2f, out snapped); Assert(snapped && Mathf.Abs(delta.x + .12f) < .00001f, "Vertical snap failed."); }
        var ring = Shape(6, NeoShapeKind.Ring, new Vector2(.08f, 1.12f));
        foreach (var kind in new[] { NeoShapeKind.Ring, NeoShapeKind.C })
        {
            ring.Kind = kind; ring.StartAngle = 35; ring.SweepAngle = 290;
            using (var world = new NeoWorld(Level(ring, owner)))
            {
                Vector2 delta = NeoSnap.Translation(world, new[] { 0 }, Vector2.zero, .2f, out snapped);
                Assert(snapped && (delta - new Vector2(-.08f, -.12f)).magnitude < (kind == NeoShapeKind.C ? ring.ArcError + .005f : .00001f), "Curved shape failed tangent alignment to head: " + kind);
                world.TranslateGroup(new[] { 0 }, delta);
                Assert(world.HeadOccupied(1, 0) && world.CheckPlayable().Count == 0, "Curved head snap invalid: " + kind);
            }
            using (var world = new NeoWorld(Level(ring, owner)))
            { NeoSnap.Translation(world, new[] { 1 }, Vector2.zero, .2f, out snapped); Assert(snapped, "Moving head failed to snap to curve: " + kind); }
            clasp.Angle = 0;
            using (var world = new NeoWorld(Level(ring, clasp)))
            {
                NeoSnap.Translation(world, new[] { 0 }, Vector2.zero, .2f, out snapped);
                Assert(!snapped, "Curve snapped to clasp: " + kind);
                NeoSnap.Translation(world, new[] { 1 }, Vector2.zero, .2f, out snapped);
                Assert(!snapped, "Clasp snapped to curve: " + kind);
            }
        }
        ring.StartAngle = 0; ring.SweepAngle = 180;
        using (var world = new NeoWorld(Level(ring, owner)))
        { NeoSnap.Translation(world, new[] { 0 }, Vector2.zero, .2f, out snapped); Assert(!snapped, "C gap snapped to head."); }
    }
    private static void ConnectionEditChecks()
    {
        var ring = Shape(1, NeoShapeKind.Ring, Vector2.zero);
        ring.Heads = new[] { new NeoHead { AlongBody = true, AttachAngle = 90, RodLength = .5f } };
        NeoLevelData.ValidateElement(ring);
        var h = ring.Heads[0];
        Assert((h.Anchor - Vector2.up).magnitude < .00001f && Mathf.Abs(h.Center.y - 1.695f) < .00001f, "Outward rod length/attachment incorrect.");
        h.Inward = true; NeoLevelData.ValidateElement(ring);
        Assert(Mathf.Abs(h.Center.y - .305f) < .00001f && Mathf.Abs(Mathf.DeltaAngle(h.Angle, 180)) < .00001f, "Inward rod/head orientation incorrect.");
        h.ToCenter = true; NeoLevelData.ValidateElement(ring); Assert(h.Center == Vector2.zero, "To-center connector failed.");
        h.ToCenter = false; h.Inward = false; h.DirectionOffset = 90; NeoLevelData.ValidateElement(ring);
        Assert(Mathf.Abs(h.Center.x + .695f) < .00001f && Mathf.Abs(h.Center.y - 1) < .00001f, "Rod direction offset failed.");
        foreach (var kind in new[] { NeoShapeKind.Gate, NeoShapeKind.Seven, NeoShapeKind.Z, NeoShapeKind.Straight, NeoShapeKind.C })
        {
            var shape = Shape(1, kind, Vector2.zero); shape.Heads = new[] { new NeoHead { AlongBody = true, PathPosition = .25f } };
            using (var world = new NeoWorld(Level(shape))) Assert(world.Bodies[0].Geometry.Mesh.vertexCount > 0, "Procedural connector failed: " + kind);
        }
        var owner = Shape(1, NeoShapeKind.Straight, new Vector2(0, -1));
        owner.Heads = new[] { new NeoHead { AlongBody = true, RodLength = .805f } };
        var rod = Shape(2, NeoShapeKind.Straight, Vector2.zero); rod.Width = 3;
        var clasp = Shape(3, NeoShapeKind.Clasp, new Vector2(1, 0));
        var obj = new GameObject("Connector editing check");
        try
        {
            var session = new NeoLevelEditor(obj.AddComponent<NeoLevelView>(), Level(owner, rod, clasp)); session.Selected = 0;
            string before = session.View.World.Data.ToJson();
            var edit = JsonUtility.FromJson<NeoElement>(JsonUtility.ToJson(session.View.World.Data.Elements[0]));
            edit.Heads[0].RodLength += .5f; session.ReplaceSelected(edit);
            Assert(Mathf.Abs(session.View.World.Data.Elements[1].Position.y - .5f) < .00001f && Mathf.Abs(session.View.World.Data.Elements[2].Position.y - .5f) < .00001f, "Head length edit didn't move occupied branch/clasp.");
            Assert(session.View.World.HeadOccupied(0, 0) && session.View.World.ChannelOccupied(2, 1), "Head edit lost connections.");
            session.Undo(); Assert(session.View.World.Data.ToJson() == before, "Head edit undo didn't restore whole branch.");
            session.Redo();
            edit = JsonUtility.FromJson<NeoElement>(JsonUtility.ToJson(session.View.World.Data.Elements[0])); edit.Heads[0].DirectionOffset = 90;
            session.ReplaceSelected(edit);
            Assert((session.View.World.Data.Elements[1].Position - new Vector2(-1.5f, -1)).magnitude < .00001f && Mathf.Abs(session.View.World.Data.Elements[1].Angle - 90) < .0001f, "Head angle edit didn't rotate follower about channel.");
            Assert((session.View.World.Data.Elements[2].Position - new Vector2(-1.5f, 0)).magnitude < .00001f, "Head rotation separated dependent clasp.");
            string rotated = session.View.World.Data.ToJson();
            edit.Heads[0].RodLength = -1; Reject(() => session.ReplaceSelected(edit), "Invalid rod length accepted.");
            Assert(session.View.World.Data.ToJson() == rotated, "Invalid connection edit moved followers.");
            var roundtrip = NeoLevelData.FromJson(rotated);
            Assert(roundtrip.Elements[0].Heads[0].AlongBody && roundtrip.ToJson() == rotated, "Connector authoring parameters lost in JSON.");
            owner.Heads = new[] {
                new NeoHead { Anchor = new Vector2(-.4f, 0), Center = new Vector2(-.4f, 1) },
                new NeoHead { Anchor = new Vector2(.4f, 0), Center = new Vector2(.4f, 1) } };
            session = new NeoLevelEditor(session.View, Level(owner, rod, clasp)); session.Selected = 0;
            string constrained = session.View.World.Data.ToJson();
            edit = JsonUtility.FromJson<NeoElement>(JsonUtility.ToJson(session.View.World.Data.Elements[0]));
            edit.Heads[0].Center += Vector2.up * .3f;
            Reject(() => session.ReplaceSelected(edit), "Conflicting two-head branch edit accepted.");
            Assert(session.View.World.Data.ToJson() == constrained, "Conflicting head edit partially changed scene.");
            edit.Heads[0].ShowHead = false; session.ReplaceSelected(edit);
            Assert(session.View.World.HeadOccupied(0, 1) && session.View.World.Data.Elements[1].Position == Vector2.zero, "Disabling head moved the remaining connection.");
            edit.Heads[1].Center += Vector2.up * .2f; session.ReplaceSelected(edit);
            Assert(Mathf.Abs(session.View.World.Data.Elements[1].Position.y - .2f) < .00001f, "Manual coordinate head edit failed to carry follower.");
        }
        finally { UnityEngine.Object.DestroyImmediate(obj); }
    }
    private static void RuntimeInteractionChecks()
    {
        var rod = Shape(1, NeoShapeKind.Straight, Vector2.zero, NeoOperation.Slide);
        var clasp = Shape(2, NeoShapeKind.Clasp, Vector2.zero);
        var unrelated = Shape(3, NeoShapeKind.Ring, new Vector2(6, 3));
        using (var world = new NeoWorld(Level(rod, clasp, unrelated)))
        {
            int visibility = 0; world.VisibilityChanged += () => visibility++;
            world.BeginOperation(0); world.Move(0, Vector2.right * .1f, 0);
            Assert(world.ReleaseOperation(0) == 0 && world.Bodies[0].Active && world.Bodies[1].Active, "Connected component hidden on release.");
            world.BeginOperation(0); world.Move(0, Vector2.right * 3, 0);
            Assert(world.Bodies[0].Active && world.Bodies[1].Active, "Detached component hidden before pointer release.");
            Assert(world.ReleaseOperation(0) == 2 && !world.Bodies[0].Active && !world.Bodies[1].Active && world.Bodies[2].Active && visibility == 1, "Independent release hid wrong components.");
            Assert(world.Pick(world.Bodies[0].Data.Position) == -1 && world.Move(0, Vector2.left, 0) == 0, "Hidden component still interactive.");
        }
        var moving = Shape(11, NeoShapeKind.Straight, Vector2.zero, NeoOperation.Slide); moving.Width = 1;
        var obstacle = Shape(22, NeoShapeKind.Straight, new Vector2(3, 0), NeoOperation.Fixed); obstacle.Angle = 90;
        using (var world = new NeoWorld(Level(moving, obstacle)))
        {
            int events = 0; NeoCollision contact = default;
            world.Collided += value => { events++; contact = value; };
            float fraction = world.Move(0, Vector2.right * 5, 0);
            Assert(fraction < 1 && events == 1 && contact.FirstId == 11 && contact.SecondId == 22 && contact.FirstIndex == 0 && contact.SecondIndex == 1, "Collision event omitted pair.");
            var probe = new C.Part { Kind = WordTile.Game.GameCollisionKind.Capsule, A = new C.Point(contact.Point.x, contact.Point.y), B = new C.Point(contact.Point.x, contact.Point.y) };
            Assert(Math.Abs(C.Clearance(probe, world.Bodies[0].World[contact.FirstPart])) < .002 && Math.Abs(C.Clearance(probe, world.Bodies[1].World[contact.SecondPart])) < .002, "Collision point not near both surfaces.");
            world.Move(0, Vector2.right, 0); Assert(events == 1, "Stationary contact floods repeated events.");
            world.Move(0, Vector2.left * .5f, 0); world.Move(0, Vector2.right, 0);
            Assert(events == 2, "Recontact didn't emit collision.");
        }
        moving.Bombs = new[] { new NeoBomb { Id = 1, Position = Vector2.right, CenterOffset = Vector2.zero } };
        obstacle.Position = new Vector2(1.2f, 0); obstacle.Width = .3f; obstacle.Angle = 0;
        using (var world = new NeoWorld(Level(moving, obstacle)))
        {
            int events = 0; world.Collided += value => events++;
            Assert(world.ResolveInitialBombContacts() == 1 && events == 1 && !world.Bodies[0].Active && !world.Bodies[1].Active, "Initial bomb collision not emitted/hidden.");
            world.ResolveInitialBombContacts(); Assert(events == 1, "Consumed bomb collision repeated.");
        }
        var obj = new GameObject("Release visibility check");
        try
        {
            var view = obj.AddComponent<NeoLevelView>(); var session = new NeoLevelEditor(view, Level(rod, clasp));
            string original = view.World.Data.ToJson(); session.EnterPlay();
            view.World.BeginOperation(0); view.World.Move(0, Vector2.right * 3, 0); view.World.ReleaseOperation(0);
            Assert(view.GetComponentsInChildren<MeshRenderer>().Length == 0, "Release didn't hide rendered components.");
            session.ExitPlay(); Assert(view.GetComponentsInChildren<MeshRenderer>().Length == 2 && view.World.Data.ToJson() == original, "Trial exit didn't restore hidden components.");
        }
        finally { UnityEngine.Object.DestroyImmediate(obj); }
    }

    private static void CollisionChecks()
    {
        var ring = Shape(1, NeoShapeKind.Ring, Vector2.zero, NeoOperation.Fixed); ring.Radius = 3;
        var rod = Shape(2, NeoShapeKind.Seven, Vector2.zero, NeoOperation.Slide); rod.Width = rod.Height = 0.3f;
        using (var world = new NeoWorld(Level(ring, rod)))
        {
            Assert(world.CheckPlayable().Count == 0 && world.Pick(new Vector2(0, 1), 0) == -1, "Hollow ring is filled.");
            float t = world.Move(1, new Vector2(100, 0), 0);
            Assert(t > 0 && t < 0.04f, "Fast translation tunneled through hollow ring.");
            Assert(world.CheckPlayable().Count == 0, "Translation ended penetrating.");
            Assert(world.Move(1, new Vector2(-1, 0), 0) == 1, "Reverse translation stuck.");
            Assert(world.Move(0, Vector2.one, 90) == 0, "Fixed shape moved.");
        }
        var moving = Shape(1, NeoShapeKind.Gate, Vector2.zero); moving.Width = moving.Height = 2;
        var obstacle = Shape(2, NeoShapeKind.Clasp, new Vector2(1.45f, 0)); obstacle.ClaspLength = 0.2f; obstacle.ClaspWidth = 0.2f; obstacle.ChannelWidth = 0.1f;
        using (var world = new NeoWorld(Level(moving, obstacle)))
        {
            float t = world.Move(0, Vector2.zero, 180); Assert(t > 0 && t < 1, "Fast rotation tunneled.");
            Assert(world.CheckPlayable().Count == 0, "Rotation stopped penetrating.");
            Assert(world.Move(0, Vector2.zero, -15) > 0.99f, "Reverse rotation failed.");
        }
        var circle = Shape(1, NeoShapeKind.Ring, Vector2.zero); var outer = Shape(2, NeoShapeKind.Ring, Vector2.zero, NeoOperation.Fixed); outer.Radius = 2;
        using (var world = new NeoWorld(Level(circle, outer))) Assert(world.Move(0, Vector2.zero, 360) == 1, "Invariant ring rotation blocked.");
        var c = Shape(1, NeoShapeKind.C, Vector2.zero); c.StartAngle = 45; c.SweepAngle = 270;
        using (var world = new NeoWorld(Level(c)))
        { Assert(world.Pick(new Vector2(1, 0), 0.01f) == -1, "C opening blocked."); Assert(world.Pick(new Vector2(-1, 0), 0.01f) == 0, "C body missing."); }
    }

    private static void RelationChecks()
    {
        var owner = Shape(1, NeoShapeKind.Ring, new Vector2(-3, 0));
        owner.Heads = new[] { new NeoHead { Anchor = new Vector2(1, 0), Center = new Vector2(3, 0) }, new NeoHead { Anchor = new Vector2(1, 0), Center = new Vector2(3, -3) } };
        var body = Shape(2, NeoShapeKind.Gate, new Vector2(0, -1), NeoOperation.Slide); body.Width = 1; body.Height = 2; body.Thickness = 0.08f;
        var body2 = Shape(3, NeoShapeKind.Gate, new Vector2(0, -4), NeoOperation.Slide); body2.Width = 1; body2.Height = 2; body2.Thickness = 0.08f;
        using (var world = new NeoWorld(Level(owner, body, body2)))
        {
            Assert(world.Bodies[0].Locked && world.Bodies[0].LockCount == 2, "Two entering bodies did not lock owner.");
            Assert(world.HeadOccupied(0, 0) && world.HeadOccupied(0, 1), "Per-head occupancy missing.");
            Assert(world.Move(0, Vector2.zero, 10) == 0, "Locked owner rotated.");
            world.SetPose(1, new Vector2(5, -1), 0); Assert(world.Bodies[0].Locked && world.Bodies[0].LockCount == 1, "First exit unlocked too early.");
            world.SetPose(2, new Vector2(5, -4), 0); Assert(!world.Bodies[0].Locked, "Final exit didn't unlock.");
        }
        var clasp = Shape(1, NeoShapeKind.Clasp, Vector2.zero);
        using (var world = new NeoWorld(Level(clasp, body)))
        { Assert(world.ChannelOccupied(0, 1) && !world.Bodies[1].Locked, "Clasp occupancy incorrectly locks passing body."); }
        body.Thickness = 0.2795f;
        using (var world = new NeoWorld(Level(clasp, body))) Assert(world.CheckPlayable().Count > 0, "Unreliable narrow channel wasn't reported.");
        var blocked = Shape(1, NeoShapeKind.Ring, Vector2.zero); blocked.Heads = new[] { new NeoHead { Center = Vector2.right } };
        using (var world = new NeoWorld(Level(blocked))) Assert(world.CheckPlayable().Count > 0, "Self-blocked channel wasn't reported.");
        owner = Shape(1, NeoShapeKind.Ring, new Vector2(-8, 0), NeoOperation.Slide);
        owner.Heads = new[] { new NeoHead { Anchor = Vector2.right, Center = new Vector2(3, 0) } };
        var longRod = Shape(2, NeoShapeKind.Z, new Vector2(4, -2), NeoOperation.Fixed); longRod.Width = longRod.BottomWidth = 8; longRod.Height = 4; longRod.Thickness = 0.08f;
        using (var world = new NeoWorld(Level(owner, longRod)))
        {
            Assert(world.CheckPlayable().Count == 0 && !world.Bodies[0].Locked, "Channel sweep fixture is invalid.");
            float fraction = world.Move(0, new Vector2(10, 0), 0);
            Assert(fraction > 0 && fraction < 0.2f && world.Bodies[0].Locked, "Moving head skipped transient channel occupancy.");
        }
    }

    private static void ConnectionChecks()
    {
        foreach (NeoShapeKind kind in Enum.GetValues(typeof(NeoShapeKind)))
        {
            if (kind == NeoShapeKind.Clasp) continue;
            var element = Shape(1, kind, Vector2.zero);
            element.Heads = new[] { new NeoHead { Anchor = Vector2.zero, Center = Vector2.up, StemWidth = 0.2f } };
            using (var world = new NeoWorld(Level(element)))
            {
                var b = world.Bodies[0]; var stem = b.Geometry.Parts[b.Geometry.BodyCount];
                Assert(stem.Kind == WordTile.Game.GameCollisionKind.Box && b.Channels.Length == 1, "Square headed rod missing on " + kind);
                var probe = new C.Part { Kind = WordTile.Game.GameCollisionKind.Capsule, A = new C.Point(0.05, -0.05), B = new C.Point(0.05, -0.05) };
                Assert(C.Clearance(stem, probe) > 0, "Square root has a rounded bulge on " + kind);
            }
            element.Heads[0].ShowHead = false;
            using (var world = new NeoWorld(Level(element)))
            {
                var b = world.Bodies[0]; int start = b.Geometry.BodyCount;
                Assert(b.Channels.Length == 0 && b.Geometry.Parts.Length == start + 2 && !b.Locked, "Rod-only geometry generated a head/channel on " + kind);
                Assert(b.Geometry.Parts[start].Kind == WordTile.Game.GameCollisionKind.Box && b.Geometry.Parts[start + 1].Kind == WordTile.Game.GameCollisionKind.Capsule, "Flat-root/round-tip parts incorrect.");
                var tip = b.Geometry.Parts[start + 1];
                var inside = new C.Part { Kind = WordTile.Game.GameCollisionKind.Capsule, A = new C.Point(0.07, 1.07), B = new C.Point(0.07, 1.07) };
                var outside = new C.Part { Kind = WordTile.Game.GameCollisionKind.Capsule, A = new C.Point(0.099, 1.099), B = new C.Point(0.099, 1.099) };
                Assert(C.Clearance(tip, inside) < 0 && C.Clearance(tip, outside) > 0, "Bare rod tip isn't circular.");
                var copy = NeoLevelData.FromJson(world.Data.ToJson()); Assert(!copy.Elements[0].Heads[0].ShowHead, "Rod-only flag lost in JSON.");
            }
        }
        var straight = Shape(1, NeoShapeKind.Straight, Vector2.zero); straight.Width = 3;
        using (var world = new NeoWorld(Level(straight)))
            Assert(world.Bodies[0].Geometry.BodyCount == 1 && world.Pick(new Vector2(1.4f, 0), 0) == 0 && world.Pick(new Vector2(0, 1), 0) == -1, "Straight length/picking is incorrect.");
        var clasp = Shape(1, NeoShapeKind.Clasp, Vector2.zero); clasp.Heads = new[] { new NeoHead { ShowHead = false } };
        Reject(() => Level(clasp).Validate(), "Clasp accepted an attachment.");
        straight.Heads = new[] { new NeoHead { ShowHead = false, Anchor = Vector2.zero, Center = Vector2.up }, new NeoHead { Anchor = Vector2.zero, Center = new Vector2(2, 1) } };
        using (var world = new NeoWorld(Level(straight))) Assert(world.Bodies[0].Channels.Length == 1 && !world.HeadOccupied(0, 0), "Mixed rod/head channel indices are invalid.");
        var entering = Shape(2, NeoShapeKind.Gate, new Vector2(2, 0)); entering.Width = 1; entering.Height = 2; entering.Thickness = 0.08f;
        using (var world = new NeoWorld(Level(straight, entering)))
            Assert(!world.HeadOccupied(0, 0) && world.HeadOccupied(0, 1) && world.IsChannelOccupied(0, 0), "Rod-only entry shifted connection index of the real head.");
        string legacy = JsonUtility.ToJson(NeoAuthoringDefaults.Example()).Replace("\"ShowHead\":true,", "");
        Assert(NeoLevelData.FromJson(legacy).Elements[0].Heads[0].ShowHead, "Old levels lost heads when ShowHead was absent.");
    }

    private static void BombChecks()
    {
        var owner = Shape(1, NeoShapeKind.Ring, Vector2.zero, NeoOperation.Fixed); owner.Radius = 0.4f;
        owner.Bombs = new[] { new NeoBomb { Id = 1, Position = new Vector2(2, 0), CenterOffset = Vector2.zero } };
        var other = Shape(2, NeoShapeKind.Straight, new Vector2(10, 0), NeoOperation.Slide); other.Width = 0.2f;
        using (var world = new NeoWorld(Level(owner, other)))
        {
            int events = 0; NeoExplosion explosion = default(NeoExplosion);
            world.Exploded += e => { events++; explosion = e; Assert(world.Bodies[0].BombSpent[0] && !world.Bodies[0].Active && !world.Bodies[1].Active, "Bomb event saw uncommitted state."); };
            Assert(world.ResolveInitialBombContacts() == 0, "Bomb exploded on its own owner.");
            float fraction = world.Move(1, new Vector2(-100, 0), 0);
            Assert(fraction > 0 && fraction < 0.1f && events == 1, "Fast bomb hit missed.");
            Assert(explosion.OwnerId == 1 && explosion.BombId == 1 && explosion.OtherId == 2 && explosion.OtherBombId == 0, "Explosion identity incorrect.");
            Assert(world.Pick(new Vector2(2, 0)) == -1 && world.Move(1, Vector2.right, 0) == 0 && world.ResolveInitialBombContacts() == 0, "Consumed bodies remained interactive.");
        }
        owner.Operation = NeoOperation.Rotate;
        other.Position = new Vector2(0, 2.2f); other.Operation = NeoOperation.Fixed;
        using (var world = new NeoWorld(Level(owner, other)))
            Assert(world.Move(0, Vector2.zero, 90) < 1 && world.Bodies[0].BombSpent[0] && !world.Bodies[1].Active, "Rotating bomb tunneled.");
        owner.Operation = NeoOperation.Fixed; other.Position = new Vector2(10, 0); other.Operation = NeoOperation.Slide;
        other.Bombs = new[] { new NeoBomb { Id = 9, Position = new Vector2(-2, 0), CenterOffset = Vector2.zero } };
        using (var world = new NeoWorld(Level(owner, other)))
        {
            int events = 0;
            world.Exploded += e => { events++; Assert(e.OtherBombId > 0 && world.Bodies[0].BombSpent[0] && world.Bodies[1].BombSpent[0], "Bomb pair not consumed before notification."); };
            world.Move(1, new Vector2(-100, 0), 0); Assert(events == 1, "Bomb pair emitted wrong event count.");
        }
        other.Bombs = Array.Empty<NeoBomb>();
        var wall = Shape(3, NeoShapeKind.Clasp, new Vector2(5, 0)); wall.ClaspWidth = 1; wall.ChannelWidth = 0.1f;
        using (var world = new NeoWorld(Level(owner, other, wall)))
        {
            world.Move(1, new Vector2(-100, 0), 0);
            Assert(world.Bodies[0].Active && world.Bodies[1].Active && !world.Bodies[0].BombSpent[0] && world.LastObstacleId == 3, "Wall before bomb ignored.");
        }
        owner.Operation = NeoOperation.Slide;
        using (var world = new NeoWorld(Level(owner, wall)))
        {
            world.Move(0, new Vector2(100, 0), 0);
            Assert(world.Bodies[0].Active && !world.Bodies[0].BombSpent[0] && world.LastObstacleId == 3, "Clasp detonated a bomb.");
        }
        other.Position = new Vector2(2, 0); other.Operation = NeoOperation.Fixed;
        using (var world = new NeoWorld(Level(owner, other)))
        {
            Assert(world.CheckPlayable().Count == 0, "Initial bomb contact blocked authoring trial.");
            int events = 0;
            world.Exploded += e => { events++; Assert(world.ResolveInitialBombContacts() == 0, "Reentrant detonation duplicated."); };
            Assert(world.ResolveInitialBombContacts() == 1 && events == 1, "Initial bomb overlap didn't detonate.");
        }
        other.Kind = NeoShapeKind.Ring; other.Radius = 2; other.Position = new Vector2(2, 0);
        using (var world = new NeoWorld(Level(owner, other))) Assert(world.ResolveInitialBombContacts() == 0, "Bomb in hollow ring exploded.");
        owner.Bombs[0].Enabled = false;
        using (var world = new NeoWorld(Level(owner))) Assert(world.Bodies[0].World.Length == world.Bodies[0].Geometry.SolidPartCount && world.Pick(new Vector2(2, 0)) == -1, "Disabled bomb remained collidable.");
        owner.Bombs[0].Enabled = true; owner.Scale = 3; owner.Angle = 90; owner.Position = new Vector2(4, 5);
        var bomb = owner.Bombs[0]; bomb.Position = Vector2.right; bomb.Angle = 90; bomb.Scale = 2; bomb.CenterOffset = new Vector2(0.1f, 0); bomb.ImageWidth = 10;
        using (var world = new NeoWorld(Level(owner)))
        {
            var part = world.Bodies[0].World[world.Bodies[0].Geometry.SolidPartCount];
            Assert(Math.Abs(part.A.X - 3.4) < 0.00001 && Math.Abs(part.A.Y - 8) < 0.00001 && Math.Abs(part.Radius - 1.2) < 0.00001, "Bomb pose/offset/scale or image independence incorrect.");
            var copy = NeoLevelData.FromJson(world.Data.ToJson()); Assert(copy.Elements[0].Bombs[0].ImageWidth == 10 && copy.Elements[0].Bombs[0].Enabled, "Bomb parameters lost in JSON.");
        }
        var invalid = NeoAuthoringDefaults.Example(); invalid.Elements[0].Bombs[0].Radius = 0; Reject(invalid.Validate, "Zero bomb radius accepted.");
        invalid = NeoAuthoringDefaults.Example(); invalid.Elements[0].Bombs = new[] { new NeoBomb { Id = 1 }, new NeoBomb { Id = 1 } }; Reject(invalid.Validate, "Duplicate local bomb IDs accepted.");
        var clasp = Shape(1, NeoShapeKind.Clasp, Vector2.zero); clasp.Bombs = new[] { new NeoBomb { Id = 1 } }; Reject(() => Level(clasp).Validate(), "Clasp accepted a bomb.");
        Assert(NeoLevelData.FromJson("{\"Version\":1,\"Elements\":[{\"Id\":1,\"Heads\":[]}]}").Elements[0].Bombs.Length == 0, "Old level without Bombs didn't load.");
        var locked = Shape(1, NeoShapeKind.Ring, new Vector2(-3, 0)); locked.Heads = new[] { new NeoHead { Anchor = Vector2.right, Center = new Vector2(3, 0) } };
        var passing = Shape(2, NeoShapeKind.Straight, Vector2.zero); passing.Width = 0.3f; passing.Thickness = 0.08f;
        var carrier = Shape(3, NeoShapeKind.Ring, new Vector2(0, 4)); carrier.Bombs = new[] { new NeoBomb { Id = 1, Position = new Vector2(0, -4), CenterOffset = Vector2.zero, Radius = 0.03f } };
        using (var world = new NeoWorld(Level(locked, passing, carrier)))
        {
            Assert(world.Bodies[0].Locked, "Bomb unlock fixture isn't occupied."); world.ResolveInitialBombContacts();
            Assert(world.Bodies[0].Active && !world.Bodies[0].Locked && !world.Bodies[1].Active && !world.Bodies[2].Active, "Explosion didn't remove occupancy locks.");
        }
    }

    private static void GroupChecks()
    {
        var a = Shape(1, NeoShapeKind.Ring, new Vector2(-6, 0), NeoOperation.Fixed);
        a.Heads = new[] { new NeoHead { Anchor = Vector2.right, Center = new Vector2(3, 0) } };
        var b = Shape(2, NeoShapeKind.Straight, new Vector2(-3, 0), NeoOperation.Slide); b.Width = 0.4f; b.Thickness = 0.08f; b.MovementAxis = Vector2.up;
        b.Heads = new[] { new NeoHead { Anchor = Vector2.zero, Center = new Vector2(3, 0) } };
        b.Bombs = new[] { new NeoBomb { Id = 1, Position = new Vector2(0, 0.8f), CenterOffset = Vector2.zero } };
        var c = Shape(3, NeoShapeKind.Straight, Vector2.zero, NeoOperation.Fixed); c.Width = 0.4f; c.Thickness = 0.08f; c.Angle = 90;
        c.Heads = new[] { new NeoHead { Anchor = Vector2.zero, Center = new Vector2(0, 3), Angle = -90 }, new NeoHead { Anchor = Vector2.zero, Center = new Vector2(0, 5), Angle = -90 } };
        var unrelated = Shape(4, NeoShapeKind.Ring, new Vector2(5, 4));
        var clasp = Shape(5, NeoShapeKind.Clasp, new Vector2(-3, 0));
        var source = Level(a, b, c, unrelated, clasp);
        var left = Shape(2, NeoShapeKind.Straight, new Vector2(-0.2f, 0)); left.Width = 0.2f; left.Thickness = 0.08f;
        var right = Shape(3, NeoShapeKind.Straight, new Vector2(0.2f, 0)); right.Width = 0.2f; right.Thickness = 0.08f;
        right.Heads = new[] { new NeoHead { Center = new Vector2(2, 0), Anchor = Vector2.zero } };
        var last = Shape(4, NeoShapeKind.Straight, new Vector2(2.2f, 0)); last.Width = 0.2f; last.Thickness = 0.08f;
        using (var world = new NeoWorld(Level(Shape(1, NeoShapeKind.Clasp, Vector2.zero), left, right, last)))
        {
            Assert(world.ChannelOccupied(0, 1) && world.ChannelOccupied(0, 2) && world.ChannelOccupied(2, 3), "Shared-clasp chain fixture incorrect.");
            Assert(world.GetDependencyGroup(1).Length == 4 && world.GetDependencyGroup(0).Length == 4, "Clasp didn't bridge its occupants and their downstream dependencies.");
        }
        using (var world = new NeoWorld(source))
        {
            Assert(world.ChannelOccupied(0, 1) && world.ChannelOccupied(1, 2) && world.ChannelOccupied(2, 0) && world.ChannelOccupied(2, 1), "Dependency cycle fixture incorrect.");
            Assert(world.ChannelOccupied(4, 1), "Clasp dependency fixture isn't occupied.");
            for (int selected = 0; selected < 3; selected++)
            {
                var group = world.GetDependencyGroup(selected);
                Assert(group.Length == 4 && Array.IndexOf(group, 0) >= 0 && Array.IndexOf(group, 1) >= 0 && Array.IndexOf(group, 2) >= 0 && Array.IndexOf(group, 4) >= 0, "Bidirectional transitive/cyclic group or occupied clasp missing.");
            }
            Assert(world.GetDependencyGroup(3).Length == 1 && world.GetDependencyGroup(4).Length == 4, "Unrelated element joined group or clasp selection missed dependents.");
            var members = world.GetDependencyGroup(1); var mesh = world.Bodies[1].Geometry.Mesh;
            string original = world.Data.ToJson();
            Reject(() => world.TranslateGroup(members, new Vector2(10001, 0)), "Out-of-bounds group translation accepted.");
            Assert(world.Data.ToJson() == original, "Failed group translation partially changed layout.");
            Reject(() => world.TranslateGroup(new[] { 0, 0 }, Vector2.one), "Duplicate group member accepted.");
            Assert(world.Data.ToJson() == original, "Duplicate member rejection changed layout.");
            int explosions = 0; world.Exploded += e => explosions++;
            Vector2 bombPosition = new Vector2((float)world.Bodies[1].World[world.Bodies[1].Geometry.SolidPartCount].A.X, (float)world.Bodies[1].World[world.Bodies[1].Geometry.SolidPartCount].A.Y);
            world.TranslateGroup(members, new Vector2(2.25f, 1.75f));
            for (int i = 0; i < source.Elements.Length; i++)
            {
                var e = world.Data.Elements[i]; Vector2 expected = source.Elements[i].Position + (i != 3 ? new Vector2(2.25f, 1.75f) : Vector2.zero);
                Assert(e.Position == expected && e.Angle == source.Elements[i].Angle && e.Scale == source.Elements[i].Scale && e.Operation == source.Elements[i].Operation && e.MovementAxis == source.Elements[i].MovementAxis, "Group translation changed pose/configuration or moved an outsider.");
            }
            var bombPart = world.Bodies[1].World[world.Bodies[1].Geometry.SolidPartCount];
            Assert(Vector2.Distance(new Vector2((float)bombPart.A.X, (float)bombPart.A.Y), bombPosition + new Vector2(2.25f, 1.75f)) < 0.00001f && explosions == 0 && !world.Bodies[1].BombSpent[0], "Attached bomb failed to follow safely in authoring.");
            Assert(world.Bodies[1].Geometry.Mesh == mesh && world.GetDependencyGroup(0).Length == 4 && world.ChannelOccupied(4, 1), "Group motion rebuilt Mesh or lost clasp/internal relationships.");
        }
        var obj = new GameObject("NeoRing group history test");
        try
        {
            var view = obj.AddComponent<NeoLevelView>(); var session = new NeoLevelEditor(view, source); session.Selected = 1;
            string original = view.World.Data.ToJson(); session.BeginGesture(true);
            Assert(session.GestureGroupCount == 4 && session.IsGestureMember(0) && session.IsGestureMember(4) && !session.IsGestureMember(3), "Captured gesture group incorrect.");
            session.TranslateSelectedDependencies(new Vector2(2.5f, 1.25f)); session.TranslateSelectedDependencies(new Vector2(-0.25f, 0.5f)); session.EndGesture();
            string moved = view.World.Data.ToJson();
            Assert(session.GestureGroupCount == 0 && moved != original, "Group gesture didn't finish.");
            for (int i = 0; i < source.Elements.Length; i++)
            {
                var filter = view.GetComponentsInChildren<MeshFilter>()[i];
                Assert((Vector2)filter.transform.localPosition == view.World.Data.Elements[i].Position, "Grouped rendered transform didn't sync.");
            }
            session.Undo(); Assert(view.World.Data.ToJson() == original && !session.CanUndo, "Group drag wasn't one undo step.");
            session.Redo(); Assert(view.World.Data.ToJson() == moved, "Group redo incomplete.");
            session.Apply(NeoAuthoringDefaults.Example()); session.Selected = 0; session.EnterPlay();
            bool rejected = false; try { session.TranslateSelectedDependencies(Vector2.one); } catch (InvalidOperationException) { rejected = true; }
            Assert(rejected, "Dependency authoring bypass used in trial play."); session.ExitPlay();
        }
        finally { UnityEngine.Object.DestroyImmediate(obj); }
    }

    private static void EditorChecks()
    {
        var obj = new GameObject("NeoRing session test");
        try
        {
            var view = obj.AddComponent<NeoLevelView>(); var session = new NeoLevelEditor(view, NeoAuthoringDefaults.Example()); session.Selected = 0;
            string original = view.World.Data.ToJson(); session.BeginGesture();
            session.SetSelectedPose(new Vector2(-3, 2), 15); session.SetSelectedPose(new Vector2(-2.8f, 2), 25); session.EndGesture();
            string moved = view.World.Data.ToJson(); session.Undo(); Assert(view.World.Data.ToJson() == original, "Gesture undo incomplete.");
            session.Redo(); Assert(view.World.Data.ToJson() == moved, "Gesture redo incomplete."); session.Undo();
            var edit = JsonUtility.FromJson<NeoElement>(JsonUtility.ToJson(view.World.Data.Elements[0])); edit.Radius = 0;
            Reject(() => session.ReplaceSelected(edit), "Invalid parameter accepted."); Assert(view.World.Data.ToJson() == original, "Invalid edit destroyed valid level.");
            edit.Radius = 0.8f; session.ReplaceSelected(edit); session.Undo(); Assert(view.World.Data.ToJson() == original, "Dimension undo failed.");
            session.Duplicate(); Assert(view.World.Data.Elements.Length == 8 && view.World.Data.Elements[7].Id == 8, "Duplicate failed.");
            Assert(session.Selected == 7 && !ReferenceEquals(view.World.Data.Elements[0].Heads[0], view.World.Data.Elements[7].Heads[0]) && !ReferenceEquals(view.World.Data.Elements[0].Bombs[0], view.World.Data.Elements[7].Bombs[0]) && view.World.Bodies[0].Geometry.Mesh == view.World.Bodies[7].Geometry.Mesh, "Copy must have independent data but share identical generated geometry.");
            var copied = JsonUtility.FromJson<NeoElement>(JsonUtility.ToJson(view.World.Data.Elements[7])); copied.Radius = 0.7f; copied.Heads[0].StemWidth = 0.1f; copied.Bombs[0].Radius = 0.1f;
            session.ReplaceSelected(copied);
            Assert(view.World.Data.Elements[0].Radius == 1 && view.World.Data.Elements[0].Heads[0].StemWidth == 0.16f && view.World.Data.Elements[0].Bombs[0].Radius == 0.2f, "Editing copy changed original.");
            session.Undo(); session.Undo(); Assert(view.World.Data.Elements.Length == 7, "Copy creation/edit undo incomplete.");
            session.Redo(); session.Redo(); Assert(view.World.Data.Elements.Length == 8 && view.World.Data.Elements[7].Radius == 0.7f, "Copy creation/edit redo incomplete.");
            session.Delete(); Assert(view.World.Data.Elements.Length == 7, "Delete failed."); session.Undo(); Assert(view.World.Data.Elements.Length == 8, "Delete undo failed.");
            session.Apply(NeoAuthoringDefaults.Example()); string before = view.World.Data.ToJson();
            session.EnterPlay(); view.World.SetPose(0, new Vector2(10, 10), 90); session.ExitPlay();
            Assert(view.World.Data.ToJson() == before, "Trial mutated draft.");
            var bombEdit = JsonUtility.FromJson<NeoElement>(JsonUtility.ToJson(view.World.Data.Elements[0]));
            bombEdit.Bombs[0].Radius = 0.3f; session.Selected = 0; session.ReplaceSelected(bombEdit); session.Undo();
            Assert(view.World.Data.Elements[0].Bombs[0].Radius == 0.2f, "Bomb parameter undo failed.");
            bombEdit.Bombs = Array.Empty<NeoBomb>(); session.ReplaceSelected(bombEdit); session.Undo();
            Assert(view.World.Data.Elements[0].Bombs.Length == 1, "Bomb delete undo failed.");
            var blast = Shape(1, NeoShapeKind.Ring, Vector2.zero); blast.Bombs = new[] { new NeoBomb { Id = 1, Position = new Vector2(3, 0), CenterOffset = Vector2.zero } };
            var target = Shape(2, NeoShapeKind.Straight, new Vector2(3, 0)); target.Width = 0.2f;
            session.Apply(Level(blast, target)); string bombDraft = view.World.Data.ToJson(); session.EnterPlay();
            Assert(!view.World.Bodies[0].Active && view.GetComponentsInChildren<SpriteRenderer>().Length == 0, "Exploded visual remained active."); session.ExitPlay();
            Assert(view.World.Data.ToJson() == bombDraft && view.World.Bodies[0].Active && !view.World.Bodies[0].BombSpent[0], "Trial consumed editor bomb.");
            var overlapping = NeoAuthoringDefaults.Example(); overlapping.Elements[1].Position = overlapping.Elements[0].Position;
            session.Apply(overlapping); Reject(session.EnterPlay, "Solid overlap entered trial."); Assert(!session.Playing, "Failed trial changed mode.");
            var badResource = NeoAuthoringDefaults.Example(); badResource.MaterialId = "missing";
            string valid = view.World.Data.ToJson(); Reject(() => session.Apply(badResource), "Unknown resource accepted."); Assert(view.World.Data.ToJson() == valid, "Failed resource load lost previous level.");
        }
        finally { UnityEngine.Object.DestroyImmediate(obj); }
    }

    private static void Benchmark()
    {
        var shapes = new NeoElement[100];
        for (int i = 0; i < 100; i++)
        {
            shapes[i] = Shape(i + 1, NeoShapeKind.Ring, new Vector2((i % 10) * 3, (i / 10) * 3), NeoOperation.Slide);
            shapes[i].Bombs = new[] { new NeoBomb { Id = 1, Position = new Vector2(0, 1.4f), CenterOffset = Vector2.zero } };
        }
        var timer = Stopwatch.StartNew();
        using (var world = new NeoWorld(Level(shapes)))
        {
            double load = timer.Elapsed.TotalMilliseconds;
            Assert(Array.TrueForAll(world.Bodies, b => b.Geometry.Mesh == world.Bodies[0].Geometry.Mesh), "100 repeated rings didn't share one mesh.");
            for (int i = 0; i < 20; i++) world.Move(0, new Vector2(i % 2 == 0 ? 0.01f : -0.01f, 0), 0);
            timer.Restart(); long before = GC.GetAllocatedBytesForCurrentThread();
            for (int i = 0; i < 1000; i++) world.Move(0, new Vector2(i % 2 == 0 ? 0.01f : -0.01f, 0), 0);
            long bytes = GC.GetAllocatedBytesForCurrentThread() - before; timer.Stop();
            Assert(bytes == 0, "Steady-state motion allocated " + bytes + " bytes.");
            UnityEngine.Debug.Log("NEORING_PERF: 100 rings + 100 bombs load=" + load.ToString("0.00") + "ms; 1000 moves=" + timer.Elapsed.TotalMilliseconds.ToString("0.00") + "ms; allocations=" + bytes);
        }
    }

    private static NeoRingEditorWindow editorWindow;
    private static NeoLevelEditor editorSession;
    private static SceneView editorCanvas;
    private static Vector2 widthHandle, rotationTarget;
    private static bool testRotation;
    private static int editorPhase;
    private static void CaptureHandle(SceneView scene)
    {
        if (scene != editorCanvas || editorSession == null) return;
        var e = editorSession.View.World.Data.Elements[2];
        Vector2 point = e.Position + NeoConnection.Rotate(new Vector2(e.Width / 2, e.Height / 2) * e.Scale, e.Angle);
        // Unity 2022 Windows SendEvent uses outer dock coordinates (tab + toolbar).
        if (testRotation)
        {
            float radius = Mathf.Max(.5f, (float)editorSession.View.World.Bodies[2].Geometry.MotionRadius * e.Scale + .3f);
            point = e.Position + NeoConnection.Rotate(Vector2.right * radius, 45);
            rotationTarget = HandleUtility.WorldToGUIPoint(e.Position + NeoConnection.Rotate(Vector2.right * radius, 135)) + new Vector2(1, 45);
        }
        widthHandle = HandleUtility.WorldToGUIPoint(point) + new Vector2(1, 45);
    }
    public static void Run()
    {
        try
        {
            Core();
            Assert(typeof(NeoLevelEditor).Assembly != typeof(NeoWorld).Assembly && typeof(NeoLevelPlayer).Assembly == typeof(NeoWorld).Assembly, "Editor/runtime assemblies not separated.");
            editorWindow = NeoRingEditorWindow.OpenLevel("Assets/NeoRing/Levels/Example.json");
            var flags = System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic;
            editorSession = (NeoLevelEditor)typeof(NeoRingEditorWindow).GetField("session", flags).GetValue(editorWindow);
            editorCanvas = (SceneView)typeof(NeoRingEditorWindow).GetField("canvas", flags).GetValue(editorWindow);
            editorSession.Selected = 2; editorCanvas.Repaint(); frames = 0; editorPhase = 0; testRotation = false;
            SceneView.duringSceneGui += CaptureHandle; EditorApplication.update += EditorCheck;
        }
        catch (Exception ex) { UnityEngine.Debug.LogException(ex); EditorApplication.Exit(1); }
    }
    private static void EditorCheck()
    {
        if (++frames < 20) return;
        try
        {
            if (editorPhase == 0)
            {
                Assert(editorCanvas != null && editorSession.View.World.Bodies.Length == 7, "Native editor preview failed.");
                editorCanvas.SendEvent(new Event { type = EventType.MouseMove, mousePosition = widthHandle }); editorCanvas.Repaint();
                frames = 0; editorPhase = 1; return;
            }
            if (editorPhase == 1)
            {
                var point = widthHandle;
                editorCanvas.Focus();
                editorCanvas.SendEvent(new Event { type = EventType.Layout, mousePosition = point });
                editorCanvas.SendEvent(new Event { type = EventType.MouseDown, button = 0, clickCount = 1, mousePosition = point });
                editorCanvas.SendEvent(new Event { type = EventType.MouseDrag, button = 0, mousePosition = point + Vector2.right * 40, delta = Vector2.right * 40 });
                editorCanvas.SendEvent(new Event { type = EventType.MouseUp, button = 0, mousePosition = point + Vector2.right * 40 });
                frames = 0; editorPhase = 2; return;
            }
            if (editorPhase == 2)
            {
                Assert(editorSession.View.World.Data.Elements[2].Width > 2.1f, "Scene mouse handle did not resize Gate width.");
                editorSession.Undo(); Assert(Mathf.Abs(editorSession.View.World.Data.Elements[2].Width - 2) < .001f, "Mouse resize undo failed.");
                testRotation = true; frames = 0; editorPhase = 3; editorCanvas.Repaint(); return;
            }
            if (editorPhase == 3)
            {
                editorCanvas.SendEvent(new Event { type = EventType.Layout, mousePosition = widthHandle });
                editorCanvas.SendEvent(new Event { type = EventType.MouseDown, button = 0, clickCount = 1, mousePosition = widthHandle });
                editorCanvas.SendEvent(new Event { type = EventType.MouseDrag, button = 0, mousePosition = rotationTarget, delta = rotationTarget - widthHandle });
                editorCanvas.SendEvent(new Event { type = EventType.MouseUp, button = 0, mousePosition = rotationTarget });
                frames = 0; editorPhase = 4; return;
            }
            Assert(Mathf.Abs(Mathf.DeltaAngle(editorSession.View.World.Data.Elements[2].Angle, 90)) < .01f, "Scene mouse rotation didn't turn Gate 90 degrees.");
            editorSession.Undo(); Assert(Mathf.Abs(editorSession.View.World.Data.Elements[2].Angle) < .01f, "Mouse rotation undo failed.");
            Vector3 pivot = editorCanvas.pivot; string beforePan = editorSession.View.World.Data.ToJson();
            var panPoint = new Vector2(150, 195);
            editorCanvas.SendEvent(new Event { type = EventType.MouseDown, button = 1, mousePosition = panPoint });
            editorCanvas.SendEvent(new Event { type = EventType.MouseDrag, button = 1, mousePosition = panPoint + Vector2.right * 30, delta = Vector2.right * 30 });
            editorCanvas.SendEvent(new Event { type = EventType.MouseUp, button = 1, mousePosition = panPoint + Vector2.right * 30 });
            Assert((editorCanvas.pivot - pivot).sqrMagnitude > .01f && beforePan == editorSession.View.World.Data.ToJson(), "Right mouse pan failed or changed level geometry.");
            editorCanvas.pivot = pivot;
            var texture = new RenderTexture(900, 700, 24); texture.Create();
            if (GraphicsSettings.currentRenderPipeline != null)
                RenderPipeline.SubmitRenderRequest(editorCanvas.camera, new UniversalRenderPipeline.SingleCameraRequest { destination = texture });
            else { editorCanvas.camera.targetTexture = texture; editorCanvas.camera.Render(); editorCanvas.camera.targetTexture = null; }
            RenderTexture.active = texture; var pixels = new Texture2D(900, 700, TextureFormat.RGB24, false);
            pixels.ReadPixels(new Rect(0, 0, 900, 700), 0, 0); pixels.Apply(); RenderTexture.active = null;
            Directory.CreateDirectory("Output"); File.WriteAllBytes("Output/NeoRing-editor-preview.png", pixels.EncodeToPNG());
            int visible = 0; foreach (var color in pixels.GetPixels()) if (Mathf.Max(color.r, color.g, color.b) > .4f) visible++;
            Assert(visible > 1000, "Native editor preview geometry not visible.");
            UnityEngine.Object.DestroyImmediate(pixels); texture.Release(); UnityEngine.Object.DestroyImmediate(texture);
            SceneView.duringSceneGui -= CaptureHandle; editorWindow.Close();
            EditorApplication.update -= EditorCheck;
            NeoRingMenus.BuildScene(); NeoRingMenus.ShowGameView();
            UnityEngine.Debug.Log("NEORING_EDITOR_PASS: separated assemblies, isolated preview, native mouse Gate resize/rotation, gesture undo.");
            SessionState.SetBool("NeoRing.Check", true); EditorApplication.EnterPlaymode();
        }
        catch (Exception ex) { UnityEngine.Debug.LogException(ex); EditorApplication.update -= EditorCheck; EditorApplication.Exit(1); }
    }
    public static void RunCatch()
    {
        try { Core(); NeoRingMenus.BuildCatchScene(); NeoRingMenus.ShowGameView(); SessionState.SetBool("NeoRing.Check", true); EditorApplication.EnterPlaymode(); }
        catch (Exception ex) { UnityEngine.Debug.LogException(ex); EditorApplication.Exit(1); }
    }
    private static void PlayCheck()
    {
        if (++frames < 45) return;
        try
        {
            var player = UnityEngine.Object.FindFirstObjectByType<NeoLevelPlayer>();
            Assert(player != null && player.GetComponent<NeoLevelView>().World != null, "Standalone player didn't load JSON.");
            var view = player.GetComponent<NeoLevelView>();
            Assert(player.GetComponents<MonoBehaviour>().Length == 2, "Runtime scene contains editing behaviours.");
            foreach (var body in view.World.Bodies) Assert(body.Geometry.Mesh != null && !AssetDatabase.Contains(body.Geometry.Mesh), "Generated mesh became asset.");
            Assert(Array.TrueForAll(view.World.Bodies, body => !body.Geometry.Mesh.isReadable), "Player retained CPU copies of generated render meshes.");
            var target = new RenderTexture(900, 700, 24); target.Create();
            if (GraphicsSettings.currentRenderPipeline != null)
                RenderPipeline.SubmitRenderRequest(player.Camera, new UniversalRenderPipeline.SingleCameraRequest { destination = target });
            else { player.Camera.targetTexture = target; player.Camera.Render(); player.Camera.targetTexture = null; }
            RenderTexture.active = target; var pixels = new Texture2D(900, 700, TextureFormat.RGB24, false);
            pixels.ReadPixels(new Rect(0, 0, 900, 700), 0, 0); pixels.Apply(); RenderTexture.active = null;
            int colorful = 0; foreach (var color in pixels.GetPixels()) if (Mathf.Max(color.r, color.g, color.b) - Mathf.Min(color.r, color.g, color.b) > .15f) colorful++;
            Assert(colorful > 1000, "Standalone gameplay rendering failed.");
            Directory.CreateDirectory("Output"); File.WriteAllBytes("Output/NeoRing-player-preview-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fff") + ".png", pixels.EncodeToPNG());
            var red = Shape(1, NeoShapeKind.Ring, new Vector2(-2, 0)); red.Color = Color.red;
            var green = Shape(2, NeoShapeKind.Ring, new Vector2(2, 0)); green.Color = Color.green;
            view.Load(Level(red, green));
            player.Camera.aspect = 900f / 700f;
            Assert(view.World.Bodies[0].Geometry.Mesh == view.World.Bodies[1].Geometry.Mesh, "Rendered different colors didn't share a mesh.");
            if (GraphicsSettings.currentRenderPipeline != null)
                RenderPipeline.SubmitRenderRequest(player.Camera, new UniversalRenderPipeline.SingleCameraRequest { destination = target });
            else { player.Camera.targetTexture = target; player.Camera.Render(); player.Camera.targetTexture = null; }
            RenderTexture.active = target; pixels.ReadPixels(new Rect(0, 0, 900, 700), 0, 0); pixels.Apply(); RenderTexture.active = null;
            var left = player.Camera.WorldToViewportPoint(view.transform.TransformPoint(new Vector3(-2, 1, 0)));
            var right = player.Camera.WorldToViewportPoint(view.transform.TransformPoint(new Vector3(2, 1, 0)));
            var redPixel = pixels.GetPixel((int)(left.x * 900), (int)(left.y * 700));
            var greenPixel = pixels.GetPixel((int)(right.x * 900), (int)(right.y * 700));
            File.WriteAllBytes("Output/NeoRing-instance-colors-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fff") + ".png", pixels.EncodeToPNG());
            Assert(redPixel.r > .2f && redPixel.g < .1f && greenPixel.g > .2f && greenPixel.r < .1f, "Shared mesh instance colors rendered incorrectly: " + redPixel + "; " + greenPixel);
            UnityEngine.Debug.Log("NEORING_INSTANCE_COLORS_PASS: same mesh/material, red and green rendered correctly; hardware instancing support=" + SystemInfo.supportsInstancing);
            UnityEngine.Object.Destroy(pixels); target.Release(); UnityEngine.Object.Destroy(target);
            UnityEngine.Debug.Log("NEORING_PLAY_PASS: standalone runtime player, JSON load, generated meshes, rendered pixels=" + colorful);
            EditorApplication.update -= PlayCheck; EditorApplication.update += Finish;
        }
        catch (Exception ex) { UnityEngine.Debug.LogException(ex); SessionState.SetBool("NeoRing.Check", false); EditorApplication.update -= PlayCheck; EditorApplication.Exit(1); }
    }
    private static void Finish()
    {
        if (++frames < 55) return;
        SessionState.SetBool("NeoRing.Check", false); EditorApplication.update -= Finish;
        UnityEngine.Debug.Log("NEORING_ALL_PASS"); EditorApplication.Exit(0);
    }
}

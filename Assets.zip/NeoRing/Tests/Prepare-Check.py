"""Prepare a native Unity/URP check under Temp; leaves the main scene/settings untouched."""
import json
import shutil
from pathlib import Path

root = Path(__file__).resolve().parents[3]
project = root / "Temp/NeoRingCheck"
(project / "Assets/Game").mkdir(parents=True, exist_ok=True)
(project / "Packages").mkdir(exist_ok=True)
(project / "ProjectSettings").mkdir(exist_ok=True)
stale_editing = project / "Assets/NeoRing/Runtime/Editing"
if stale_editing.exists():
    assert stale_editing.resolve().is_relative_to(project.resolve())
    shutil.rmtree(stale_editing)
stale_meta = Path(str(stale_editing) + ".meta")
if stale_meta.exists():
    stale_meta.unlink()
legacy_editor = project / "Assets/NeoRing/Editor/Authoring/NeoRingWorkbench.cs"
if legacy_editor.exists():
    legacy_editor.unlink()
legacy_meta = Path(str(legacy_editor) + ".meta")
if legacy_meta.exists():
    legacy_meta.unlink()
shutil.copytree(root / "Assets/NeoRing", project / "Assets/NeoRing", dirs_exist_ok=True)
for name in ("catch.png", "catch.png.meta"):
    shutil.copyfile(root / "Assets" / name, project / "Assets" / name)
shutil.copyfile(root / "Assets/Game/GameCollision2D.cs", project / "Assets/Game/GameCollision2D.cs")
shutil.copytree(root / "Assets/Settings", project / "Assets/Settings", dirs_exist_ok=True)
for name in ("ProjectVersion.txt", "GraphicsSettings.asset", "QualitySettings.asset"):
    shutil.copyfile(root / "ProjectSettings" / name, project / "ProjectSettings" / name)
cached = {}
for folder in (root / "Library/PackageCache").iterdir():
    meta = folder / "package.json"
    if meta.exists():
        data = json.loads(meta.read_text(encoding="utf-8-sig"))
        cached[data["name"]] = (folder, data)
original = json.loads((root / "Packages/manifest.json").read_text())
dependencies = {k: v for k, v in original["dependencies"].items() if k.startswith("com.unity.modules.")}


def add_package(name):
    if name in dependencies:
        return
    folder, data = cached[name]
    dependencies[name] = "file:" + folder.as_posix()
    for dependency in data.get("dependencies", {}):
        if dependency.startswith("com.unity.modules."):
            dependencies[dependency] = "1.0.0"
        else:
            add_package(dependency)


add_package("com.unity.render-pipelines.universal")
(project / "Packages/manifest.json").write_text(json.dumps({"dependencies": dependencies}, indent=2))
print(project)

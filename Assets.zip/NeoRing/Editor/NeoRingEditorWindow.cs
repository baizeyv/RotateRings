using System;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using WordTile.NeoRing;

/// <summary>Editor-only authoring in an isolated preview SceneView.</summary>
public sealed class NeoRingEditorWindow : EditorWindow
{
    [SerializeField] private string draft, filePath;
    private Scene preview;
    [SerializeField] private SceneView canvas;
    private static readonly string[] ShapeNames = { "环", "C 环", "门", "7", "Z", "卡扣", "直线" };
    private GameObject root;
    private NeoLevelEditor session;
    private NeoElementLibrary library;
    private Vector2 scroll;
    [SerializeField] private bool showScreenFrame = true;
    private int head;
    private bool snapping = true, gesture, playing, groupGesture, bodyDragging, playDragging, panning;
    private Vector2 dragPointer, dragPosition;
    private Vector3 panAnchor;
    private string message = "在 Scene 视图拖动手柄编辑。Ctrl 移动关联组，Alt 关闭吸附。";

    public static NeoRingEditorWindow OpenLevel(string assetPath = null)
    {
        var window = GetWindow<NeoRingEditorWindow>("NeoRing 编辑器");
        if (!string.IsNullOrEmpty(assetPath)) window.LoadLevel(assetPath);
        window.Show(); window.ShowCanvas(); return window;
    }
    private void OnEnable()
    {
        preview = EditorSceneManager.NewPreviewScene();
        EditorSceneManager.SetSceneCullingMask(preview, EditorSceneManager.CalculateAvailableSceneCullingMask());
        root = new GameObject("NeoRing editor preview") { hideFlags = HideFlags.HideAndDontSave };
        SceneManager.MoveGameObjectToScene(root, preview);
        var view = root.AddComponent<NeoLevelView>();
        view.RenderLayer = 0;
        view.Sprites = new[] { new NeoSpriteEntry { Id = "catch", Sprite = AssetDatabase.LoadAssetAtPath<Sprite>("Assets/catch.png") } };
        try
        {
            var data = string.IsNullOrEmpty(draft) ? NeoAuthoringDefaults.Example() : NeoLevelData.FromJson(draft);
            RegisterMaterial(view, data);
            session = new NeoLevelEditor(view, data);
        }
        catch (Exception ex) { message = ex.Message; session = new NeoLevelEditor(view, new NeoLevelData()); }
        session.Selected = session.View.World.Bodies.Length > 0 ? 0 : -1;
        try
        {
            string libraryPath = Path.GetFullPath("Assets/NeoRing/Libraries/CustomElements.json");
            string previousPath = Path.Combine(Application.persistentDataPath, "NeoRing", "custom-elements.json");
            if (!File.Exists(libraryPath) && File.Exists(previousPath)) { NeoLevelData.Load(previousPath).Save(libraryPath); AssetDatabase.Refresh(); }
            library = new NeoElementLibrary(libraryPath);
        }
        catch (Exception ex) { message = ex.Message; }
        SceneView.duringSceneGui += SceneGUI;
        EditorApplication.playModeStateChanged += PlayState;
        EditorApplication.delayCall += RestoreCanvas;
    }
    private void RestoreCanvas() { if (session != null) ShowCanvas(); }
    private void PlayState(PlayModeStateChange state)
    { if (state == PlayModeStateChange.ExitingEditMode) Close(); }
    private void OnDisable()
    {
        SceneView.duringSceneGui -= SceneGUI; EditorApplication.playModeStateChanged -= PlayState;
        EditorApplication.delayCall -= RestoreCanvas;
        if (session != null) { if (session.Playing) session.ExitPlay(); draft = session.View.World.Data.ToJson(); }
        if (canvas != null) SetCanvasScene(default);
        if (preview.IsValid()) EditorSceneManager.ClosePreviewScene(preview);
        session = null;
    }
    private void ShowCanvas()
    {
        canvas = GetWindow<SceneView>(); SetCanvasScene(preview); canvas.in2DMode = true;
        canvas.Frame(new Bounds(Vector3.zero, new Vector3(12, 12, 1)), false); canvas.Show(); canvas.Repaint();
    }
    private void SetCanvasScene(Scene scene)
    {
        // Unity 2022 exposes the SceneView preview-scene hook internally.
        var flags = System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic;
        typeof(SceneView).GetProperty("customScene", flags).SetValue(canvas, scene);
        ulong mask = 0;
        if (scene.IsValid())
        {
            mask = EditorSceneManager.GetSceneCullingMask(scene);
            if (mask == 0) { mask = EditorSceneManager.CalculateAvailableSceneCullingMask(); EditorSceneManager.SetSceneCullingMask(scene, mask); }
        }
        typeof(SceneView).GetProperty("overrideSceneCullingMask", flags).SetValue(canvas, mask);
    }
    private void Run(Action action)
    {
        try { action(); draft = session.View.World.Data.ToJson(); message = "已更新。"; }
        catch (Exception ex) { message = ex.Message; }
        Repaint(); if (canvas != null) canvas.Repaint();
    }
    private void LoadLevel(string path)
    { Run(() => { if (session.Playing) session.ExitPlay(); playing = false; var data = NeoLevelData.Load(path); RegisterMaterial(session.View, data); session.Apply(data); filePath = path; head = 0; }); }
    private bool SaveLevel()
    {
        string path = EditorUtility.SaveFilePanel("保存 NeoRing 关卡", "Assets/NeoRing/Levels", string.IsNullOrEmpty(filePath) ? "Level" : Path.GetFileNameWithoutExtension(filePath), "json");
        if (string.IsNullOrEmpty(path)) return false;
        bool saved = false;
        Run(() => { session.Save(path); filePath = path; AssetDatabase.Refresh(); saved = true; });
        return saved;
    }
    private void OnGUI()
    {
        if (session == null) return;
        using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
        {
            if (GUILayout.Button("Scene 画布", EditorStyles.toolbarButton)) ShowCanvas();
            if (GUILayout.Button("聚焦", EditorStyles.toolbarButton) && session.Selected >= 0 && canvas != null)
            {
                var bounds = session.View.World.Bodies[session.Selected].Bounds;
                canvas.Frame(new Bounds(new Vector3((float)(bounds.MinX + bounds.MaxX) / 2, (float)(bounds.MinY + bounds.MaxY) / 2, 0), new Vector3((float)(bounds.MaxX - bounds.MinX) + 1, (float)(bounds.MaxY - bounds.MinY) + 1, 1)), false);
            }
            if (GUILayout.Button("打开", EditorStyles.toolbarButton)) { string p = EditorUtility.OpenFilePanel("打开关卡", "Assets/NeoRing/Levels", "json"); if (!string.IsNullOrEmpty(p)) LoadLevel(p); }
            GUI.enabled = !playing;
            if (GUILayout.Button("新建", EditorStyles.toolbarButton)) Run(() => { session.Apply(new NeoLevelData { Name = "New level" }); session.Selected = -1; filePath = null; head = 0; });
            if (GUILayout.Button("保存", EditorStyles.toolbarButton)) SaveLevel();
            if (GUILayout.Button("撤销", EditorStyles.toolbarButton)) Run(session.Undo);
            if (GUILayout.Button("重做", EditorStyles.toolbarButton)) Run(session.Redo);
            GUI.enabled = true;
        }
        if (GUILayout.Button(playing ? "结束预览试玩" : "预览试玩（无需进入 Play）")) Run(() => { if (playing) session.ExitPlay(); else session.EnterPlay(); playing = session.Playing; });
        if (!playing && GUILayout.Button("创建独立游玩场景") && SaveLevel()) Run(() => NeoRingMenus.BuildPlayerScene(filePath));
        scroll = EditorGUILayout.BeginScrollView(scroll);
        GUI.enabled = !playing;
        EditorGUI.BeginChangeCheck();
        var material = (Material)EditorGUILayout.ObjectField("关卡共享材质", NeoRingMenus.LevelMaterial(session.View.World.Data), typeof(Material), false);
        if (EditorGUI.EndChangeCheck()) Run(() =>
        {
            var data = session.View.World.Data.Clone();
            data.MaterialId = material == null ? "" : AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(material));
            RegisterMaterial(session.View, data); session.Apply(data);
        });
        if (material != null && !material.enableInstancing)
            EditorGUILayout.HelpBox("此材质未开启 GPU Instancing；请在材质 Inspector 中开启，Shader 也需支持 _InstanceColor 实例颜色。", MessageType.Info);
        snapping = EditorGUILayout.Toggle("移动自动吸附", snapping);
        EditorGUI.BeginChangeCheck();
        showScreenFrame = EditorGUILayout.Toggle("1080 × 1920 范围预览", showScreenFrame);
        if (EditorGUI.EndChangeCheck() && canvas != null) canvas.Repaint();
        if (GUILayout.Button("聚焦竖屏范围") && canvas != null)
        {
            float height = NeoRingMenus.GameplayCameraSize * 2;
            canvas.Frame(new Bounds(Vector3.zero, new Vector3(height * 1080f / 1920f, height, 1)), false);
            canvas.Repaint();
        }
        foreach (NeoShapeKind kind in Enum.GetValues(typeof(NeoShapeKind)))
            if (GUILayout.Button("+ " + ShapeNames[(int)kind])) Run(() => session.Add(kind));
        using (new EditorGUILayout.HorizontalScope())
        {
            if (GUILayout.Button("复制")) Run(session.Duplicate);
            if (GUILayout.Button("删除")) Run(session.Delete);
        }
        EditorGUILayout.LabelField("关卡元件", EditorStyles.boldLabel);
        for (int i = 0; i < session.View.World.Bodies.Length; i++)
        {
            int index = i; var body = session.View.World.Bodies[i];
            if (GUILayout.Button((i == session.Selected ? "● " : "") + body.Data.Id + "  " + body.Data.Name + (!body.Active ? "（隐藏）" : "")))
            { session.Selected = index; head = 0; if (canvas != null) canvas.Repaint(); }
        }
        if (session.Selected >= 0)
        {
            var e = Clone();
            EditorGUI.BeginChangeCheck(); e.Name = EditorGUILayout.TextField("名称", e.Name);
            e.Operation = (NeoOperation)EditorGUILayout.EnumPopup("游玩操作", e.Operation);
            e.Color = EditorGUILayout.ColorField("颜色", e.Color);
            e.SpriteId = EditorGUILayout.TextField("图片 ID", e.SpriteId);
            DrawNumbers(e);
            if (EditorGUI.EndChangeCheck()) Run(() => session.ReplaceSelected(e));
            if (e.Kind != NeoShapeKind.Clasp)
            {
                if (GUILayout.Button("+ 连接件")) Run(() =>
                {
                    var list = new System.Collections.Generic.List<NeoHead>(e.Heads);
                    list.Add(new NeoHead { AlongBody = true }); e.Heads = list.ToArray(); head = list.Count - 1; session.ReplaceSelected(e);
                });
                for (int i = 0; i < e.Heads.Length; i++) { int index = i; if (GUILayout.Button((head == i ? "● " : "") + "连接件 " + (i + 1))) { head = index; canvas.Repaint(); } }
                if (e.Heads.Length > 0)
                {
                    head = Mathf.Clamp(head, 0, e.Heads.Length - 1); var h = e.Heads[head];
                    EditorGUI.BeginChangeCheck(); h.ShowHead = EditorGUILayout.Toggle("带连接头", h.ShowHead);
                    h.AlongBody = EditorGUILayout.Toggle("沿形状自动定位", h.AlongBody);
                    if (h.AlongBody)
                    {
                        h.Inward = EditorGUILayout.Toggle("向内", h.Inward);
                        h.ToCenter = EditorGUILayout.Toggle("延伸到中心", h.ToCenter);
                        if (e.Kind == NeoShapeKind.Ring || e.Kind == NeoShapeKind.C) h.AttachAngle = Number("附着角度", h.AttachAngle);
                        else h.PathPosition = Number("路径位置（0–1）", h.PathPosition);
                        h.RodLength = Number("杆长", h.RodLength);
                        h.DirectionOffset = Number("方向偏移角度", h.DirectionOffset);
                    }
                    else
                    {
                        h.Anchor = Coordinates("杆根", h.Anchor);
                        h.Center = Coordinates("头中心 / 杆端", h.Center);
                        h.Angle = Number("连接头角度", h.Angle);
                    }
                    h.StemWidth = Number("杆宽", h.StemWidth);
                    if (h.ShowHead)
                    {
                        h.Length = Number("连接头长度", h.Length);
                        h.Width = Number("连接头宽度", h.Width);
                        h.ChannelWidth = Number("连接头通道宽度", h.ChannelWidth);
                    }
                    if (EditorGUI.EndChangeCheck()) Run(() => session.ReplaceSelected(e));
                    if (GUILayout.Button("向内 / 向外翻转")) Run(() => { h.AlongBody = false; h.Center = h.Anchor * 2 - h.Center; h.Angle += 180; session.ReplaceSelected(e); });
                    if (GUILayout.Button("延伸到中心")) Run(() => { h.AlongBody = false; h.Center = Vector2.zero; h.Angle = Mathf.Atan2(-h.Anchor.y, -h.Anchor.x) * Mathf.Rad2Deg - 90; session.ReplaceSelected(e); });
                    if (GUILayout.Button("删除连接件")) Run(() => { var list = new System.Collections.Generic.List<NeoHead>(e.Heads); list.RemoveAt(head); e.Heads = list.ToArray(); session.ReplaceSelected(e); });
                }
                if (GUILayout.Button("+ 炸弹")) Run(() => { NeoAuthoringDefaults.AddBombDefinition(e); session.ReplaceSelected(e); });
                EditorGUI.BeginChangeCheck();
                for (int i = 0; i < e.Bombs.Length; i++)
                {
                    var b = e.Bombs[i];
                    EditorGUILayout.LabelField("炸弹 " + (i + 1), EditorStyles.boldLabel);
                    b.Enabled = EditorGUILayout.Toggle("启用", b.Enabled);
                    b.Position = Coordinates("位置", b.Position);
                    b.Angle = Number("角度", b.Angle);
                    b.Scale = Number("缩放", b.Scale);
                    b.Radius = Number("碰撞半径", b.Radius);
                    b.ImageWidth = Number("图片宽度", b.ImageWidth);
                    b.CenterOffset = Coordinates("碰撞中心偏移", b.CenterOffset);
                }
                if (EditorGUI.EndChangeCheck()) Run(() => session.ReplaceSelected(e));
            }
            if (library != null && GUILayout.Button("保存为自定义元件")) Run(() => { library.Add(e, e.Name); AssetDatabase.Refresh(); });
        }
        if (library != null)
        {
            EditorGUILayout.LabelField("自定义元件", EditorStyles.boldLabel);
            for (int i = 0; i < library.Data.Elements.Length; i++)
            { int index = i; if (GUILayout.Button("+ " + library.Data.Elements[i].Name)) Run(() => session.AddCustom(library.Data.Elements[index], Vector2.zero)); }
        }
        GUI.enabled = true;
        EditorGUILayout.HelpBox(message + "\n拖动圆点改变尺寸；黄色圆环调整旋转。连接件红色点调整杆根，绿色点调整头中心／杆长／方向。", MessageType.Info);
        EditorGUILayout.EndScrollView();
    }
    private NeoElement Clone() { return JsonUtility.FromJson<NeoElement>(JsonUtility.ToJson(session.View.World.Data.Elements[session.Selected])); }
    private static void RegisterMaterial(NeoLevelView view, NeoLevelData data)
    {
        var material = NeoRingMenus.LevelMaterial(data);
        if (material == null) return;
        foreach (var entry in view.Materials) if (entry.Id == data.MaterialId) return;
        var entries = new System.Collections.Generic.List<NeoMaterialEntry>(view.Materials);
        entries.Add(new NeoMaterialEntry { Id = data.MaterialId, Material = material }); view.Materials = entries.ToArray();
    }
    private static float Number(string label, float value) { return EditorGUILayout.DelayedFloatField(label, value); }
    private static Vector2 Coordinates(string label, Vector2 value)
    {
        EditorGUILayout.LabelField(label);
        using (new EditorGUI.IndentLevelScope())
            return new Vector2(Number("X", value.x), Number("Y", value.y));
    }
    private static void DrawNumbers(NeoElement e)
    {
        EditorGUILayout.LabelField("数值属性", EditorStyles.boldLabel);
        e.Position = Coordinates("位置", e.Position);
        e.Angle = Number("旋转角度", e.Angle);
        e.Scale = Number("缩放", e.Scale);
        if (e.Operation == NeoOperation.Slide) e.MovementAxis = Coordinates("移动方向", e.MovementAxis);
        e.SortingOrder = EditorGUILayout.DelayedIntField("显示层级", e.SortingOrder);
        if (e.Kind == NeoShapeKind.Clasp)
        {
            e.ClaspLength = Number("卡扣长度", e.ClaspLength);
            e.ClaspWidth = Number("卡扣宽度", e.ClaspWidth);
            e.ChannelWidth = Number("通道宽度", e.ChannelWidth);
            return;
        }
        e.Thickness = Number("线宽", e.Thickness);
        if (e.Kind == NeoShapeKind.Ring || e.Kind == NeoShapeKind.C)
        {
            e.Radius = Number("半径", e.Radius);
            if (e.Kind == NeoShapeKind.C)
            {
                e.StartAngle = Number("起始角度", e.StartAngle);
                e.SweepAngle = Number("圆弧角度", e.SweepAngle);
            }
        }
        else
        {
            e.Width = Number(e.Kind == NeoShapeKind.Straight ? "长度" : e.Kind == NeoShapeKind.Z ? "上段长度" : "宽度", e.Width);
            if (e.Kind == NeoShapeKind.Gate)
            {
                EditorGUI.BeginChangeCheck();
                float left = Number("左竖段高度", e.ResolvedGateLeftHeight);
                float right = Number("右竖段高度", e.ResolvedGateRightHeight);
                if (EditorGUI.EndChangeCheck()) { e.GateLeftHeight = left; e.GateRightHeight = right; }
            }
            else if (e.Kind != NeoShapeKind.Straight) e.Height = Number("高度", e.Height);
            if (e.Kind == NeoShapeKind.Z) e.BottomWidth = Number("下段长度", e.BottomWidth);
        }
    }
    private static Vector3 World(NeoElement e, Vector2 local) { return e.Position + NeoConnection.Rotate(local * e.Scale, e.Angle); }
    private static Vector2 Local(NeoElement e, Vector3 world) { return NeoConnection.Rotate((Vector2)world - e.Position, -e.Angle) / e.Scale; }
    private Vector2 Handle(NeoElement e, Vector2 point, string label, Color color)
    {
        Vector3 world = World(e, point); Handles.color = color;
        Handles.Label(world + Vector3.up * .08f, label);
        int id = GUIUtility.GetControlID(e.Id * 397 ^ label.GetHashCode(), FocusType.Passive);
        float size = HandleUtility.GetHandleSize(world) * .055f; Event ev = Event.current;
        if (ev.type == EventType.Layout) HandleUtility.AddControl(id, HandleUtility.DistanceToCircle(world, size) - .5f);
        if (ev.type == EventType.Repaint) Handles.DotHandleCap(id, world, Quaternion.identity, size, EventType.Repaint);
        Ray ray = HandleUtility.GUIPointToWorldRay(ev.mousePosition); float distance;
        bool hit = new Plane(Vector3.forward, Vector3.zero).Raycast(ray, out distance);
        if (ev.type == EventType.MouseDown && ev.button == 0 && HandleUtility.nearestControl == id && hit)
        {
            GUIUtility.hotControl = id; pointStart = world; pointerStart = ray.GetPoint(distance);
            groupGesture = label == "移动" && ev.control;
            if (!gesture) { session.BeginGesture(groupGesture); gesture = true; }
            ev.Use();
        }
        if (ev.type == EventType.MouseDrag && GUIUtility.hotControl == id && hit)
        { world = pointStart + ray.GetPoint(distance) - pointerStart; GUI.changed = true; ev.Use(); }
        if (ev.type == EventType.MouseUp && ev.button == 0 && GUIUtility.hotControl == id)
        { GUIUtility.hotControl = 0; ev.Use(); }
        return Local(e, world);
    }
    private Vector3 pointStart, pointerStart;
    private float rotationStart, pointerAngle;
    private float RotationHandle(Vector3 center, float angle, float radius)
    {
        int id = GUIUtility.GetControlID("NeoRingRotation".GetHashCode(), FocusType.Passive); Event ev = Event.current;
        if (ev.type == EventType.Layout)
        {
            Vector2 origin = HandleUtility.WorldToGUIPoint(center);
            float size = Vector2.Distance(origin, HandleUtility.WorldToGUIPoint(center + Vector3.right * radius));
            HandleUtility.AddControl(id, Mathf.Abs(Vector2.Distance(origin, ev.mousePosition) - size));
        }
        if (ev.type == EventType.Repaint) Handles.DrawWireDisc(center, Vector3.forward, radius);
        Ray ray = HandleUtility.GUIPointToWorldRay(ev.mousePosition); float distance;
        bool hit = new Plane(Vector3.forward, center).Raycast(ray, out distance);
        Vector3 direction = hit ? ray.GetPoint(distance) - center : Vector3.zero;
        float pointer = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        if (ev.type == EventType.MouseDown && ev.button == 0 && HandleUtility.nearestControl == id && hit)
        { GUIUtility.hotControl = id; rotationStart = angle; pointerAngle = pointer; if (!gesture) { session.BeginGesture(); gesture = true; } ev.Use(); }
        if (ev.type == EventType.MouseDrag && GUIUtility.hotControl == id && hit && direction.sqrMagnitude > .0001f)
        { angle = rotationStart + Mathf.DeltaAngle(pointerAngle, pointer); GUI.changed = true; ev.Use(); }
        if (ev.type == EventType.MouseUp && ev.button == 0 && GUIUtility.hotControl == id) { GUIUtility.hotControl = 0; ev.Use(); }
        return angle;
    }
    private Vector2 BodyAnchor(NeoElement e, Vector2 desired)
    {
        Vector2 closest = desired; float best = float.PositiveInfinity;
        var body = session.View.World.Bodies[session.Selected];
        for (int i = 0; i < body.Geometry.BodyCount; i++)
        {
            var part = body.Geometry.Parts[i]; Vector2 candidate;
            if (part.Kind == WordTile.Game.GameCollisionKind.Ring) candidate = desired.sqrMagnitude < .000001f ? Vector2.up * e.Radius : desired.normalized * e.Radius;
            else
            {
                Vector2 a = new Vector2((float)part.A.X, (float)part.A.Y), line = new Vector2((float)(part.B.X - part.A.X), (float)(part.B.Y - part.A.Y));
                candidate = a + line * Mathf.Clamp01(Vector2.Dot(desired - a, line) / Mathf.Max(.000001f, line.sqrMagnitude));
            }
            float distance = (candidate - desired).sqrMagnitude;
            if (distance < best) { best = distance; closest = candidate; }
        }
        return closest;
    }
    private int PickVisual(Vector2 point)
    {
        int picked = session.View.World.Pick(point);
        for (int i = 0; i < session.View.World.Bodies.Length; i++)
        {
            var body = session.View.World.Bodies[i]; var e = body.Data;
            if (!body.Active || e.Kind != NeoShapeKind.Clasp || string.IsNullOrEmpty(e.SpriteId)) continue;
            Vector2 local = Local(e, point);
            if (Mathf.Abs(local.x) <= e.ClaspLength / 2 && Mathf.Abs(local.y) <= e.ClaspWidth / 2 && (picked < 0 || e.SortingOrder >= session.View.World.Data.Elements[picked].SortingOrder)) picked = i;
        }
        return picked;
    }
    private void SceneGUI(SceneView scene)
    {
        if (session == null || scene != canvas) return;
        if (showScreenFrame && Event.current.type == EventType.Repaint)
        {
            float y = NeoRingMenus.GameplayCameraSize, x = y * 1080f / 1920f;
            Color previous = Handles.color;
            Handles.color = new Color(1, 1, 1, .8f);
            Handles.DrawAAPolyLine(2, new Vector3(-x, -y, 0), new Vector3(-x, y, 0), new Vector3(x, y, 0), new Vector3(x, -y, 0), new Vector3(-x, -y, 0));
            Handles.Label(new Vector3(-x, y + .12f, 0), "1080 × 1920 游玩范围");
            Handles.color = previous;
        }
        Event ev = Event.current;
        int canvasControl = GUIUtility.GetControlID("NeoRingCanvas".GetHashCode(), FocusType.Passive);
        if (ev.type == EventType.Layout) HandleUtility.AddDefaultControl(canvasControl);
        if ((ev.type == EventType.MouseDown || ev.type == EventType.MouseDrag) && ev.button == 1 && !gesture && !playDragging)
        {
            Ray ray = HandleUtility.GUIPointToWorldRay(ev.mousePosition); float distance;
            if (new Plane(Vector3.forward, Vector3.zero).Raycast(ray, out distance))
            {
                if (ev.type == EventType.MouseDown) { panning = true; panAnchor = ray.GetPoint(distance); GUIUtility.hotControl = canvasControl; }
                else if (panning) { scene.pivot += panAnchor - ray.GetPoint(distance); scene.Repaint(); }
            }
            ev.Use();
        }
        if (ev.rawType == EventType.MouseUp && ev.button == 1 && panning) { panning = false; GUIUtility.hotControl = 0; ev.Use(); }
        if (ev.type == EventType.KeyDown && ev.control && ev.keyCode == KeyCode.Z && !playing) { Run(ev.shift ? (Action)session.Redo : session.Undo); ev.Use(); }
        if (session.Selected >= 0 && !playing)
        {
            var e = Clone(); EditorGUI.BeginChangeCheck();
            Handles.color = Color.yellow;
            Vector3 moved = World(e, Handle(e, Vector2.zero, "移动", Color.yellow));
            float radius = Mathf.Max(.5f, (float)session.View.World.Bodies[session.Selected].Geometry.MotionRadius * e.Scale + .3f);
            float rotated = RotationHandle(e.Position, e.Angle, radius);
            bool poseChanged = EditorGUI.EndChangeCheck();
            if (poseChanged) Run(() =>
            {
                if (!gesture) { session.BeginGesture(groupGesture); gesture = true; }
                if (((Vector2)moved - e.Position).sqrMagnitude > .000000001f) session.MoveSelectedSnapped(moved, snapping && !ev.alt ? HandleUtility.GetHandleSize(moved) * .12f : 0, groupGesture);
                else session.SetSelectedPose(e.Position, rotated);
            });
            e = Clone(); EditorGUI.BeginChangeCheck();
            if (e.Kind == NeoShapeKind.Ring || e.Kind == NeoShapeKind.C)
            {
                e.Radius = Mathf.Max(.1f, Handle(e, new Vector2(e.Radius, 0), "半径", Color.cyan).magnitude);
                if (e.Kind == NeoShapeKind.C)
                {
                    EditorGUI.BeginChangeCheck();
                    Vector2 start = Handle(e, NeoConnection.Rotate(Vector2.right * e.Radius, e.StartAngle), "开口起点", Color.magenta);
                    float endAngle = e.StartAngle + e.SweepAngle;
                    Vector2 end = Handle(e, NeoConnection.Rotate(Vector2.right * e.Radius, endAngle), "开口终点", Color.magenta);
                    if (EditorGUI.EndChangeCheck()) { e.StartAngle = Mathf.Atan2(start.y, start.x) * Mathf.Rad2Deg; e.SweepAngle = Mathf.Clamp(Mathf.Repeat(Mathf.Atan2(end.y, end.x) * Mathf.Rad2Deg - e.StartAngle, 360), 1, 359); }
                }
            }
            else if (e.Kind == NeoShapeKind.Clasp)
            {
                e.ClaspLength = Mathf.Max(.05f, Handle(e, new Vector2(e.ClaspLength / 2, 0), "卡扣长度", Color.cyan).x * 2);
                e.ClaspWidth = Mathf.Max(.05f, Handle(e, new Vector2(0, e.ClaspWidth / 2), "卡扣外宽", Color.cyan).y * 2);
                e.ChannelWidth = Mathf.Clamp(Handle(e, new Vector2(0, e.ChannelWidth / 2), "通道", Color.green).y * 2, .01f, e.ClaspWidth - .01f);
            }
            else
            {
                Vector2 widthPoint = e.Kind == NeoShapeKind.Z ? new Vector2(-e.Width, e.Height / 2) : new Vector2(e.Width / 2, e.Kind == NeoShapeKind.Straight ? 0 : e.Height / 2);
                Vector2 width = Handle(e, widthPoint, "宽 / 段长", Color.cyan);
                e.Width = Mathf.Max(.1f, e.Kind == NeoShapeKind.Z ? -width.x : width.x * 2);
                if (e.Kind == NeoShapeKind.Gate)
                {
                    float top = e.Height / 2;
                    Vector2 left = new Vector2(-e.Width / 2, top - e.ResolvedGateLeftHeight);
                    Vector2 right = new Vector2(e.Width / 2, top - e.ResolvedGateRightHeight);
                    Vector2 newLeft = Handle(e, left, "左竖段高度", Color.cyan);
                    Vector2 newRight = Handle(e, right, "右竖段高度", Color.cyan);
                    if (newLeft != left) e.GateLeftHeight = Mathf.Max(.1f, top - newLeft.y);
                    if (newRight != right) e.GateRightHeight = Mathf.Max(.1f, top - newRight.y);
                }
                else if (e.Kind != NeoShapeKind.Straight) e.Height = Mathf.Max(.1f, Handle(e, new Vector2(0, -e.Height / 2), "高", Color.cyan).y * -2);
                if (e.Kind == NeoShapeKind.Z) e.BottomWidth = Mathf.Max(.1f, Handle(e, new Vector2(e.BottomWidth, -e.Height / 2), "下段长", Color.cyan).x);
            }
            Vector2 thicknessAxis = e.Kind == NeoShapeKind.Ring || e.Kind == NeoShapeKind.C ? NeoConnection.Rotate(Vector2.right, e.Kind == NeoShapeKind.Ring ? 90 : e.StartAngle + e.SweepAngle / 2) : Vector2.up;
            Vector2 thicknessBase = e.Kind == NeoShapeKind.Ring || e.Kind == NeoShapeKind.C ? thicknessAxis * e.Radius : e.Kind == NeoShapeKind.Straight ? Vector2.zero : new Vector2(e.Kind == NeoShapeKind.Z ? -e.Width / 2 : 0, e.Height / 2);
            if (e.Kind != NeoShapeKind.Clasp) e.Thickness = Mathf.Max(.02f, Vector2.Dot(Handle(e, thicknessBase + thicknessAxis * e.Thickness / 2, "线宽", Color.white) - thicknessBase, thicknessAxis) * 2);
            if (e.Heads.Length > 0)
            {
                head = Mathf.Clamp(head, 0, e.Heads.Length - 1); var h = e.Heads[head];
                Vector2 anchor = Handle(e, h.Anchor, "杆根", Color.red);
                if (anchor != h.Anchor) anchor = BodyAnchor(e, anchor);
                Vector2 center = Handle(e, h.Center, "头中心 / 杆长方向", Color.green);
                if (anchor != h.Anchor || center != h.Center)
                {
                    h.AlongBody = false; center += anchor - h.Anchor; h.Anchor = anchor; h.Center = center;
                    Vector2 direction = h.Center - h.Anchor; h.Angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg - 90;
                }
                Vector2 rodDirection = (h.Center - h.Anchor).normalized, normal = new Vector2(-rodDirection.y, rodDirection.x);
                EditorGUI.BeginChangeCheck();
                float headRotation = RotationHandle(World(e, h.Anchor), e.Angle + h.Angle, Mathf.Max(.25f, Vector2.Distance(h.Anchor, h.Center) * e.Scale * .6f));
                if (EditorGUI.EndChangeCheck())
                {
                    float change = Mathf.DeltaAngle(e.Angle + h.Angle, headRotation);
                    h.AlongBody = false; h.Center = h.Anchor + NeoConnection.Rotate(h.Center - h.Anchor, change); h.Angle += change;
                }
                Vector2 midpoint = (h.Anchor + h.Center) / 2;
                h.StemWidth = Mathf.Max(.02f, Vector2.Dot(Handle(e, midpoint + normal * h.StemWidth / 2, "杆宽", Color.white) - midpoint, normal) * 2);
                if (h.ShowHead)
                {
                    Vector2 axis = NeoConnection.Rotate(Vector2.right, h.Angle), across = new Vector2(-axis.y, axis.x);
                    h.Length = Mathf.Max(.05f, Vector2.Dot(Handle(e, h.Center + axis * h.Length / 2, "头长度", Color.cyan) - h.Center, axis) * 2);
                    h.Width = Mathf.Max(.05f, Vector2.Dot(Handle(e, h.Center + across * h.Width / 2, "头宽", Color.cyan) - h.Center, across) * 2);
                    h.ChannelWidth = Mathf.Clamp(Vector2.Dot(Handle(e, h.Center + across * h.ChannelWidth / 2, "净通道", Color.green) - h.Center, across) * 2, .01f, h.Width - .01f);
                }
            }
            foreach (var bomb in e.Bombs)
            {
                bomb.Position = Handle(e, bomb.Position, "炸弹", new Color(1, .5f, 0));
                bomb.Radius = Mathf.Max(.02f, (Handle(e, bomb.Position + Vector2.right * bomb.Radius, "爆炸碰撞半径", Color.red) - bomb.Position).magnitude);
                bomb.ImageWidth = Mathf.Max(.02f, (Handle(e, bomb.Position + Vector2.up * bomb.ImageWidth / 2, "图片尺寸", Color.white) - bomb.Position).magnitude * 2);
            }
            if (e.Operation == NeoOperation.Slide)
            {
                Vector2 axis = NeoConnection.Rotate(e.MovementAxis.normalized, -e.Angle);
                Vector2 direction = Handle(e, axis * (radius / e.Scale + .3f), "游玩移动轴", Color.magenta);
                if (direction.sqrMagnitude > .0001f) e.MovementAxis = NeoConnection.Rotate(direction.normalized, e.Angle);
            }
            float scaleRadius = Mathf.Max(.8f, (float)session.View.World.Bodies[session.Selected].Geometry.MotionRadius * 1.5f);
            Vector2 scalePoint = Handle(e, new Vector2(-1, -1).normalized * scaleRadius, "整体缩放", Color.white);
            e.Scale = Mathf.Clamp(e.Scale * scalePoint.magnitude / scaleRadius, .01f, 100);
            if (EditorGUI.EndChangeCheck()) Run(() => { if (!gesture) { session.BeginGesture(); gesture = true; } session.ReplaceSelected(e); });
        }
        if (ev.type == EventType.MouseDown && ev.button == 0 && GUIUtility.hotControl == 0)
        {
            Ray ray = HandleUtility.GUIPointToWorldRay(ev.mousePosition); float distance;
            if (new Plane(Vector3.forward, Vector3.zero).Raycast(ray, out distance))
            {
                session.Selected = playing ? session.View.World.Pick(ray.GetPoint(distance)) : PickVisual(ray.GetPoint(distance)); head = 0;
                if (session.Selected >= 0)
                {
                    GUIUtility.hotControl = canvasControl;
                    if (playing) { playDragging = true; session.View.World.BeginOperation(session.Selected); playLast = ray.GetPoint(distance); }
                    else { bodyDragging = true; dragPointer = ray.GetPoint(distance); dragPosition = session.View.World.Data.Elements[session.Selected].Position; groupGesture = ev.control; session.BeginGesture(groupGesture); gesture = true; }
                }
                Repaint(); ev.Use();
            }
        }
        if (bodyDragging && ev.type == EventType.MouseDrag && ev.button == 0 && session.Selected >= 0)
        {
            Ray ray = HandleUtility.GUIPointToWorldRay(ev.mousePosition); float distance;
            if (new Plane(Vector3.forward, Vector3.zero).Raycast(ray, out distance))
                Run(() => session.MoveSelectedSnapped(dragPosition + (Vector2)ray.GetPoint(distance) - dragPointer, snapping && !ev.alt ? HandleUtility.GetHandleSize(dragPosition) * .12f : 0, groupGesture));
            ev.Use();
        }
        if (playing && playDragging && ev.type == EventType.MouseDrag && ev.button == 0 && session.Selected >= 0)
        {
            Ray ray = HandleUtility.GUIPointToWorldRay(ev.mousePosition); float distance;
            if (new Plane(Vector3.forward, Vector3.zero).Raycast(ray, out distance))
            {
                Vector2 point = ray.GetPoint(distance), origin = session.View.World.Data.Elements[session.Selected].Position;
                session.View.World.Move(session.Selected, point - playLast, Vector2.SignedAngle(playLast - origin, point - origin)); session.View.SyncPose(session.Selected); playLast = point; scene.Repaint(); ev.Use();
            }
        }
        if (ev.rawType == EventType.MouseUp && ev.button == 0)
        {
            if (playing && playDragging && session.Selected >= 0) session.View.World.ReleaseOperation(session.Selected);
            bodyDragging = playDragging = false;
            if (GUIUtility.hotControl == canvasControl) GUIUtility.hotControl = 0;
            if (gesture) { session.EndGesture(); gesture = false; }
            draft = session.View.World.Data.ToJson(); Repaint();
        }
    }
    private Vector2 playLast;
}

using System;
using System.Collections.Generic;
using UnityEngine;
using C = WordTile.Game.GameCollision2D;

namespace WordTile.NeoRing
{
    /// <summary>Move occupied branches with an edited head, using relations before the edit.</summary>
    public static class NeoConnectionFollow
    {
        public static bool Apply(NeoWorld world, int owner, NeoLevelData next)
        {
            var previous = world.Bodies[owner]; var replacement = next.Elements[owner];
            if (previous.Data.Heads.Length != replacement.Heads.Length) return false;
            var proposals = new Dictionary<int, NeoElement>(); bool changed = false;
            for (int channel = 0; channel < previous.Channels.Length; channel++)
            {
                int headIndex = previous.Geometry.ChannelConnectionIndices[channel];
                if (headIndex < 0 || headIndex >= replacement.Heads.Length || !replacement.Heads[headIndex].ShowHead) continue;
                var oldChannel = previous.Channels[channel]; var head = replacement.Heads[headIndex];
                Vector2 oldCenter = new Vector2((float)oldChannel.A.X, (float)oldChannel.A.Y);
                Vector2 newCenter = replacement.Position + NeoConnection.Rotate(head.Center * replacement.Scale, replacement.Angle);
                float oldAngle = Mathf.Atan2((float)oldChannel.Axis.Y, (float)oldChannel.Axis.X) * Mathf.Rad2Deg;
                float angle = Mathf.DeltaAngle(oldAngle, replacement.Angle + head.Angle);
                float scale = replacement.Scale / previous.Data.Scale;
                bool moved = (newCenter - oldCenter).sqrMagnitude > .000000001f || Mathf.Abs(angle) > .00001f || Mathf.Abs(scale - 1) > .00001f;
                var visited = new bool[world.Bodies.Length]; visited[owner] = true;
                var branch = new List<int>();
                for (int other = 0; other < visited.Length; other++)
                {
                    if (visited[other] || !world.Bodies[other].Active) continue;
                    var body = world.Bodies[other];
                    for (int k = 0; k < body.Geometry.BodyCount; k++)
                        if (C.Clearance(oldChannel, body.World[k]) < -NeoWorld.OccupancyTolerance)
                        { branch.Add(other); visited[other] = true; break; }
                }
                for (int cursor = 0; cursor < branch.Count; cursor++)
                    for (int other = 0; other < visited.Length; other++)
                        if (!visited[other] && world.Bodies[other].Active && (world.ChannelOccupied(branch[cursor], other) || world.ChannelOccupied(other, branch[cursor])))
                        { branch.Add(other); visited[other] = true; }
                foreach (int member in branch)
                {
                    var proposal = JsonUtility.FromJson<NeoElement>(JsonUtility.ToJson(world.Data.Elements[member]));
                    proposal.Position = newCenter + NeoConnection.Rotate((proposal.Position - oldCenter) * scale, angle);
                    proposal.Angle += angle; proposal.Scale *= scale;
                    NeoElement existing;
                    if (proposals.TryGetValue(member, out existing) && ((existing.Position - proposal.Position).sqrMagnitude > .000001f || Mathf.Abs(Mathf.DeltaAngle(existing.Angle, proposal.Angle)) > .001f || Mathf.Abs(existing.Scale - proposal.Scale) > .00001f))
                        throw new ArgumentException("关联组同时连接多个连接头，调整会产生冲突；请先解除其中一个连接。");
                    proposals[member] = proposal; changed |= moved;
                }
            }
            if (changed) foreach (var proposal in proposals) next.Elements[proposal.Key] = proposal.Value;
            return changed;
        }
    }
}

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEngine;

namespace WordTile.NeoRing
{
    /// <summary>Runtime authoring session. History is JSON, trial play owns a separate clone.</summary>
    public sealed class NeoLevelEditor
    {
        public NeoLevelView View { get; private set; }
        public bool Playing { get; private set; }
        public int Selected { get; set; } = -1;
        public bool CanUndo { get { return !Playing && undo.Count > 0; } }
        public bool CanRedo { get { return !Playing && redo.Count > 0; } }
        private readonly List<string> undo = new List<string>(), redo = new List<string>();
        private string draft, gesture;
        private int[] gestureGroup = Array.Empty<int>();
        public int GestureGroupCount { get { return gestureGroup.Length; } }
        public NeoLevelEditor(NeoLevelView view, NeoLevelData source) { View = view; View.Load(source); }
        private void Push(List<string> list, string json)
        { if (list.Count == 64) list.RemoveAt(0); list.Add(json); }
        private void Record(string before)
        { if (gesture == null) Push(undo, before); redo.Clear(); }
        public void BeginGesture(bool moveDependencies = false)
        {
            EnsureEditing(); EndGesture(); gesture = View.World.Data.ToJson();
            gestureGroup = moveDependencies ? View.World.GetDependencyGroup(Selected) : Array.Empty<int>();
        }
        public bool IsGestureMember(int index) { return Array.IndexOf(gestureGroup, index) >= 0; }
        public void EndGesture()
        {
            if (gesture == null) return;
            if (gesture != View.World.Data.ToJson()) { Push(undo, gesture); redo.Clear(); }
            gesture = null;
            gestureGroup = Array.Empty<int>();
        }
        private void EnsureEditing() { if (Playing) throw new InvalidOperationException("Exit trial play before editing."); }
        public void ReplaceSelected(NeoElement element)
        {
            EnsureEditing(); string before = View.World.Data.ToJson();
            var next = View.World.Data.Clone(); next.Elements[Selected] = JsonUtility.FromJson<NeoElement>(JsonUtility.ToJson(element)); next.Validate();
            bool followed = NeoConnectionFollow.Apply(View.World, Selected, next);
            if (followed) View.Load(next); else View.ReplaceElement(Selected, next.Elements[Selected]);
            if (before != View.World.Data.ToJson()) Record(before);
        }
        public void SetSelectedPose(Vector2 point, float angle)
        {
            EnsureEditing(); string before = gesture == null ? View.World.Data.ToJson() : null;
            View.World.SetPose(Selected, point, angle); View.SyncPose(Selected);
            if (before != null && before != View.World.Data.ToJson()) Record(before);
        }
        public void TranslateSelectedDependencies(Vector2 delta)
        {
            EnsureEditing(); string before = gesture == null ? View.World.Data.ToJson() : null;
            int[] members = gestureGroup.Length > 0 ? gestureGroup : View.World.GetDependencyGroup(Selected);
            View.World.TranslateGroup(members, delta);
            for (int i = 0; i < members.Length; i++) View.SyncPose(members[i]);
            if (before != null && before != View.World.Data.ToJson()) Record(before);
        }
        public bool MoveSelectedSnapped(Vector2 desiredPosition, float distance, bool group)
        {
            EnsureEditing();
            int[] members = group ? (gestureGroup.Length > 0 ? gestureGroup : View.World.GetDependencyGroup(Selected)) : new[] { Selected };
            bool snapped;
            Vector2 delta = NeoSnap.Translation(View.World, members, desiredPosition - View.World.Data.Elements[Selected].Position, distance, out snapped);
            if (group) TranslateSelectedDependencies(delta);
            else SetSelectedPose(View.World.Data.Elements[Selected].Position + delta, View.World.Data.Elements[Selected].Angle);
            return snapped;
        }
        public void Add(NeoShapeKind kind)
        {
            EnsureEditing(); var data = View.World.Data.Clone(); int id = 1;
            foreach (var e in data.Elements) id = Math.Max(id, e.Id + 1);
            var element = new NeoElement { Id = id, Name = kind.ToString(), Kind = kind, Operation = kind == NeoShapeKind.Clasp ? NeoOperation.Fixed : NeoOperation.Rotate };
            var list = new List<NeoElement>(data.Elements); list.Add(element); data.Elements = list.ToArray();
            Apply(data); Selected = data.Elements.Length - 1;
        }
        public void Duplicate()
        {
            EnsureEditing(); if (Selected < 0) return;
            var data = View.World.Data.Clone(); var element = JsonUtility.FromJson<NeoElement>(JsonUtility.ToJson(data.Elements[Selected]));
            int id = 1; foreach (var e in data.Elements) id = Math.Max(id, e.Id + 1);
            element.Id = id; element.Name += " copy"; element.Position += Vector2.one * 0.4f;
            var list = new List<NeoElement>(data.Elements); list.Add(element); data.Elements = list.ToArray(); Apply(data); Selected = list.Count - 1;
        }
        public void AddCustom(NeoElement template, Vector2 position)
        {
            EnsureEditing(); var data = View.World.Data.Clone();
            var element = JsonUtility.FromJson<NeoElement>(JsonUtility.ToJson(template));
            element.Id = 1; foreach (var e in data.Elements) element.Id = Math.Max(element.Id, e.Id + 1);
            element.Position = position;
            var list = new List<NeoElement>(data.Elements); list.Add(element); data.Elements = list.ToArray();
            Apply(data); Selected = list.Count - 1;
        }
        public void Delete()
        {
            EnsureEditing(); if (Selected < 0) return;
            var data = View.World.Data.Clone(); var list = new List<NeoElement>(data.Elements); list.RemoveAt(Selected); data.Elements = list.ToArray();
            Apply(data); Selected = Math.Min(Selected, list.Count - 1);
        }
        public void Apply(NeoLevelData data)
        {
            EnsureEditing(); EndGesture(); string before = View.World.Data.ToJson(); View.Load(data);
            if (before != View.World.Data.ToJson()) Record(before);
            Selected = Math.Min(Selected, View.World.Bodies.Length - 1);
        }
        private void Restore(List<string> from, List<string> to)
        {
            EnsureEditing(); EndGesture(); if (from.Count == 0) return;
            string json = from[from.Count - 1], current = View.World.Data.ToJson(); View.Load(NeoLevelData.FromJson(json));
            from.RemoveAt(from.Count - 1); Push(to, current); Selected = Math.Min(Selected, View.World.Bodies.Length - 1);
        }
        public void Undo() { Restore(undo, redo); }
        public void Redo() { Restore(redo, undo); }
        public void EnterPlay()
        {
            EnsureEditing(); EndGesture(); var errors = View.World.CheckPlayable();
            if (errors.Count != 0) throw new ArgumentException(string.Join("\n", errors));
            draft = View.World.Data.ToJson(); View.Load(NeoLevelData.FromJson(draft)); Playing = true;
            View.World.ResolveInitialBombContacts();
        }
        public void ExitPlay()
        { if (!Playing) return; View.Load(NeoLevelData.FromJson(draft)); Playing = false; draft = null; }
        public void Save(string path) { EnsureEditing(); EndGesture(); View.World.Data.Save(path); }
        public void Load(string path) { Apply(NeoLevelData.Load(path)); }
    }
}

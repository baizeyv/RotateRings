using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace WordTile.NeoRing
{
    /// <summary>Reusable element definitions; persists parameters, never generated meshes.</summary>
    public sealed class NeoElementLibrary
    {
        public string Path { get; private set; }
        public NeoLevelData Data { get; private set; }
        public NeoElementLibrary(string path)
        {
            Path = path;
            Data = File.Exists(path) ? NeoLevelData.Load(path) : new NeoLevelData { Name = "Custom elements" };
        }
        public void Add(NeoElement source, string name)
        {
            if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("请输入自定义元件名称。");
            var next = Data.Clone();
            foreach (var entry in next.Elements)
                if (entry.Name == name.Trim()) throw new ArgumentException("名称已存在，请使用新的名称。");
            var element = JsonUtility.FromJson<NeoElement>(JsonUtility.ToJson(source));
            element.Id = 1;
            foreach (var entry in next.Elements) element.Id = Math.Max(element.Id, entry.Id + 1);
            element.Name = name.Trim(); element.Position = Vector2.zero;
            var list = new List<NeoElement>(next.Elements); list.Add(element); next.Elements = list.ToArray();
            next.Save(Path); Data = next;
        }
        public void Remove(int index)
        {
            var next = Data.Clone(); var list = new List<NeoElement>(next.Elements);
            list.RemoveAt(index); next.Elements = list.ToArray(); next.Save(Path); Data = next;
        }
    }
}

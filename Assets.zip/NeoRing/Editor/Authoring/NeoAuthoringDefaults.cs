using System;
using System.Collections.Generic;
using UnityEngine;

namespace WordTile.NeoRing
{
    public static class NeoAuthoringDefaults
    {
        public static NeoLevelData Example()
        {
            var elements = new NeoElement[7];
            for (int i = 0; i < elements.Length; i++)
                elements[i] = new NeoElement { Id = i + 1, Name = ((NeoShapeKind)i).ToString(), Kind = (NeoShapeKind)i,
                    Position = new Vector2((i % 3 - 1) * 3.2f, i < 3 ? 2.2f : -2.2f),
                    Operation = i == 5 ? NeoOperation.Fixed : i == 4 ? NeoOperation.Slide : NeoOperation.Rotate,
                    Color = Color.HSVToRGB(i / 7f, 0.55f, 0.95f) };
            elements[0].Heads = new[] { new NeoHead { Anchor = Vector2.up, Center = new Vector2(0, 1.45f) } };
            elements[0].Bombs = new[] { new NeoBomb { Id = 1, Position = new Vector2(-1.3f, 0) } };
            elements[6].Position = new Vector2(0, -4.8f); elements[6].Operation = NeoOperation.Slide;
            elements[6].Heads = new[] { new NeoHead { Anchor = new Vector2(-0.5f, 0), Center = new Vector2(-0.5f, 0.65f) },
                new NeoHead { Anchor = new Vector2(0.5f, 0), Center = new Vector2(0.5f, 0.55f), ShowHead = false } };
            return new NeoLevelData { Name = "Seven shapes", Elements = elements };
        }

        public static int AddBombDefinition(NeoElement element)
        {
            if (element.Bombs.Length >= 16) throw new ArgumentException("每个形状最多支持 16 个炸弹。");
            int id = 1; while (Array.Exists(element.Bombs, bomb => bomb.Id == id)) id++;
            var list = new List<NeoBomb>(element.Bombs); list.Add(new NeoBomb { Id = id }); element.Bombs = list.ToArray();
            return list.Count - 1;
        }
    }
}

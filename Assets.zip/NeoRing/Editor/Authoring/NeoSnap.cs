using System;
using UnityEngine;
using C = WordTile.Game.GameCollision2D;
using K = WordTile.Game.GameCollisionKind;

namespace WordTile.NeoRing
{
    /// <summary>Authoring-only translation alignment of rod centerlines to channel centers.</summary>
    public static class NeoSnap
    {
        public static Vector2 Translation(NeoWorld world, int[] members, Vector2 delta, float distance, out bool snapped)
        {
            snapped = false;
            if (distance <= 0) return delta;
            var moving = new bool[world.Bodies.Length];
            foreach (int index in members) moving[index] = true;
            float best = distance * distance; Vector2 result = delta;
            for (int owner = 0; owner < moving.Length; owner++)
            {
                var channelBody = world.Bodies[owner]; if (!channelBody.Active) continue;
                foreach (var originalChannel in channelBody.Channels)
                {
                    var channel = Shift(originalChannel, moving[owner] ? delta : Vector2.zero);
                    for (int other = 0; other < moving.Length; other++)
                    {
                        var body = world.Bodies[other];
                        if (!body.Active || moving[owner] == moving[other]) continue;
                        bool curved = body.Data.Kind == NeoShapeKind.Ring || body.Data.Kind == NeoShapeKind.C;
                        if (curved && channelBody.Data.Kind == NeoShapeKind.Clasp) continue;
                        for (int part = 0; part < body.Geometry.BodyCount; part++)
                        {
                            var rod = Shift(body.World[part], moving[other] ? delta : Vector2.zero);
                            if (body.Data.Kind == NeoShapeKind.C)
                            {
                                if (part > 0) break;
                                Vector2 center = body.Data.Position + (moving[other] ? delta : Vector2.zero);
                                rod = new C.Part { Kind = K.Ring, A = new C.Point(center.x, center.y), RingRadius = body.Data.Radius * body.Data.Scale, Radius = body.Data.Thickness * body.Data.Scale / 2 };
                            }
                            Vector2 correction;
                            if (!Correction(channel, rod, out correction)) continue;
                            if (body.Data.Kind == NeoShapeKind.C)
                            {
                                // Align the actual tessellated centerline, including its chord error.
                                Vector2 ideal = Point(channel.A) - correction, axis = Point(channel.Axis);
                                float nearest = body.Data.ArcError * body.Data.Scale + .0001f;
                                bool found = false;
                                for (int k = 0; k < body.Geometry.BodyCount; k++)
                                {
                                    var segment = Shift(body.World[k], moving[other] ? delta : Vector2.zero);
                                    Vector2 a = Point(segment.A), line = Point(segment.B) - a;
                                    float along = Vector2.Dot(line, axis);
                                    if (Mathf.Abs(along) < .000001f) continue;
                                    float t = Vector2.Dot(ideal - a, axis) / along;
                                    if (t < 0 || t > 1) continue;
                                    Vector2 actual = a + line * t;
                                    float error = Vector2.Distance(actual, ideal);
                                    if (error > nearest) continue;
                                    nearest = error; correction = Point(channel.A) - actual; found = true;
                                }
                                if (!found) continue;
                            }
                            if (moving[owner]) correction = -correction;
                            Vector2 normal = new Vector2(-(float)channel.Axis.Y, (float)channel.Axis.X);
                            float room = (float)(channel.HalfHeight - rod.Radius - world.Data.CollisionSkin);
                            // Curvature can meet a rail corner before the tangent center is aligned.
                            // Search a small offset within the remaining passage clearance when needed.
                            for (int attempt = 0; attempt < (curved ? 33 : 1); attempt++)
                            {
                                float offset = attempt == 0 ? 0 : ((attempt + 1) / 2) * room / 16 * (attempt % 2 == 0 ? -1 : 1);
                                Vector2 adjusted = correction + normal * offset;
                                float score = adjusted.sqrMagnitude;
                                if (score > best) continue;
                                Vector2 candidate = delta + adjusted;
                                var finalChannel = Shift(originalChannel, moving[owner] ? candidate : Vector2.zero);
                                bool occupied = false;
                                for (int k = 0; k < body.Geometry.BodyCount; k++)
                                    if (C.Clearance(finalChannel, Shift(body.World[k], moving[other] ? candidate : Vector2.zero)) < -NeoWorld.OccupancyTolerance) { occupied = true; break; }
                                if (!occupied || !Fits(world, moving, candidate)) continue;
                                best = score; result = candidate; snapped = true;
                                if (attempt == 0) break;
                            }
                        }
                    }
                }
            }
            return result;
        }
        private static bool Correction(C.Part channel, C.Part rod, out Vector2 correction)
        {
            Vector2 center = Point(channel.A), axis = Point(channel.Axis), target;
            correction = Vector2.zero;
            if (rod.Kind == K.Ring)
            {
                Vector2 normal = new Vector2(-axis.y, axis.x);
                float side = Vector2.Dot(center - Point(rod.A), normal) < 0 ? -1 : 1;
                target = Point(rod.A) + normal * (side * (float)rod.RingRadius);
            }
            else
            {
                Vector2 a = Point(rod.A), b = rod.Kind == K.Capsule ? Point(rod.B) : a + Point(rod.Axis) * (float)rod.HalfWidth;
                if (rod.Kind == K.Box) a -= Point(rod.Axis) * (float)rod.HalfWidth;
                Vector2 line = b - a;
                if (line.sqrMagnitude < .000001f || Mathf.Abs(Vector2.Dot(line.normalized, axis)) < .97f) return false;
                // Require a full channel-length segment around the insertion point, not an end cap.
                float margin = (float)channel.HalfWidth / line.magnitude;
                if (margin >= .5f) return false;
                float t = Mathf.Clamp(Vector2.Dot(center - a, line) / line.sqrMagnitude, margin, 1 - margin);
                target = a + line * t;
            }
            double thickness = rod.Kind == K.Box ? rod.HalfHeight : rod.Radius;
            if (thickness >= channel.HalfHeight) return false;
            correction = center - target; return true;
        }
        private static bool Fits(NeoWorld world, bool[] moving, Vector2 delta)
        {
            for (int i = 0; i < moving.Length; i++) if (moving[i])
            {
                var body = world.Bodies[i];
                if (Mathf.Abs(body.Data.Position.x + delta.x) > 10000 || Mathf.Abs(body.Data.Position.y + delta.y) > 10000) return false;
                foreach (var part in body.World)
                {
                    var shifted = Shift(part, delta);
                    for (int j = 0; j < moving.Length; j++) if (!moving[j] && world.Bodies[j].Active)
                        foreach (var other in world.Bodies[j].World)
                            if (shifted.Bounds.Overlaps(other.Bounds) && C.Clearance(shifted, other) < world.Data.CollisionSkin) return false;
                }
            }
            return true;
        }
        private static C.Part Shift(C.Part part, Vector2 delta) { return C.Transform(part, delta.x, delta.y, 1, 0, 1); }
        private static Vector2 Point(C.Point point) { return new Vector2((float)point.X, (float)point.Y); }
    }
}

using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using WordTile.NeoRing;

public static class NeoRingMenus
{
    public const float GameplayCameraSize = 6.2f;
    public const string ScenePath = "Assets/NeoRing/Scenes/NeoRingWorkbench.unity";
    public const string CatchScenePath = "Assets/NeoRing/Scenes/NeoRingCatchExample.unity";

    [MenuItem("Tools/NeoRing/打开图片卡扣示例")]
    public static void OpenCatch()
    {
        if (EditorApplication.isPlaying) return;
        NeoRingEditorWindow.OpenLevel("Assets/NeoRing/Levels/CatchExample.json");
    }
    public static NeoLevelPlayer BuildCatchScene()
    {
        return BuildPlayerScene("Assets/NeoRing/Levels/CatchExample.json", CatchScenePath);
    }

    [MenuItem("Tools/NeoRing/打开关卡编辑器")]
    public static void Open()
    {
        if (EditorApplication.isPlaying) return;
        NeoRingEditorWindow.OpenLevel();
    }
    public static NeoLevelPlayer BuildPlayerScene(string levelPath, string destination = null)
    {
        string assetPath = System.IO.Path.GetFullPath(levelPath).Replace('\\', '/');
        string projectPath = System.IO.Path.GetFullPath(".").Replace('\\', '/') + "/";
        if (!assetPath.StartsWith(projectPath + "Assets/", System.StringComparison.OrdinalIgnoreCase))
            throw new System.ArgumentException("请先把关卡 JSON 保存到项目 Assets 目录。");
        var level = AssetDatabase.LoadAssetAtPath<TextAsset>(assetPath.Substring(projectPath.Length));
        if (level == null) throw new System.ArgumentException("关卡尚未导入 Unity。");
        using (var world = new NeoWorld(NeoLevelData.FromJson(level.text)))
        {
            var errors = world.CheckPlayable();
            if (errors.Count > 0) throw new System.ArgumentException(string.Join("\n", errors));
        }
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return null;
        EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        var camera = new GameObject("Gameplay camera").AddComponent<Camera>(); camera.tag = "MainCamera";
        camera.transform.position = new Vector3(0, 0, -10); camera.orthographic = true; camera.orthographicSize = GameplayCameraSize;
        camera.cullingMask = 1 << 31; camera.clearFlags = CameraClearFlags.SolidColor; camera.backgroundColor = new Color(.988f, .941f, .847f);
        var root = new GameObject("NeoRing Player"); var view = root.AddComponent<NeoLevelView>();
        view.SharedShapeMaterial = LevelMaterial(NeoLevelData.FromJson(level.text));
        view.Sprites = new[] { new NeoSpriteEntry { Id = "catch", Sprite = AssetDatabase.LoadAssetAtPath<Sprite>("Assets/catch.png") } };
        var player = root.AddComponent<NeoLevelPlayer>(); player.Level = level; player.Camera = camera;
        string scenePath = destination ?? AssetDatabase.GenerateUniqueAssetPath("Assets/NeoRing/Scenes/" + System.IO.Path.GetFileNameWithoutExtension(levelPath) + "Player.unity");
        EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene(), scenePath); AssetDatabase.Refresh(); return player;
    }
    public static NeoLevelPlayer BuildScene()
    { return BuildPlayerScene("Assets/NeoRing/Levels/Example.json", ScenePath); }
    public static Material LevelMaterial(NeoLevelData data)
    {
        if (string.IsNullOrEmpty(data.MaterialId)) return null;
        var material = AssetDatabase.LoadAssetAtPath<Material>(AssetDatabase.GUIDToAssetPath(data.MaterialId));
        if (material == null) material = Resources.Load<Material>(data.MaterialId);
        if (material == null) throw new System.ArgumentException("找不到关卡材质：" + data.MaterialId);
        return material;
    }
    public static void ShowGameView()
    {
        var window = EditorWindow.GetWindow(System.Type.GetType("UnityEditor.GameView,UnityEditor"));
        Landscape(window); window.Show(); window.Focus();
    }
    private static void Landscape(EditorWindow window)
    {
        try
        {
            var assembly = typeof(Editor).Assembly; var sizesType = assembly.GetType("UnityEditor.GameViewSizes");
            var sizes = typeof(ScriptableSingleton<>).MakeGenericType(sizesType).GetProperty("instance").GetValue(null);
            var groupType = assembly.GetType("UnityEditor.GameViewSizeGroupType");
            var group = sizesType.GetMethod("GetGroup").Invoke(sizes, new[] { System.Enum.Parse(groupType, "Standalone") });
            var type = group.GetType(); int count = (int)type.GetMethod("GetTotalCount").Invoke(group, null), index = -1;
            for (int i = 0; i < count; i++)
            {
                var size = type.GetMethod("GetGameViewSize").Invoke(group, new object[] { i });
                if ((int)size.GetType().GetProperty("width").GetValue(size) == 1600 && (int)size.GetType().GetProperty("height").GetValue(size) == 900) { index = i; break; }
            }
            if (index < 0)
            {
                var size = System.Activator.CreateInstance(assembly.GetType("UnityEditor.GameViewSize"), new object[] {
                    System.Enum.Parse(assembly.GetType("UnityEditor.GameViewSizeType"), "FixedResolution"), 1600, 900, "NeoRing 1600×900" });
                type.GetMethod("AddCustomSize").Invoke(group, new[] { size }); index = count;
            }
            window.GetType().GetProperty("selectedSizeIndex", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic).SetValue(window, index);
        }
        catch (System.Exception) { /* The runtime UI still scales uniformly when editor internals differ. */ }
    }
}

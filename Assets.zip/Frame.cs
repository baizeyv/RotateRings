using System;
using UnityEngine;

namespace DefaultNamespace
{
    public class Frame : MonoBehaviour
    {
        private void Awake()
        {
            Application.targetFrameRate = 60;
        }
    }
}

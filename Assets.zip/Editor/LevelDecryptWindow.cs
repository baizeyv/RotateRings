using System;
using System.IO;
using System.IO.Compression;
using System.Text;
using UnityEditor;
using UnityEngine;

public sealed class LevelDecryptWindow : EditorWindow
{
    private string levelId = "100020";
    private string content = "";
    private string preview = "";
    private string loadedId = "";
    private string status = "";
    private Vector2 scroll;
    private static string LevelsFolder => Path.Combine(Application.dataPath, "Levels");

    [MenuItem("Tools/WordTile/关卡解密工具")]
    private static void Open()
    {
        GetWindow<LevelDecryptWindow>("关卡解密").minSize = new Vector2(520, 360);
    }

    private void OnGUI()
    {
        EditorGUILayout.HelpBox("读取 Assets/Levels 下的 GZip 关卡文件，格式化预览 JSON 内容。", MessageType.Info);
        levelId = EditorGUILayout.TextField("关卡 ID", levelId);
        using (new EditorGUILayout.HorizontalScope())
        {
            if (GUILayout.Button("解密并显示")) LoadLevel();
            if (GUILayout.Button("导出此 ID 的 JSON")) ExportLevel();
            if (GUILayout.Button("一键导出全部")) ExportAll();
        }
        if (!string.IsNullOrEmpty(status)) EditorGUILayout.HelpBox(status, MessageType.None);
        EditorGUILayout.LabelField(string.IsNullOrEmpty(loadedId) ? "解密内容" : "解密内容：" + loadedId);
        using (new EditorGUI.DisabledScope(string.IsNullOrEmpty(content)))
            if (GUILayout.Button("复制内容", GUILayout.Width(100))) EditorGUIUtility.systemCopyBuffer = preview;
        scroll = EditorGUILayout.BeginScrollView(scroll);
        EditorGUILayout.SelectableLabel(preview, EditorStyles.textArea,
            GUILayout.MinHeight(position.height - 190),
            GUILayout.Height(Mathf.Max(position.height - 190,
                EditorStyles.textArea.CalcHeight(new GUIContent(preview), Mathf.Max(100, position.width - 40)))));
        EditorGUILayout.EndScrollView();
    }

    private bool LoadLevel()
    {
        content = "";
        preview = "";
        loadedId = "";
        try
        {
            string id = levelId.Trim();
            if (id.Length == 0 || id.IndexOfAny("0123456789".ToCharArray()) < 0)
                throw new ArgumentException("请输入数字关卡 ID。");
            foreach (char character in id)
                if (character < '0' || character > '9') throw new ArgumentException("请输入数字关卡 ID。");
            string path = Path.Combine(LevelsFolder, id + ".level");
            if (!File.Exists(path)) throw new FileNotFoundException("未找到关卡：" + id);
            content = LevelGZipDecoder.Decode(path);
            preview = LevelJsonPreview.Format(content);
            loadedId = id;
            status = "解密成功：" + id;
            scroll = Vector2.zero;
            return true;
        }
        catch (Exception exception)
        {
            status = "解密失败：" + exception.Message;
            return false;
        }
    }

    private void ExportLevel()
    {
        if (!LoadLevel()) return;
        string path = EditorUtility.SaveFilePanel("导出关卡 JSON", ProjectFolder, loadedId, "json");
        if (string.IsNullOrEmpty(path)) return;
        try
        {
            File.WriteAllText(path, content, new UTF8Encoding(false));
            AssetDatabase.Refresh();
            status = "已导出：" + path;
        }
        catch (Exception exception) { status = "导出失败：" + exception.Message; }
    }

    private static string ProjectFolder => Path.GetDirectoryName(Application.dataPath);

    private void ExportAll()
    {
        if (!Directory.Exists(LevelsFolder)) { status = "未找到 Assets/Levels 文件夹。"; return; }
        string folder = EditorUtility.OpenFolderPanel("选择导出目录（会在其中创建新文件夹）", ProjectFolder, "");
        if (string.IsNullOrEmpty(folder)) return;
        int exported = 0;
        int failed = 0;
        bool cancelled = false;
        try
        {
            string[] files = Directory.GetFiles(LevelsFolder, "*.level", SearchOption.AllDirectories);
            Array.Sort(files, StringComparer.Ordinal);
            if (files.Length == 0) { status = "Levels 下没有 .level 文件。"; return; }
            folder = Path.Combine(folder, "DecryptedLevels_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff"));
            Directory.CreateDirectory(folder);
            for (int i = 0; i < files.Length; i++)
            {
                if (EditorUtility.DisplayCancelableProgressBar("导出全部关卡", Path.GetFileName(files[i]), (float)i / files.Length))
                { cancelled = true; break; }
                try
                {
                    string relative = files[i].Substring(LevelsFolder.Length + 1);
                    string output = Path.Combine(folder, Path.ChangeExtension(relative, ".json"));
                    string decoded = LevelGZipDecoder.Decode(files[i]);
                    Directory.CreateDirectory(Path.GetDirectoryName(output));
                    File.WriteAllText(output, decoded, new UTF8Encoding(false));
                    exported++;
                }
                catch (Exception exception)
                {
                    failed++;
                    Debug.LogError("关卡导出失败：" + files[i] + "\n" + exception.Message);
                }
            }
            status = (cancelled ? "已取消" : "导出完成") + "，成功 " + exported + "，失败 " + failed + "。目录：" + folder;
        }
        catch (Exception exception) { status = "导出失败：" + exception.Message; }
        finally
        {
            EditorUtility.ClearProgressBar();
            AssetDatabase.Refresh();
        }
    }
}

public static class LevelJsonPreview
{
    // Only change whitespace outside strings, preserving every JSON value verbatim.
    public static string Format(string json)
    {
        var result = new StringBuilder();
        int indent = 0;
        bool inString = false;
        bool escaped = false;
        foreach (char character in json)
        {
            if (inString)
            {
                result.Append(character);
                if (escaped) escaped = false;
                else if (character == '\\') escaped = true;
                else if (character == '"') inString = false;
                continue;
            }
            switch (character)
            {
                case '"': inString = true; result.Append(character); break;
                case '{':
                case '[':
                    result.Append(character).Append('\n').Append(' ', ++indent * 2);
                    break;
                case '}':
                case ']':
                    result.Append('\n').Append(' ', --indent * 2).Append(character);
                    break;
                case ',': result.Append(character).Append('\n').Append(' ', indent * 2); break;
                case ':': result.Append(": "); break;
                default:
                    if (!char.IsWhiteSpace(character)) result.Append(character);
                    break;
            }
        }
        return result.ToString();
    }
}

public static class LevelGZipDecoder
{
    public static string Decode(string path)
    {
        using (var input = File.OpenRead(path))
        using (var gzip = new GZipStream(input, CompressionMode.Decompress))
        using (var reader = new StreamReader(gzip, new UTF8Encoding(false, true)))
            return reader.ReadToEnd();
    }
}

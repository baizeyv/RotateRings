using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;
using Debug = UnityEngine.Debug;

namespace WordTile.EditorTools
{
    public sealed class WordTileGeneratorWindow : EditorWindow
    {
        [SerializeField] private GenerationSettings settings = new GenerationSettings();
        [SerializeField] private int dictionaryChoice;
        [SerializeField] private TextAsset customDictionary;
        [SerializeField] private TextAsset exclusionList;
        [SerializeField] private int batchCount = 10;
        private GenerationResult preview;
        private GenerationSettings previewSettings;
        private WordDictionary previewDictionary;
        private string previewDictionaryName = "";
        private string json = "", status = "", selectedWord = "";
        private Vector2 windowScroll, jsonScroll;
        private const string DictionaryPath = "Assets/WordTile/Dictionaries/wordtile-curated-en.txt";
        private const string BackupDictionaryPath = "Assets/WordTile/Dictionaries/levels-backup-en.txt";
        private static readonly string[] DictionaryNames = { "自有筛选词库", "Levels 备用词库", "自定义 TXT 词库" };

        [MenuItem("Tools/WordTile/关卡生成器")]
        private static void Open()
        { GetWindow<WordTileGeneratorWindow>("关卡生成器").minSize = new Vector2(760, 600); }

        private void OnGUI()
        {
            windowScroll = EditorGUILayout.BeginScrollView(windowScroll);
            EditorGUILayout.HelpBox("四方向连接；单词内不重复使用格子；目标词覆盖全棋盘。使用所选词库生成新棋盘，无障碍。", MessageType.Info);
            dictionaryChoice = EditorGUILayout.Popup("生成词库", dictionaryChoice, DictionaryNames);
            if (dictionaryChoice == 2)
                customDictionary = (TextAsset)EditorGUILayout.ObjectField("自定义 TXT 词库", customDictionary, typeof(TextAsset), false);
            exclusionList = (TextAsset)EditorGUILayout.ObjectField("排除词 TXT（可选）", exclusionList, typeof(TextAsset), false);
            EditorGUILayout.LabelField(dictionaryChoice == 0 ? "基于 SCOWL，已按项目规则筛选。" :
                dictionaryChoice == 1 ? "来自 Levels 的全部目标词和额外词，未应用自有词库筛选规则。" : "每行一个英文单词，自动大写并去重。", EditorStyles.wordWrappedLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                settings.Width = EditorGUILayout.IntField("宽", settings.Width);
                settings.Height = EditorGUILayout.IntField("高", settings.Height);
            }
            settings.TargetCount = EditorGUILayout.IntField("目标词数", settings.TargetCount);
            settings.ExtraCount = EditorGUILayout.IntField("额外词数量（-1 为全部）", settings.ExtraCount);
            EditorGUILayout.LabelField("0 表示不导出额外词；指定数量时，不足会重试并在失败后提示。", EditorStyles.wordWrappedLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                settings.MinLength = EditorGUILayout.IntField("最短词长", settings.MinLength);
                settings.MaxLength = EditorGUILayout.IntField("最长词长", settings.MaxLength);
            }
            settings.Seed = EditorGUILayout.IntField("随机种子", settings.Seed);
            settings.Id = EditorGUILayout.IntField("关卡 ID / 批量起始 ID", settings.Id);
            batchCount = EditorGUILayout.IntField("批量数量", batchCount);
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("生成并预览")) GeneratePreview();
                using (new EditorGUI.DisabledScope(preview == null))
                {
                    if (GUILayout.Button("验证当前预览")) ValidatePreview();
                    if (GUILayout.Button("导出当前预览 JSON")) ExportPreview();
                    if (GUILayout.Button("分析当前关卡难度")) LevelDifficultyWindow.OpenForLevel(preview.Level);
                }
                if (GUILayout.Button("批量生成并导出")) ExportBatch();
            }
            if (!string.IsNullOrEmpty(status)) EditorGUILayout.HelpBox(status, MessageType.None);
            if (preview != null) DrawPreview();
            EditorGUILayout.EndScrollView();
        }

        private void DrawPreview()
        {
            GeneratedLevel level = preview.Level;
            EditorGUILayout.LabelField("当前预览", "ID " + level.id + " · " + level.width + "×" + level.height +
                " · 种子 " + previewSettings.Seed + "（修改参数后需重新生成）");
            EditorGUILayout.LabelField("预览使用词库", previewDictionaryName);
            EditorGUILayout.LabelField("格子小数字为选定目标词路径的使用次数；坐标原点为左上角。");
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUILayout.VerticalScope(GUILayout.Width(level.width * 62)))
                {
                    string letters = level.letters.Replace(",", "");
                    int[] selectedPath = string.IsNullOrEmpty(selectedWord) ? new int[0] : preview.Paths[selectedWord];
                    for (int row = 0; row < level.height; row++)
                    {
                        using (new EditorGUILayout.HorizontalScope())
                            for (int column = 0; column < level.width; column++)
                            {
                                int cell = row * level.width + column;
                                Color previous = GUI.backgroundColor;
                                if (selectedPath.Contains(cell)) GUI.backgroundColor = Color.cyan;
                                GUILayout.Box(letters[cell] + "\n" + preview.Usage[cell], GUILayout.Width(56), GUILayout.Height(48));
                                GUI.backgroundColor = previous;
                            }
                    }
                    if (!string.IsNullOrEmpty(selectedWord))
                        EditorGUILayout.LabelField(selectedWord + " 路径", string.Join(" → ", selectedPath.Select(cell =>
                            "(" + cell % level.width + "," + cell / level.width + ")").ToArray()), EditorStyles.wordWrappedLabel);
                }
                using (new EditorGUILayout.VerticalScope())
                {
                    EditorGUILayout.LabelField("目标词（点击高亮路径）", EditorStyles.boldLabel);
                    for (int i = 0; i < level.target_words.Length; i += 4)
                        using (new EditorGUILayout.HorizontalScope())
                            for (int j = i; j < Math.Min(i + 4, level.target_words.Length); j++)
                            {
                                string word = level.target_words[j].word;
                                if (GUILayout.Toggle(selectedWord == word, word, "Button")) selectedWord = word;
                            }
                    EditorGUILayout.LabelField("额外词（" + level.extra_words.Length + "）", EditorStyles.boldLabel);
                    EditorGUILayout.LabelField(string.Join(", ", level.extra_words.Select(word => word.word).ToArray()), EditorStyles.wordWrappedLabel);
                }
            }
            if (GUILayout.Button("复制预览 JSON", GUILayout.Width(140))) EditorGUIUtility.systemCopyBuffer = json;
            jsonScroll = EditorGUILayout.BeginScrollView(jsonScroll, GUILayout.Height(280));
            EditorGUILayout.SelectableLabel(json, EditorStyles.textArea,
                GUILayout.Height(Mathf.Max(270, EditorStyles.textArea.CalcHeight(new GUIContent(json), Mathf.Max(100, position.width - 50)))));
            EditorGUILayout.EndScrollView();
        }

        private WordDictionary LoadDictionary()
        {
            if (dictionaryChoice < 0 || dictionaryChoice >= DictionaryNames.Length) throw new ArgumentException("请选择有效词库。");
            TextAsset asset = dictionaryChoice == 2 ? customDictionary : AssetDatabase.LoadAssetAtPath<TextAsset>(dictionaryChoice == 0 ? DictionaryPath : BackupDictionaryPath);
            if (asset == null) throw new FileNotFoundException("未找到所选词库：" + DictionaryNames[dictionaryChoice] + "，请检查文件或指定 TXT。");
            return new WordDictionary(asset.text, exclusionList == null ? "" : exclusionList.text);
        }

        private static GenerationSettings CopySettings(GenerationSettings original)
        { return JsonUtility.FromJson<GenerationSettings>(JsonUtility.ToJson(original)); }

        private HashSet<string> ExistingContentKeys(Func<bool> cancelled)
        {
            var keys = new HashSet<string>(StringComparer.Ordinal);
            string folder = Path.Combine(Application.dataPath, "Levels");
            if (!Directory.Exists(folder)) return keys;
            string[] files = Directory.GetFiles(folder, "*.level", SearchOption.AllDirectories);
            Array.Sort(files, StringComparer.Ordinal);
            for (int i = 0; i < files.Length; i++)
            {
                if (i % 32 == 0 && cancelled()) throw new OperationCanceledException();
                try
                {
                    var level = JsonUtility.FromJson<GeneratedLevel>(LevelGZipDecoder.Decode(files[i]));
                    if (level == null || level.target_words == null || level.letters == null)
                        throw new InvalidDataException("缺少关卡字段。");
                    keys.Add(WordTileGenerator.ContentKey(level));
                }
                catch (Exception exception)
                {
                    // Fail closed: unreadable references must not silently disable duplicate checking.
                    throw new InvalidDataException("无法读取重复检测参考文件：" + files[i], exception);
                }
            }
            return keys;
        }

        private void GeneratePreview()
        {
            preview = null;
            json = "";
            selectedWord = "";
            var timer = Stopwatch.StartNew();
            try
            {
                GenerationSettings parameters = CopySettings(settings);
                parameters.Validate();
                WordDictionary dictionary = LoadDictionary();
                Func<bool> cancelled = Progress("生成关卡", () => "搜索可解棋盘 / ID " + parameters.Id, () => 0.5f);
                HashSet<string> existing = ExistingContentKeys(Progress("检查现有关卡重复", () => "仅读取参考关卡进行去重", () => 0f));
                var result = WordTileGenerator.Generate(parameters, dictionary,
                    level => existing.Contains(WordTileGenerator.ContentKey(level)), cancelled);
                CheckRoundTrip(result, dictionary, parameters);
                preview = result;
                previewSettings = parameters;
                previewDictionary = dictionary;
                previewDictionaryName = DictionaryNames[dictionaryChoice] + " · " + dictionary.Words.Length + " 词";
                json = result.Level.ToJson();
                status = "生成成功：词库 " + dictionary.Words.Length + " 词，尝试 " + result.Attempts +
                    " 次，搜索 " + result.SearchNodes + " 节点，用时 " + timer.Elapsed.TotalSeconds.ToString("F2") + " 秒。";
            }
            catch (OperationCanceledException) { status = "已取消生成。"; }
            catch (Exception exception) { status = "生成失败：" + exception.Message; Debug.LogException(exception); }
            finally { EditorUtility.ClearProgressBar(); }
        }

        private static Func<bool> Progress(string title, Func<string> message, Func<float> fraction)
        {
            var timer = Stopwatch.StartNew();
            long previous = -100;
            return () =>
            {
                if (timer.ElapsedMilliseconds - previous < 100) return false;
                previous = timer.ElapsedMilliseconds;
                return EditorUtility.DisplayCancelableProgressBar(title, message(), fraction());
            };
        }

        private static void CheckRoundTrip(GenerationResult result, WordDictionary dictionary, GenerationSettings parameters)
        {
            WordTileGenerator.ValidatePaths(result);
            string text = result.Level.ToJson();
            var decoded = JsonUtility.FromJson<GeneratedLevel>(text);
            WordTileGenerator.Validate(decoded, dictionary, parameters);
            if (JsonUtility.ToJson(decoded) != JsonUtility.ToJson(result.Level)) throw new InvalidDataException("JSON 回读数据不匹配。");
        }

        private void ValidatePreview()
        {
            try { CheckRoundTrip(preview, previewDictionary, previewSettings); status = "验证通过：词条、四方向路径、全格覆盖、使用次数及 JSON 回读。"; }
            catch (Exception exception) { status = "验证失败：" + exception.Message; }
        }

        private void ExportPreview()
        {
            string path = EditorUtility.SaveFilePanel("导出当前预览 JSON", Path.GetDirectoryName(Application.dataPath), preview.Level.id.ToString(), "json");
            if (string.IsNullOrEmpty(path)) return;
            try
            {
                CheckRoundTrip(preview, previewDictionary, previewSettings);
                File.WriteAllText(path, json, new UTF8Encoding(false));
                AssetDatabase.Refresh();
                status = "已导出当前预览：" + path;
            }
            catch (Exception exception) { status = "导出失败：" + exception.Message; }
        }

        private void ExportBatch()
        {
            try
            {
                settings.Validate();
                if (batchCount < 1 || batchCount > 10000 || (long)settings.Id + batchCount - 1 > int.MaxValue)
                    throw new ArgumentException("批量数量必须为 1–10000，连续 ID 不能溢出。");
                WordDictionary dictionary = LoadDictionary();
                string parent = EditorUtility.OpenFolderPanel("选择批量导出目录（会创建新文件夹）", Path.GetDirectoryName(Application.dataPath), "");
                if (string.IsNullOrEmpty(parent)) return;
                HashSet<string> existing = ExistingContentKeys(Progress("检查现有关卡重复", () => "仅读取参考关卡进行去重", () => 0f));
                string folder = Path.Combine(parent, "GeneratedLevels_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff"));
                Directory.CreateDirectory(folder);
                var boards = new HashSet<string>(StringComparer.Ordinal);
                var log = new StringBuilder("ID\tSeed\tResult\tSeconds\n");
                log.Insert(0, "词库：" + DictionaryNames[dictionaryChoice] + "；实际词数：" + dictionary.Words.Length + "\n");
                int success = 0, failures = 0, current = 0;
                bool wasCancelled = false;
                var total = Stopwatch.StartNew();
                Func<bool> cancelled = Progress("批量生成关卡", () => "生成 " + (current + 1) + " / " + batchCount,
                    () => (float)current / batchCount);
                for (current = 0; current < batchCount; current++)
                {
                    GenerationSettings parameters = CopySettings(settings);
                    parameters.Id += current;
                    parameters.Seed = WordTileGenerator.BatchSeed(settings.Seed, current);
                    var timer = Stopwatch.StartNew();
                    try
                    {
                        if (cancelled()) throw new OperationCanceledException();
                        GenerationResult result = WordTileGenerator.Generate(parameters, dictionary,
                            level => boards.Contains(WordTileGenerator.BoardKey(level)) || existing.Contains(WordTileGenerator.ContentKey(level)), cancelled);
                        CheckRoundTrip(result, dictionary, parameters);
                        File.WriteAllText(Path.Combine(folder, parameters.Id + ".json"), result.Level.ToJson(), new UTF8Encoding(false));
                        boards.Add(WordTileGenerator.BoardKey(result.Level));
                        success++;
                        log.Append(parameters.Id).Append('\t').Append(parameters.Seed).Append("\tOK\t").Append(timer.Elapsed.TotalSeconds.ToString("F3")).Append('\n');
                    }
                    catch (OperationCanceledException) { wasCancelled = true; break; }
                    catch (Exception exception)
                    {
                        failures++;
                        log.Append(parameters.Id).Append('\t').Append(parameters.Seed).Append('\t').Append(exception.Message.Replace('\n', ' ').Replace('\t', ' '))
                            .Append('\t').Append(timer.Elapsed.TotalSeconds.ToString("F3")).Append('\n');
                        Debug.LogError("生成关卡 " + parameters.Id + " 失败：" + exception.Message);
                    }
                }
                log.Append("Success=").Append(success).Append(" Failed=").Append(failures).Append(" Cancelled=").Append(wasCancelled)
                    .Append(" Seconds=").Append(total.Elapsed.TotalSeconds.ToString("F3")).Append('\n');
                File.WriteAllText(Path.Combine(folder, "generation-report.txt"), log.ToString(), new UTF8Encoding(false));
                status = (wasCancelled ? "已取消" : "批量完成") + "：成功 " + success + "，失败 " + failures + "，未处理 " + (batchCount - success - failures) + "。目录：" + folder;
            }
            catch (OperationCanceledException) { status = "已取消重复检测，未开始导出。"; }
            catch (Exception exception) { status = "批量导出失败：" + exception.Message; Debug.LogException(exception); }
            finally { EditorUtility.ClearProgressBar(); AssetDatabase.Refresh(); }
        }
    }
}

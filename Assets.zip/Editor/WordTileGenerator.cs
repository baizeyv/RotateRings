using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WordTile.EditorTools
{
    [Serializable]
    public sealed class GenerationSettings
    {
        public int Width = 4, Height = 3, TargetCount = 10, MinLength = 3, MaxLength = 8;
        public int Seed = 1, Id = 1;
        public int ExtraCount = -1;

        public void Validate()
        {
            if (Width < 2 || Width > 6 || Height < 2 || Height > 6)
                throw new ArgumentException("棋盘宽高必须为 2–6。");
            if (TargetCount < 1 || TargetCount > 30) throw new ArgumentException("目标词数必须为 1–30。");
            if (ExtraCount < -1) throw new ArgumentException("额外词数量须为非负整数，或 -1（全部）。");
            if (MinLength < 1 || MaxLength < MinLength || MaxLength > Width * Height)
                throw new ArgumentException("词长必须满足 1 ≤ 最短 ≤ 最长 ≤ 格子数。");
            if ((long)TargetCount * MaxLength < Width * Height)
                throw new ArgumentException("目标词总长度不足以覆盖所有格子，请增加词数或最长词长。");
            if (Id < 1) throw new ArgumentException("关卡 ID 必须为正整数。");
        }
    }

    [Serializable]
    public sealed class LevelWord
    {
        public string word;
        public int type;
        public LevelWord() { }
        public LevelWord(string value) { word = value; type = 0; }
    }

    [Serializable]
    public sealed class LevelObstacle
    {
        public int required_words, id, type;
        public LevelCell[] cells;
    }

    [Serializable]
    public sealed class LevelCell { public int x, y; }

    [Serializable]
    public sealed class GeneratedLevel
    {
        public int id, width, height;
        public LevelWord[] target_words, extra_words;
        public string letters;
        public LevelObstacle[] obstacles = new LevelObstacle[0];

        public string ToJson()
        {
            var text = new StringBuilder();
            text.Append("{\"id\":").Append(id).Append(",\"width\":").Append(width)
                .Append(",\"height\":").Append(height).Append(",\"target_words\":");
            AppendWords(text, target_words);
            text.Append(",\"extra_words\":");
            AppendWords(text, extra_words);
            text.Append(",\"letters\":\"").Append(letters).Append("\",\"obstacles\":[]}");
            return LevelJsonPreview.Format(text.ToString());
        }

        private static void AppendWords(StringBuilder text, LevelWord[] words)
        {
            text.Append('[');
            for (int i = 0; i < words.Length; i++)
            {
                if (i > 0) text.Append(',');
                if (!WordDictionary.IsWord(words[i].word) || words[i].type != 0)
                    throw new ArgumentException("仅支持大写英文词和 type 0。");
                text.Append("{\"word\":\"").Append(words[i].word).Append("\",\"type\":0}");
            }
            text.Append(']');
        }
    }

    public sealed class GenerationResult
    {
        public GeneratedLevel Level;
        public Dictionary<string, int[]> Paths;
        public int[] Usage;
        public int Attempts, SearchNodes;
    }

    public sealed class WordDictionary
    {
        internal sealed class TrieNode
        {
            internal readonly Dictionary<char, TrieNode> Children = new Dictionary<char, TrieNode>();
            internal string Word;
        }

        internal readonly TrieNode Root = new TrieNode();
        public readonly string[] Words;
        private readonly HashSet<string> lookup;

        public WordDictionary(string text, string exclusions = "")
        {
            var excluded = new HashSet<string>(ReadWords(exclusions), StringComparer.Ordinal);
            Words = ReadWords(text).Where(word => !excluded.Contains(word)).Distinct(StringComparer.Ordinal)
                .OrderBy(word => word, StringComparer.Ordinal).ToArray();
            if (Words.Length == 0) throw new ArgumentException("词库为空，或词条已全部被排除。");
            lookup = new HashSet<string>(Words, StringComparer.Ordinal);
            foreach (string word in Words)
            {
                // Longer words cannot fit any supported board.
                if (word.Length > 36) continue;
                TrieNode node = Root;
                foreach (char letter in word)
                {
                    TrieNode child;
                    if (!node.Children.TryGetValue(letter, out child))
                        node.Children.Add(letter, child = new TrieNode());
                    node = child;
                }
                node.Word = word;
            }
        }

        public bool Contains(string word) { return lookup.Contains(word); }

        private static IEnumerable<string> ReadWords(string text)
        {
            foreach (string line in (text ?? "").Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
            {
                string word = line.Trim().ToUpperInvariant();
                if (IsWord(word)) yield return word;
            }
        }

        public static bool IsWord(string word)
        {
            return !string.IsNullOrEmpty(word) && word.All(letter => letter >= 'A' && letter <= 'Z');
        }
    }

    public static class WordTileGenerator
    {
        public const int MaxAttempts = 100;
        public const int MaxSearchNodes = 2000000;

        private sealed class Budget
        {
            internal int Nodes;
            private readonly int limit;
            private readonly Func<bool> cancelled;
            internal Budget(int limit, Func<bool> cancelled) { this.limit = limit; this.cancelled = cancelled; }
            internal void Spend()
            {
                if (Nodes >= limit) throw new InvalidOperationException("已达到搜索上限，请调整尺寸、词数或词长。");
                if ((Nodes++ % 1024) == 0 && cancelled != null && cancelled()) throw new OperationCanceledException();
            }
        }

        public static GenerationResult Generate(GenerationSettings settings, WordDictionary dictionary,
            Func<GeneratedLevel, bool> reject = null, Func<bool> cancelled = null, int nodeLimit = MaxSearchNodes)
        {
            settings.Validate();
            if (dictionary == null) throw new ArgumentNullException("dictionary");
            if (nodeLimit < 1 || nodeLimit > MaxSearchNodes) throw new ArgumentOutOfRangeException("nodeLimit");
            string[] candidates = dictionary.Words.Where(w => w.Length >= settings.MinLength && w.Length <= settings.MaxLength).ToArray();
            if (candidates.Length < settings.TargetCount) throw new ArgumentException("指定词长范围内的词库词数不足。");
            if (settings.ExtraCount >= 0 && dictionary.Words.Count(w => w.Length >= settings.MinLength && w.Length <= settings.Width * settings.Height)
                < (long)settings.TargetCount + settings.ExtraCount)
                throw new ArgumentException("词库可用词数不足以满足目标词和额外词数量。");
            var random = new Random(settings.Seed);
            var budget = new Budget(nodeLimit, cancelled);
            int[][] neighbours = Neighbours(settings.Width, settings.Height);
            for (int attempt = 1; attempt <= MaxAttempts; attempt++)
            {
                budget.Spend();
                var board = new char[settings.Width * settings.Height];
                var planted = new Dictionary<string, int[]>(StringComparer.Ordinal);
                // Plant whole words; every assigned letter is backed by a target path.
                while (board.Any(letter => letter == '\0') && planted.Count < settings.TargetCount)
                {
                    string bestWord = null;
                    int[] bestPath = null;
                    int bestCoverage = 0;
                    for (int sample = 0; sample < 80; sample++)
                    {
                        budget.Spend();
                        string word = candidates[random.Next(candidates.Length)];
                        if (planted.ContainsKey(word)) continue;
                        int[] path = PlaceWord(board, neighbours, word, random, budget);
                        if (path == null) continue;
                        int coverage = path.Count(cell => board[cell] == '\0');
                        if (coverage > bestCoverage)
                        { bestCoverage = coverage; bestWord = word; bestPath = path; }
                        if (bestCoverage == settings.MaxLength) break;
                    }
                    if (bestPath == null) break;
                    for (int i = 0; i < bestPath.Length; i++) board[bestPath[i]] = bestWord[i];
                    planted.Add(bestWord, bestPath);
                }
                if (board.Any(letter => letter == '\0')) continue;
                Dictionary<string, int[]> found = Scan(board, neighbours, dictionary.Root, budget);
                var remaining = found.Keys.Where(w => w.Length >= settings.MinLength && w.Length <= settings.MaxLength && !planted.ContainsKey(w))
                    .OrderBy(w => w, StringComparer.Ordinal).ToArray();
                if (remaining.Length + planted.Count < settings.TargetCount) continue;
                Shuffle(remaining, random);
                foreach (string word in remaining)
                {
                    if (planted.Count == settings.TargetCount) break;
                    planted.Add(word, found[word]);
                }
                string[] targets = SortWords(planted.Keys);
                string[] extras = SortWords(found.Keys.Where(w => !planted.ContainsKey(w) && w.Length >= settings.MinLength));
                if (settings.ExtraCount >= 0)
                {
                    if (extras.Length < settings.ExtraCount) continue;
                    if (settings.ExtraCount > 0) Shuffle(extras, random);
                    extras = SortWords(extras.Take(settings.ExtraCount));
                }
                var level = new GeneratedLevel
                {
                    id = settings.Id, width = settings.Width, height = settings.Height,
                    letters = string.Join(",", Enumerable.Range(0, settings.Height)
                        .Select(row => new string(board, row * settings.Width, settings.Width)).ToArray()),
                    target_words = targets.Select(w => new LevelWord(w)).ToArray(),
                    extra_words = extras.Select(w => new LevelWord(w)).ToArray()
                };
                if (reject != null && reject(level)) continue;
                Validate(level, dictionary, settings, budget);
                int[] usage = new int[board.Length];
                foreach (int[] path in planted.Values) foreach (int cell in path) usage[cell]++;
                var result = new GenerationResult { Level = level, Paths = planted, Usage = usage, Attempts = attempt, SearchNodes = budget.Nodes };
                ValidatePaths(result);
                return result;
            }
            throw new InvalidOperationException("尝试 100 个棋盘后仍未满足目标词数、额外词数、覆盖或去重要求，请调整尺寸、词数、词长或种子。");
        }

        private static int[] PlaceWord(char[] board, int[][] neighbours, string word, Random random, Budget budget)
        {
            int[] starts = Enumerable.Range(0, board.Length).ToArray();
            Shuffle(starts, random);
            int[] path = new int[word.Length];
            int localNodes = 0;
            foreach (int start in starts)
                if (PlaceStep(board, neighbours, word, 0, start, 0UL, path, random, budget, ref localNodes)) return path;
            return null;
        }

        private static bool PlaceStep(char[] board, int[][] neighbours, string word, int index, int cell,
            ulong visited, int[] path, Random random, Budget budget, ref int localNodes)
        {
            // ponytail: cap each placement at 500 nodes; increase only if valid custom-word boards fail often.
            if (++localNodes > 500) return false;
            budget.Spend();
            if ((visited & (1UL << cell)) != 0 || (board[cell] != '\0' && board[cell] != word[index])) return false;
            path[index] = cell;
            if (index == word.Length - 1) return true;
            visited |= 1UL << cell;
            int[] next = (int[])neighbours[cell].Clone();
            Shuffle(next, random);
            foreach (int neighbour in next)
                if (PlaceStep(board, neighbours, word, index + 1, neighbour, visited, path, random, budget, ref localNodes)) return true;
            return false;
        }

        private static Dictionary<string, int[]> Scan(char[] board, int[][] neighbours, WordDictionary.TrieNode root, Budget budget)
        {
            var found = new Dictionary<string, int[]>(StringComparer.Ordinal);
            var path = new int[board.Length];
            for (int cell = 0; cell < board.Length; cell++) ScanStep(board, neighbours, root, cell, 0UL, path, 0, found, budget);
            return found;
        }

        private static void ScanStep(char[] board, int[][] neighbours, WordDictionary.TrieNode node, int cell,
            ulong visited, int[] path, int depth, Dictionary<string, int[]> found, Budget budget)
        {
            budget.Spend();
            WordDictionary.TrieNode child;
            if ((visited & (1UL << cell)) != 0 || !node.Children.TryGetValue(board[cell], out child)) return;
            path[depth] = cell;
            if (child.Word != null && !found.ContainsKey(child.Word)) found.Add(child.Word, path.Take(depth + 1).ToArray());
            visited |= 1UL << cell;
            foreach (int next in neighbours[cell]) ScanStep(board, neighbours, child, next, visited, path, depth + 1, found, budget);
        }

        public static void Validate(GeneratedLevel level, WordDictionary dictionary, GenerationSettings settings)
        {
            Validate(level, dictionary, settings, new Budget(MaxSearchNodes, null));
        }

        private static void Validate(GeneratedLevel level, WordDictionary dictionary, GenerationSettings settings, Budget budget)
        {
            settings.Validate();
            if (level == null || level.id != settings.Id || level.width != settings.Width || level.height != settings.Height)
                throw new ArgumentException("关卡 ID 或尺寸不匹配。");
            char[] board = ReadBoard(level);
            if (level.obstacles == null || level.obstacles.Length != 0 || level.target_words == null || level.extra_words == null || level.target_words.Length != settings.TargetCount)
                throw new ArgumentException("目标词数量或障碍格式错误。");
            if (settings.ExtraCount >= 0 && level.extra_words.Length != settings.ExtraCount)
                throw new ArgumentException("额外词数量不符合设置。");
            var words = new HashSet<string>(StringComparer.Ordinal);
            foreach (LevelWord word in level.target_words.Concat(level.extra_words))
            {
                budget.Spend();
                if (word == null || !WordDictionary.IsWord(word.word) || word.type != 0 || !dictionary.Contains(word.word) || !words.Add(word.word))
                    throw new ArgumentException("词条非法、重复或不在词库中。");
                if (FindPath(board, level.width, level.height, word.word, budget) == null)
                    throw new ArgumentException("词条没有合法的四方向路径：" + word.word);
            }
            // Validate existence independently; the chosen paths are separately checked for full coverage.
            foreach (LevelWord word in level.target_words)
                if (word.word.Length < settings.MinLength || word.word.Length > settings.MaxLength)
                    throw new ArgumentException("目标词长度超出范围。");
            var coverage = new bool[board.Length];
            foreach (LevelWord word in level.target_words)
                MarkReachablePaths(board, level.width, level.height, word.word, coverage, budget);
            if (coverage.Any(covered => !covered)) throw new ArgumentException("目标词不能覆盖全部格子。");
        }

        public static void ValidatePaths(GenerationResult result)
        {
            char[] board = ReadBoard(result.Level);
            var counts = new int[board.Length];
            if (result.Paths.Count != result.Level.target_words.Length) throw new ArgumentException("路径数量不匹配。");
            foreach (LevelWord word in result.Level.target_words)
            {
                int[] path;
                if (!result.Paths.TryGetValue(word.word, out path) || path.Length != word.word.Length || path.Distinct().Count() != path.Length)
                    throw new ArgumentException("目标词路径缺失或重复使用格子。");
                for (int i = 0; i < path.Length; i++)
                {
                    int cell = path[i];
                    if (cell < 0 || cell >= board.Length || board[cell] != word.word[i]) throw new ArgumentException("路径字母不匹配。");
                    if (i > 0 && Distance(path[i - 1], cell, result.Level.width) != 1) throw new ArgumentException("路径必须四方向相邻。");
                    counts[cell]++;
                }
            }
            if (counts.Any(count => count == 0) || result.Usage == null || !counts.SequenceEqual(result.Usage))
                throw new ArgumentException("路径未覆盖全格或使用次数不匹配。");
        }

        public static string BoardKey(GeneratedLevel level)
        { return level.width + "x" + level.height + ":" + level.letters; }

        public static string ContentKey(GeneratedLevel level)
        { return BoardKey(level) + ":" + string.Join("|", level.target_words.Select(w => w.word).OrderBy(w => w, StringComparer.Ordinal).ToArray()); }

        public static int BatchSeed(int seed, int index) { return unchecked(seed + index * 104729); }

        private static char[] ReadBoard(GeneratedLevel level)
        {
            if (level.width < 2 || level.width > 6 || level.height < 2 || level.height > 6 || level.letters == null)
                throw new ArgumentException("棋盘尺寸非法。");
            string[] rows = level.letters.Split(',');
            if (rows.Length != level.height || rows.Any(row => row.Length != level.width || !WordDictionary.IsWord(row)))
                throw new ArgumentException("棋盘字母行或列数不匹配。");
            return string.Concat(rows).ToCharArray();
        }

        private static int[] FindPath(char[] board, int width, int height, string word, Budget budget)
        {
            var path = new int[word.Length];
            for (int cell = 0; cell < board.Length; cell++)
                if (FindStep(board, width, height, word, 0, cell, 0UL, path, budget)) return path;
            return null;
        }

        private static bool FindStep(char[] board, int width, int height, string word, int index, int cell,
            ulong visited, int[] path, Budget budget)
        {
            budget.Spend();
            if ((visited & (1UL << cell)) != 0 || board[cell] != word[index]) return false;
            path[index] = cell;
            if (index == word.Length - 1) return true;
            visited |= 1UL << cell;
            // This validator deliberately uses coordinates, independently of the generator's neighbour table.
            int x = cell % width, y = cell / width;
            if (x > 0 && FindStep(board, width, height, word, index + 1, cell - 1, visited, path, budget)) return true;
            if (x + 1 < width && FindStep(board, width, height, word, index + 1, cell + 1, visited, path, budget)) return true;
            if (y > 0 && FindStep(board, width, height, word, index + 1, cell - width, visited, path, budget)) return true;
            return y + 1 < height && FindStep(board, width, height, word, index + 1, cell + width, visited, path, budget);
        }

        private static void MarkReachablePaths(char[] board, int width, int height, string word, bool[] coverage, Budget budget)
        {
            // A cell is covered only when it belongs to a complete valid target-word path.
            for (int cell = 0; cell < board.Length; cell++)
            {
                var path = new int[word.Length];
                MarkStep(board, width, height, word, 0, cell, 0UL, path, coverage, budget);
            }
        }

        private static void MarkStep(char[] board, int width, int height, string word, int index, int cell,
            ulong visited, int[] path, bool[] coverage, Budget budget)
        {
            budget.Spend();
            if ((visited & (1UL << cell)) != 0 || board[cell] != word[index]) return;
            path[index] = cell;
            if (index == word.Length - 1)
            { foreach (int step in path) coverage[step] = true; return; }
            visited |= 1UL << cell;
            int x = cell % width, y = cell / width;
            if (x > 0) MarkStep(board, width, height, word, index + 1, cell - 1, visited, path, coverage, budget);
            if (x + 1 < width) MarkStep(board, width, height, word, index + 1, cell + 1, visited, path, coverage, budget);
            if (y > 0) MarkStep(board, width, height, word, index + 1, cell - width, visited, path, coverage, budget);
            if (y + 1 < height) MarkStep(board, width, height, word, index + 1, cell + width, visited, path, coverage, budget);
        }

        private static int Distance(int first, int second, int width)
        { return Math.Abs(first % width - second % width) + Math.Abs(first / width - second / width); }

        private static int[][] Neighbours(int width, int height)
        {
            var table = new int[width * height][];
            for (int cell = 0; cell < table.Length; cell++)
            {
                var adjacent = new List<int>(4);
                int x = cell % width, y = cell / width;
                if (x > 0) adjacent.Add(cell - 1);
                if (x + 1 < width) adjacent.Add(cell + 1);
                if (y > 0) adjacent.Add(cell - width);
                if (y + 1 < height) adjacent.Add(cell + width);
                table[cell] = adjacent.ToArray();
            }
            return table;
        }

        private static string[] SortWords(IEnumerable<string> words)
        { return words.OrderBy(w => w.Length).ThenBy(w => w, StringComparer.Ordinal).ToArray(); }

        private static void Shuffle<T>(T[] values, Random random)
        {
            for (int i = values.Length - 1; i > 0; i--)
            { int j = random.Next(i + 1); T value = values[i]; values[i] = values[j]; values[j] = value; }
        }
    }
}

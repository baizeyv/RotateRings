using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WordTile.EditorTools
{
    public sealed class PuzzleWord
    {
        public string Word;
        public readonly List<int[]> Paths = new List<int[]>();
    }

    public sealed class PuzzleSolutionWord
    {
        public string Word;
        public int[] Path;
    }

    public sealed class PuzzleSolveResult
    {
        public PuzzleWord[] Candidates;
        public readonly List<PuzzleSolutionWord[]> Solutions = new List<PuzzleSolutionWord[]>();
        public bool CandidatesComplete = true, SolutionsComplete = true;
        public int CandidateNodes, CombinationNodes;
        public string Message;

        public string ToText(int width)
        {
            var text = new StringBuilder();
            text.AppendLine("WordTile 候选词与完整组合（Levels 备用词库，四方向连接）");
            text.AppendLine(Message);
            text.AppendLine("候选搜索完整=" + CandidatesComplete + "；组合搜索完整=" + SolutionsComplete);
            foreach (var group in Candidates.GroupBy(word => word.Word.Length).OrderBy(group => group.Key))
                text.AppendLine(group.Key + " 字母：" + string.Join(", ", group.Select(word => word.Word).ToArray()));
            for (int i = 0; i < Solutions.Count; i++)
            {
                text.AppendLine("组合 " + (i + 1));
                foreach (PuzzleSolutionWord word in Solutions[i])
                    text.AppendLine(word.Word + "：" + FormatPath(word.Path, width));
            }
            return text.ToString();
        }

        public static string FormatPath(int[] path, int width)
        { return string.Join(" → ", path.Select(cell => "(" + cell % width + "," + cell / width + ")").ToArray()); }
    }

    public static class WordTilePuzzleSolver
    {
        public const int MaxSearchNodes = 2000000;
        public const int MaxCandidatePaths = 100000;

        public static int[] ParseLengths(string text)
        {
            string[] values = (text ?? "").Split(new[] { ',', '，', ';', '；', ' ', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            if (values.Length == 0 || values.Length > 100) throw new ArgumentException("请输入 1–100 个单词长度，例如 3,3,4。");
            var lengths = new int[values.Length];
            for (int i = 0; i < values.Length; i++)
                if (!int.TryParse(values[i], out lengths[i]) || lengths[i] < 1) throw new ArgumentException("单词长度必须为正整数。");
            return lengths;
        }

        private sealed class CandidateSearch
        {
            internal char[] Letters;
            internal int[] Counts, Path;
            internal int[][] Neighbours;
            internal HashSet<int> Lengths;
            internal int MaxLength, Nodes, Limit, PathCount;
            internal bool Complete = true;

            internal Func<bool> Cancelled;
            internal readonly Dictionary<string, PuzzleWord> Found = new Dictionary<string, PuzzleWord>(StringComparer.Ordinal);

            internal void Visit(int cell, WordDictionary.TrieNode node, ulong visited, int depth)
            {
                if (!Complete) return;
                if (Nodes >= Limit || PathCount >= MaxCandidatePaths) { Complete = false; return; }
                if (Nodes % 1024 == 0 && Cancelled != null && Cancelled()) throw new OperationCanceledException();
                Nodes++;
                WordDictionary.TrieNode next;
                if (Counts[cell] == 0 || (visited & (1UL << cell)) != 0 || !node.Children.TryGetValue(Letters[cell], out next)) return;
                Path[depth] = cell;
                if (next.Word != null && Lengths.Contains(depth + 1))
                {
                    PuzzleWord word;
                    if (!Found.TryGetValue(next.Word, out word)) Found.Add(next.Word, word = new PuzzleWord { Word = next.Word });
                    word.Paths.Add(Path.Take(depth + 1).ToArray());
                    PathCount++;
                }
                if (depth + 1 >= MaxLength) return;
                foreach (int adjacent in Neighbours[cell]) Visit(adjacent, next, visited | (1UL << cell), depth + 1);
            }
        }

        private sealed class CombinationSearch
        {
            internal PuzzleWord[][] Options;
            internal int[] Lengths, Remaining;
            internal bool[] Used;
            internal readonly HashSet<string> UsedWords = new HashSet<string>(StringComparer.Ordinal);
            internal readonly List<PuzzleSolutionWord> Chosen = new List<PuzzleSolutionWord>();
            internal readonly HashSet<string> FoundKeys = new HashSet<string>(StringComparer.Ordinal);
            internal PuzzleSolveResult Result;
            internal int Nodes, Limit, MaxSolutions;
            internal Func<bool> Cancelled;
            internal bool Complete = true;

            private bool Eligible(PuzzleWord word)
            {
                return !UsedWords.Contains(word.Word) && Chosen.All(chosen => chosen.Word.Length != word.Word.Length ||
                    string.CompareOrdinal(chosen.Word, word.Word) < 0);
            }

            private bool Spend()
            {
                if (!Complete) return false;
                if (Nodes >= Limit || Result.Solutions.Count >= MaxSolutions) { Complete = false; return false; }
                if (Nodes % 1024 == 0 && Cancelled != null && Cancelled()) throw new OperationCanceledException();
                Nodes++;
                return true;
            }

            internal void Visit()
            {
                if (!Spend()) return;
                if (Chosen.Count == Lengths.Length)
                {
                    if (Remaining.Any(count => count != 0)) return;
                    string key = string.Join("|", Chosen.Select(word => word.Word).OrderBy(word => word, StringComparer.Ordinal).ToArray());
                    // Multiple path assignments for the same word set are one answer; retain one valid assignment.
                    if (FoundKeys.Add(key)) Result.Solutions.Add(Chosen.OrderBy(word => word.Word.Length).ThenBy(word => word.Word, StringComparer.Ordinal).ToArray());
                    return;
                }
                int slot = -1, smallest = int.MaxValue;
                var checkedLengths = new HashSet<int>();
                for (int i = 0; i < Lengths.Length; i++)
                {
                    if (Used[i] || !checkedLengths.Add(Lengths[i])) continue;
                    int feasible = 0;
                    foreach (PuzzleWord word in Options[i])
                    {
                        if (!Spend()) return;
                        if (!Eligible(word)) continue;
                        bool fits = false;
                        foreach (int[] path in word.Paths)
                        {
                            if (!Spend()) return;
                            if (path.All(cell => Remaining[cell] > 0)) { fits = true; break; }
                        }
                        if (fits) feasible++;
                    }
                    if (feasible == 0) return;
                    if (feasible < smallest) { smallest = feasible; slot = i; }
                }
                Used[slot] = true;
                foreach (PuzzleWord word in Options[slot])
                {
                    if (!Spend()) break;
                    if (!Eligible(word)) continue;
                    foreach (int[] path in word.Paths)
                    {
                        if (!Spend()) break;
                        if (path.Any(cell => Remaining[cell] == 0)) continue;
                        foreach (int cell in path) Remaining[cell]--;
                        UsedWords.Add(word.Word);
                        Chosen.Add(new PuzzleSolutionWord { Word = word.Word, Path = path });
                        Visit();
                        Chosen.RemoveAt(Chosen.Count - 1);
                        UsedWords.Remove(word.Word);
                        foreach (int cell in path) Remaining[cell]++;
                    }
                }
                Used[slot] = false;
            }
        }

        public static PuzzleSolveResult Solve(int width, int height, string letters, int[] counts, int[] lengths,
            WordDictionary dictionary, int maxSolutions = 100, Func<bool> cancelled = null, int nodeLimit = MaxSearchNodes)
        {
            if (width < 1 || width > 6 || height < 1 || height > 6 || letters == null || letters.Length != width * height)
                throw new ArgumentException("棋盘宽高须为 1–6，字母数量须与格子数一致。");
            if (counts == null || counts.Length != letters.Length || counts.Any(count => count < 0 || count > 100))
                throw new ArgumentException("每格剩余次数须为 0–100。");
            char[] board = letters.ToUpperInvariant().ToCharArray();
            for (int i = 0; i < board.Length; i++)
                if (counts[i] > 0 && (board[i] < 'A' || board[i] > 'Z')) throw new ArgumentException("可用格子必须填写一个英文字母。");
            if (lengths == null || lengths.Length == 0 || lengths.Length > 100 || lengths.Any(length => length < 1 || length > board.Length))
                throw new ArgumentException("需要 1–100 个目标长度，每个长度必须为 1 到格子数。");
            if (dictionary == null) throw new ArgumentNullException("dictionary");
            if (maxSolutions < 1 || maxSolutions > 1000 || nodeLimit < 1 || nodeLimit > MaxSearchNodes) throw new ArgumentOutOfRangeException("搜索上限非法。");
            int[][] neighbours = Enumerable.Range(0, board.Length).Select(cell =>
                Enumerable.Range(0, board.Length).Where(next =>
                    Math.Abs(cell % width - next % width) + Math.Abs(cell / width - next / width) == 1).ToArray()).ToArray();
            var candidate = new CandidateSearch { Letters = board, Counts = counts, Neighbours = neighbours, Lengths = new HashSet<int>(lengths),
                Path = new int[board.Length], MaxLength = lengths.Max(), Limit = nodeLimit, Cancelled = cancelled };
            for (int cell = 0; cell < board.Length && candidate.Complete; cell++) candidate.Visit(cell, dictionary.Root, 0UL, 0);
            var result = new PuzzleSolveResult { Candidates = candidate.Found.Values.OrderBy(word => word.Word.Length)
                .ThenBy(word => word.Word, StringComparer.Ordinal).ToArray(), CandidatesComplete = candidate.Complete, CandidateNodes = candidate.Nodes };
            if (counts.Sum() != lengths.Sum())
            {
                result.Message = "无法组成完整答案：剩余次数总和 " + counts.Sum() + " 与目标长度总和 " + lengths.Sum() + " 不一致。候选词仍列出。";
                result.SolutionsComplete = true;
                return result;
            }
            var combination = new CombinationSearch { Options = lengths.Select(length => result.Candidates.Where(word => word.Word.Length == length).ToArray()).ToArray(),
                Lengths = lengths, Remaining = (int[])counts.Clone(), Used = new bool[lengths.Length], Result = result,
                Limit = nodeLimit, MaxSolutions = maxSolutions, Cancelled = cancelled };
            combination.Visit();
            result.CombinationNodes = combination.Nodes;
            result.SolutionsComplete = candidate.Complete && combination.Complete;
            result.Message = result.Solutions.Count > 0 ? "找到 " + result.Solutions.Count + " 组完整答案（同一词集合的不同路径合并显示）。" :
                result.SolutionsComplete ? "备用词库与四方向规则下，没有符合全部数量及长度约束的完整答案。" : "目前未找到完整答案，搜索尚未完整，不能判定无解。";
            if (!result.CandidatesComplete || !result.SolutionsComplete) result.Message += " 达到结果或搜索上限；当前结果不是全部。";
            return result;
        }
    }
}

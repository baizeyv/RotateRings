using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace WordTile.EditorTools
{
    public sealed class LevelDifficultyWindow : EditorWindow
    {
        [SerializeField] private DifficultyWeights weights = new DifficultyWeights();
        [SerializeField] private TextAsset customFrequencies;
        [SerializeField] private int levelId = 100020;
        [SerializeField] private string pastedJson = "";
        private GeneratedLevel level;
        private DifficultyReport report;
        private string status = "", selectedWord = "";
        private Vector2 scroll;
        private bool showInput;
        private const string FrequencyPath = "Assets/WordTile/Dictionaries/wordfreq-scowl-en.json";

        [MenuItem("Tools/WordTile/关卡难度分析")]
        private static void Open()
        { GetWindow<LevelDifficultyWindow>("关卡难度分析").minSize = new Vector2(780, 650); }

        public static void OpenForLevel(GeneratedLevel source)
        {
            var window = GetWindow<LevelDifficultyWindow>("关卡难度分析");
            window.minSize = new Vector2(780, 650);
            window.level = JsonUtility.FromJson<GeneratedLevel>(JsonUtility.ToJson(source));
            window.report = null;
            window.Analyze();
            window.Show();
        }

        private void OnGUI()
        {
            scroll = EditorGUILayout.BeginScrollView(scroll);
            EditorGUILayout.HelpBox("0–100 分，越高越难。启发式估算，尚未用玩家数据校准；路径按四方向连接分析。", MessageType.Info);
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("打开 JSON / .level 文件")) OpenFile();
                levelId = EditorGUILayout.IntField("Levels 关卡 ID", levelId);
                if (GUILayout.Button("按 ID 加载并分析", GUILayout.Width(150)))
                    LoadAndAnalyze(() => LevelGZipDecoder.Decode(Path.Combine(Application.dataPath, "Levels", levelId + ".level")));
            }
            showInput = EditorGUILayout.Foldout(showInput, "粘贴关卡 JSON", true);
            if (showInput)
            {
                pastedJson = EditorGUILayout.TextArea(pastedJson, GUILayout.Height(110));
                if (GUILayout.Button("分析粘贴的 JSON")) LoadAndAnalyze(() => pastedJson);
            }
            customFrequencies = (TextAsset)EditorGUILayout.ObjectField("自定义词频 JSON（可选）", customFrequencies, typeof(TextAsset), false);
            EditorGUILayout.LabelField("默认词频", "wordfreq 3.1.1 · 已覆盖内置词库中的 37,001 词");
            using (new EditorGUILayout.HorizontalScope())
            {
                weights.Familiarity = EditorGUILayout.FloatField("熟悉度权重", weights.Familiarity);
                weights.Length = EditorGUILayout.FloatField("词长权重", weights.Length);
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                weights.Turns = EditorGUILayout.FloatField("转弯权重", weights.Turns);
                weights.Interference = EditorGUILayout.FloatField("干扰权重", weights.Interference);
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(level == null))
                    if (GUILayout.Button("分析 / 应用当前权重")) Analyze();
                using (new EditorGUI.DisabledScope(report == null))
                {
                    if (GUILayout.Button("复制难度报告")) EditorGUIUtility.systemCopyBuffer = report.ToText();
                    if (GUILayout.Button("导出难度报告 TXT")) ExportReport();
                }
            }
            if (!string.IsNullOrEmpty(status)) EditorGUILayout.HelpBox(status, MessageType.None);
            if (report != null) DrawReport();
            EditorGUILayout.EndScrollView();
        }

        private void OpenFile()
        {
            string path = EditorUtility.OpenFilePanelWithFilters("打开关卡", Path.GetDirectoryName(Application.dataPath),
                new[] { "关卡文件", "json,level", "所有文件", "*" });
            if (!string.IsNullOrEmpty(path)) LoadAndAnalyze(() =>
                string.Equals(Path.GetExtension(path), ".level", StringComparison.OrdinalIgnoreCase)
                    ? LevelGZipDecoder.Decode(path) : File.ReadAllText(path));
        }

        private void LoadAndAnalyze(Func<string> read)
        {
            report = null;
            level = null;
            try { level = JsonUtility.FromJson<GeneratedLevel>(read()); Analyze(); }
            catch (Exception exception) { status = "读取失败：" + exception.Message; }
        }

        private void Analyze()
        {
            report = null;
            selectedWord = "";
            var timer = Stopwatch.StartNew();
            long lastUpdate = -100;
            try
            {
                TextAsset frequencyText = customFrequencies != null ? customFrequencies : AssetDatabase.LoadAssetAtPath<TextAsset>(FrequencyPath);
                WordFrequencyLookup frequency = frequencyText == null ? null :
                    new WordFrequencyLookup(JsonUtility.FromJson<FrequencyAsset>(frequencyText.text));
                report = LevelDifficultyAnalyzer.Analyze(level, frequency, weights, () =>
                {
                    if (timer.ElapsedMilliseconds - lastUpdate < 100) return false;
                    lastUpdate = timer.ElapsedMilliseconds;
                    return EditorUtility.DisplayCancelableProgressBar("分析关卡难度", "枚举目标词的四方向路径", 0.5f);
                });
                status = "分析完成：" + timer.Elapsed.TotalSeconds.ToString("F2") + " 秒，搜索 " + report.SearchNodes + " 节点。";
            }
            catch (OperationCanceledException) { status = "已取消分析。"; }
            catch (Exception exception) { status = "分析失败：" + exception.Message; }
            finally { EditorUtility.ClearProgressBar(); }
        }

        private void DrawReport()
        {
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("ID " + report.LevelId + " · " + report.Grade +
                (report.ScoreAvailable ? " · " + report.Score.ToString("F1") + " / 100" : " · 无有效总分"), EditorStyles.boldLabel);
            EditorGUILayout.LabelField("目标词 " + report.Words.Length + " · 总字母量 " + report.Words.Sum(word => word.Word.Length) +
                " · 已发现路径覆盖 " + report.CoveredCells + "/" + report.Width * report.Height);
            DrawComponent("单词熟悉度", report.FamiliarityScore, report.Weights[0], "词频越低，分数越高；缺失词频取中性 50 分。");
            DrawComponent("词长", report.LengthScore, report.Weights[1], "3 字母及以下为 0 分，10 字母及以上为 100 分。");
            DrawComponent("路径转弯", report.TurnScore, report.Weights[2], "使用枚举路径中的最少转弯数，多条合法路径适当降低分数。");
            DrawComponent("搜索干扰", report.InterferenceScore, report.Weights[3], "匹配了单词前缀，但最终不能完成单词的分支越多，分数越高。");
            foreach (string note in report.Notes) EditorGUILayout.HelpBox(note, MessageType.Info);
            EditorGUILayout.LabelField("各词解释（按难度排序，点击查看最少转弯路径）", EditorStyles.boldLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Label("目标词", GUILayout.Width(125));
                GUILayout.Label("Zipf", GUILayout.Width(90));
                GUILayout.Label("合法路径", GUILayout.Width(100));
                GUILayout.Label("最少转弯", GUILayout.Width(100));
                GUILayout.Label("死路前缀", GUILayout.Width(85));
                GUILayout.Label("词难度");
            }
            foreach (WordDifficulty word in report.Words.OrderByDescending(word => word.Score).ThenBy(word => word.Word, StringComparer.Ordinal))
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button(word.Word, GUILayout.Width(125))) selectedWord = word.Word;
                    GUILayout.Label(word.FrequencyKnown ? word.Zipf.ToString("F2") : "未知", GUILayout.Width(90));
                    GUILayout.Label((word.SearchComplete ? "" : "≥") + word.PathCount, GUILayout.Width(100));
                    GUILayout.Label(word.PathCount == 0 ? "—" : (word.SearchComplete ? "" : "已发现 ") + word.MinTurns, GUILayout.Width(100));
                    GUILayout.Label((word.SearchComplete ? "" : "≥") + word.DeadPrefixes, GUILayout.Width(85));
                    GUILayout.Label(word.PathCount == 0 ? "—" : word.Score.ToString("F1") + (word.SearchComplete ? "" : "（暂估）"));
                }
            if (!string.IsNullOrEmpty(selectedWord)) DrawPath(report.Words.First(word => word.Word == selectedWord));
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("简单 <35；普通 35–<65；困难 ≥65。修改权重后需重新分析。", EditorStyles.wordWrappedLabel);
            EditorGUILayout.LabelField("词频来源：" + report.FrequencySource + "\n许可：" + report.FrequencyLicense, EditorStyles.wordWrappedLabel);
        }

        private static void DrawComponent(string name, float score, float weight, string explanation)
        {
            EditorGUILayout.LabelField(name + "：" + score.ToString("F1") + " 分 · 权重 " + (weight * 100).ToString("F1") +
                "% · 贡献 " + (score * weight).ToString("F1") + " 分", EditorStyles.boldLabel);
            EditorGUILayout.LabelField(explanation, EditorStyles.wordWrappedLabel);
        }

        private void DrawPath(WordDifficulty word)
        {
            EditorGUILayout.LabelField(word.Word + " 分项：熟悉度 " + word.FamiliarityScore.ToString("F1") +
                " · 词长 " + word.LengthScore.ToString("F1") + (word.PathCount > 0 ?
                " · 转弯 " + word.TurnScore.ToString("F1") + " · 干扰 " + word.InterferenceScore.ToString("F1") : " · 路径项尚无有效结果"), EditorStyles.wordWrappedLabel);
            if (word.PathCount == 0) { EditorGUILayout.HelpBox(word.SearchComplete ? "该词在四方向规则下没有合法路径。" : "搜索尚未找到该词路径。", MessageType.Info); return; }
            EditorGUILayout.LabelField(word.Word + " · " + (word.SearchComplete ? "最少转弯路径" : "已发现最少转弯路径"));
            string letters = level.letters.Replace(",", "");
            for (int row = 0; row < report.Height; row++)
                using (new EditorGUILayout.HorizontalScope())
                    for (int column = 0; column < report.Width; column++)
                    {
                        int cell = row * report.Width + column;
                        int step = Array.IndexOf(word.EasiestPath, cell);
                        Color previous = GUI.backgroundColor;
                        if (step >= 0) GUI.backgroundColor = Color.cyan;
                        GUILayout.Box(letters[cell] + (step >= 0 ? "\n" + (step + 1) : ""), GUILayout.Width(48), GUILayout.Height(44));
                        GUI.backgroundColor = previous;
                    }
        }

        private void ExportReport()
        {
            string path = EditorUtility.SaveFilePanel("导出难度解释报告", Path.GetDirectoryName(Application.dataPath), report.LevelId + "-difficulty", "txt");
            if (string.IsNullOrEmpty(path)) return;
            try { File.WriteAllText(path, report.ToText(), new UTF8Encoding(false)); AssetDatabase.Refresh(); status = "已导出：" + path; }
            catch (Exception exception) { status = "导出失败：" + exception.Message; }
        }
    }
}

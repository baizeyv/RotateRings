using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace WordTile.EditorTools
{
    public sealed class WordTilePuzzleSolverWindow : EditorWindow
    {
        [SerializeField] private int width = 4, height = 3, maxSolutions = 100;
        [SerializeField] private string[] letters = new string[12];
        [SerializeField] private int[] counts = Enumerable.Repeat(1, 12).ToArray();
        [SerializeField] private string lengthText = "3,3,4";
        [SerializeField] private string completedWords = "";
        private int gridWidth = 4, gridHeight = 3;
        private PuzzleSolveResult result;
        private int[] selectedPath = new int[0];
        private string status = "", selection = "";
        private Vector2 scroll;
        private const string DictionaryPath = "Assets/WordTile/Dictionaries/levels-backup-en.txt";

        [MenuItem("Tools/WordTile/棋盘找词与解答")]
        private static void Open()
        { GetWindow<WordTilePuzzleSolverWindow>("棋盘找词与解答").minSize = new Vector2(650, 600); }

        private void OnEnable()
        {
            width = Mathf.Clamp(width, 1, 6);
            height = Mathf.Clamp(height, 1, 6);
            gridWidth = width;
            gridHeight = height;
            if (letters == null || letters.Length != width * height) letters = new string[width * height];
            if (counts == null || counts.Length != width * height) counts = Enumerable.Repeat(1, width * height).ToArray();
        }

        private void OnGUI()
        {
            scroll = EditorGUILayout.BeginScrollView(scroll);
            EditorGUILayout.HelpBox("使用 Levels 备用词库。四方向相邻连接，一个词内不能重复使用格子；完整答案中每个词只用一次，并恰好耗尽各格次数。", MessageType.Info);
            EditorGUI.BeginChangeCheck();
            width = EditorGUILayout.IntSlider("棋盘宽", width, 1, 6);
            height = EditorGUILayout.IntSlider("棋盘高", height, 1, 6);
            if (width != gridWidth || height != gridHeight) ResizeBoard();
            EditorGUILayout.LabelField("每格：上方输入字母，下方输入剩余次数（0 为不可用，可留空）。左上角为 (0,0)。", EditorStyles.wordWrappedLabel);
            for (int row = 0; row < height; row++)
                using (new EditorGUILayout.HorizontalScope())
                    for (int column = 0; column < width; column++)
                    {
                        int cell = row * width + column;
                        Color previous = GUI.backgroundColor;
                        if (selectedPath.Contains(cell)) GUI.backgroundColor = Color.cyan;
                        using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox, GUILayout.Width(76)))
                        {
                            int step = Array.IndexOf(selectedPath, cell);
                            GUILayout.Label("(" + column + "," + row + ")" + (step >= 0 ? " #" + (step + 1) : ""));
                            letters[cell] = EditorGUILayout.TextField(letters[cell] ?? "", GUILayout.Width(60));
                            counts[cell] = EditorGUILayout.IntField(counts[cell], GUILayout.Width(60));
                        }
                        GUI.backgroundColor = previous;
                    }
            lengthText = EditorGUILayout.TextField("目标词长度列表", lengthText);
            EditorGUILayout.LabelField("例如 3,3,4 表示两个 3 字母词和一个 4 字母词；输入当前尚未完成的词长。", EditorStyles.wordWrappedLabel);
            completedWords = EditorGUILayout.TextField("已完成单词（可选）", completedWords);
            EditorGUILayout.LabelField("已完成词不会再次作为候选；多个词可用逗号或空格分隔。", EditorStyles.wordWrappedLabel);
            maxSolutions = EditorGUILayout.IntField("最多显示完整组合", maxSolutions);
            if (EditorGUI.EndChangeCheck()) { result = null; selectedPath = new int[0]; selection = ""; status = "输入已修改，请重新搜索。"; }
            EditorGUILayout.LabelField("剩余次数总和", counts.Sum(count => (long)count).ToString());
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("找词并求完整组合")) Search();
                using (new EditorGUI.DisabledScope(result == null))
                {
                    if (GUILayout.Button("复制结果")) EditorGUIUtility.systemCopyBuffer = result.ToText(width);
                    if (GUILayout.Button("导出结果 TXT")) Export();
                }
            }
            if (!string.IsNullOrEmpty(status)) EditorGUILayout.HelpBox(status, MessageType.None);
            if (!string.IsNullOrEmpty(selection)) EditorGUILayout.LabelField(selection, EditorStyles.wordWrappedLabel);
            if (result != null) DrawResults();
            EditorGUILayout.EndScrollView();
        }

        private void ResizeBoard()
        {
            var nextLetters = new string[width * height];
            var nextCounts = Enumerable.Repeat(1, width * height).ToArray();
            for (int y = 0; y < Math.Min(height, gridHeight); y++)
                for (int x = 0; x < Math.Min(width, gridWidth); x++)
                { nextLetters[y * width + x] = letters[y * gridWidth + x]; nextCounts[y * width + x] = counts[y * gridWidth + x]; }
            letters = nextLetters;
            counts = nextCounts;
            gridWidth = width;
            gridHeight = height;
        }

        private void Search()
        {
            result = null;
            selectedPath = new int[0];
            selection = "";
            var timer = Stopwatch.StartNew();
            long last = -100;
            try
            {
                string[] board = letters.Select((letter, i) =>
                {
                    string value = (letter ?? "").Trim().ToUpperInvariant();
                    if (value.Length == 0 && counts[i] == 0) return " ";
                    if (value.Length != 1) throw new ArgumentException("格子 (" + i % width + "," + i / width + ") 必须输入一个字母。");
                    return value;
                }).ToArray();
                TextAsset asset = AssetDatabase.LoadAssetAtPath<TextAsset>(DictionaryPath);
                if (asset == null) throw new FileNotFoundException("未找到 Levels 备用词库。");
                string excluded = string.Join("\n", (completedWords ?? "").Split(new[] { ',', '，', ';', '；', ' ', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries));
                result = WordTilePuzzleSolver.Solve(width, height, string.Concat(board), counts,
                    WordTilePuzzleSolver.ParseLengths(lengthText), new WordDictionary(asset.text, excluded), maxSolutions, () =>
                    {
                        if (timer.ElapsedMilliseconds - last < 100) return false;
                        last = timer.ElapsedMilliseconds;
                        return EditorUtility.DisplayCancelableProgressBar("搜索棋盘", "枚举候选路径并匹配剩余次数", 0.5f);
                    });
                status = result.Message + " 候选词 " + result.Candidates.Length + " 个，用时 " + timer.Elapsed.TotalSeconds.ToString("F2") + " 秒。";
            }
            catch (OperationCanceledException) { status = "已取消搜索。"; }
            catch (Exception exception) { status = "搜索失败：" + exception.Message; }
            finally { EditorUtility.ClearProgressBar(); }
        }

        private void Highlight(string word, int[] path)
        {
            selectedPath = path;
            selection = word + "：" + PuzzleSolveResult.FormatPath(path, width);
            Repaint();
        }

        private void DrawResults()
        {
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("完整答案组合（点击单词查看该组合的实际路径）", EditorStyles.boldLabel);
            for (int i = 0; i < result.Solutions.Count; i++)
            {
                EditorGUILayout.LabelField("组合 " + (i + 1));
                PuzzleSolutionWord[] solution = result.Solutions[i];
                for (int start = 0; start < solution.Length; start += 5)
                    using (new EditorGUILayout.HorizontalScope())
                        for (int j = start; j < Math.Min(start + 5, solution.Length); j++)
                        { PuzzleSolutionWord word = solution[j]; if (GUILayout.Button(word.Word)) Highlight(word.Word, word.Path); }
            }
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("按目标长度列出的全部候选词（不保证每词都能参与完整组合）", EditorStyles.boldLabel);
            if (!result.CandidatesComplete) EditorGUILayout.HelpBox("候选搜索达到上限，以下仅为已发现部分。", MessageType.Warning);
            foreach (var group in result.Candidates.GroupBy(word => word.Word.Length))
            {
                PuzzleWord[] words = group.ToArray();
                EditorGUILayout.LabelField(group.Key + " 字母 · " + words.Length + " 词");
                for (int start = 0; start < words.Length; start += 5)
                    using (new EditorGUILayout.HorizontalScope())
                        for (int j = start; j < Math.Min(start + 5, words.Length); j++)
                        {
                            PuzzleWord word = words[j];
                            if (GUILayout.Button(word.Word + "（" + word.Paths.Count + " 路径）")) Highlight(word.Word, word.Paths[0]);
                        }
            }
        }

        private void Export()
        {
            string path = EditorUtility.SaveFilePanel("导出棋盘搜索结果", Path.GetDirectoryName(Application.dataPath), "puzzle-solutions", "txt");
            if (string.IsNullOrEmpty(path)) return;
            try { File.WriteAllText(path, result.ToText(width), new UTF8Encoding(false)); AssetDatabase.Refresh(); status = "已导出：" + path; }
            catch (Exception exception) { status = "导出失败：" + exception.Message; }
        }
    }
}

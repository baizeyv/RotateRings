using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace WordTile.EditorTools
{
    [Serializable]
    public sealed class FrequencyEntry { public string word; public float zipf; }

    [Serializable]
    public sealed class FrequencyAsset
    {
        public string source, license, attribution;
        public FrequencyEntry[] entries;
    }

    public sealed class WordFrequencyLookup
    {
        private readonly Dictionary<string, float> values = new Dictionary<string, float>(StringComparer.Ordinal);
        public readonly string Source, License;

        public WordFrequencyLookup(FrequencyAsset asset)
        {
            if (asset == null || asset.entries == null || string.IsNullOrWhiteSpace(asset.source) ||
                string.IsNullOrWhiteSpace(asset.license) || string.IsNullOrWhiteSpace(asset.attribution))
                throw new ArgumentException("词频 JSON 必须包含 source、license、attribution 和 entries。");
            Source = asset.source;
            License = asset.license;
            foreach (FrequencyEntry entry in asset.entries)
            {
                if (entry == null || !WordDictionary.IsWord(entry.word) || float.IsNaN(entry.zipf) ||
                    float.IsInfinity(entry.zipf) || entry.zipf < 0 || entry.zipf > 9 || values.ContainsKey(entry.word))
                    throw new ArgumentException("词频条目须为唯一的大写英文词，Zipf 为 0–9 的有限数值。");
                values.Add(entry.word, entry.zipf);
            }
        }

        public bool TryGet(string word, out float zipf) { return values.TryGetValue(word, out zipf); }
    }

    [Serializable]
    public sealed class DifficultyWeights
    {
        public float Familiarity = 40, Length = 20, Turns = 20, Interference = 20;

        internal float[] Normalized()
        {
            float[] values = { Familiarity, Length, Turns, Interference };
            if (values.Any(value => float.IsNaN(value) || float.IsInfinity(value) || value < 0 || value > 100))
                throw new ArgumentException("各项权重必须为 0–100 的有限数值。");
            float total = values.Sum();
            if (total == 0) throw new ArgumentException("至少一项权重必须大于 0。");
            return values.Select(value => value / total).ToArray();
        }
    }

    [Serializable]
    public sealed class WordDifficulty
    {
        public string Word;
        public bool FrequencyKnown, SearchComplete;
        public float Zipf, FamiliarityScore, LengthScore, TurnScore, InterferenceScore, Score;
        public int PathCount, MinTurns, SearchNodes, DeadPrefixes;
        public int[] EasiestPath = new int[0];
    }

    [Serializable]
    public sealed class DifficultyReport
    {
        public int LevelId, Width, Height, SearchNodes, MissingFrequencies, UnsolvableWords, UnfinishedWords, CoveredCells;
        public float Score, FamiliarityScore, LengthScore, TurnScore, InterferenceScore;
        public bool ScoreAvailable, SearchComplete;
        public string Grade, FrequencySource, FrequencyLicense;
        public float[] Weights;
        public WordDifficulty[] Words;
        public string[] Notes;

        public string ToText()
        {
            var text = new StringBuilder();
            text.AppendLine("关卡难度解释 / ID " + LevelId + " / " + Width + "×" + Height);
            text.AppendLine("启发式估算，未使用玩家数据校准；不代表实测完成时间。");
            text.AppendLine("结果：" + Grade + (ScoreAvailable ? " / " + Score.ToString("F1", CultureInfo.InvariantCulture) + " 分" : " / 无有效总分"));
            text.AppendLine("分项（0–100，越高越难）：熟悉度=" + FamiliarityScore.ToString("F1") + " 词长=" + LengthScore.ToString("F1") +
                " 转弯=" + TurnScore.ToString("F1") + " 干扰=" + InterferenceScore.ToString("F1"));
            text.AppendLine("归一化权重：" + string.Join(" / ", Weights.Select(weight => (weight * 100).ToString("F1") + "%").ToArray()));
            text.AppendLine("目标词=" + Words.Length + " 总字母量=" + Words.Sum(word => word.Word.Length) +
                " 全部已发现路径覆盖=" + CoveredCells + "/" + Width * Height + " 搜索节点=" + SearchNodes);
            foreach (string note in Notes) text.AppendLine("说明：" + note);
            text.AppendLine("单词\tZipf\t路径数\t最少转弯\t死路前缀\t难度\t搜索完整");
            foreach (WordDifficulty word in Words.OrderByDescending(word => word.Score).ThenBy(word => word.Word, StringComparer.Ordinal))
                text.AppendLine(word.Word + "\t" + (word.FrequencyKnown ? word.Zipf.ToString("F2") : "未知（中性50分）") + "\t" +
                    (word.SearchComplete ? "" : "至少 ") + word.PathCount + "\t" + (word.PathCount == 0 ? "—" : word.MinTurns.ToString()) + "\t" +
                    word.DeadPrefixes + "\t" + (word.PathCount == 0 ? "—" : word.Score.ToString("F1")) + "\t" + word.SearchComplete);
            text.AppendLine("公式：熟悉度=clamp((5.5-Zipf)/3)×100；词长=clamp((长度-3)/7)×100。");
            text.AppendLine("转弯=最少转弯/max(1,长度-2)×100÷(1+0.15×log2(路径数))；干扰=clamp(log(1+死路前缀)/log(51))×100。");
            text.AppendLine("每项取目标词平均后加权；简单<35，普通35–<65，困难≥65。阈值及公式均为初始设计参数。");
            text.AppendLine("词频来源：" + FrequencySource);
            text.AppendLine("词频数据许可：" + FrequencyLicense);
            text.AppendLine("完整原始词频署名及数据来源保存在词频 JSON 的 attribution 字段中；默认文件为 wordfreq-scowl-en.json。");
            return text.ToString();
        }
    }

    public static class LevelDifficultyAnalyzer
    {
        public const int MaxSearchNodes = 2000000;
        public const int MaxNodesPerWord = 100000;
        public const int MaxPathsPerWord = 10000;

        private sealed class Search
        {
            internal readonly char[] Board;
            internal readonly int Width, Height, Limit, PathLimit;
            internal readonly Func<bool> Cancelled;
            internal int TotalNodes, WordNodes;
            internal bool CutOff;
            internal bool[] Covered;
            internal WordDifficulty Result;
            internal int[] Path;

            internal Search(char[] board, int width, int height, int limit, int pathLimit, Func<bool> cancelled)
            { Board = board; Width = width; Height = height; Limit = limit; PathLimit = pathLimit; Cancelled = cancelled; Covered = new bool[board.Length]; }

            internal bool Visit(int cell, int index, ulong visited, int previousDirection, int turns)
            {
                if (TotalNodes >= Limit || WordNodes >= MaxNodesPerWord || Result.PathCount >= PathLimit)
                { CutOff = true; return false; }
                if (TotalNodes % 1024 == 0 && Cancelled != null && Cancelled()) throw new OperationCanceledException();
                TotalNodes++;
                WordNodes++;
                if ((visited & (1UL << cell)) != 0 || Board[cell] != Result.Word[index]) return false;
                Path[index] = cell;
                if (index == Result.Word.Length - 1)
                {
                    Result.PathCount++;
                    foreach (int step in Path) Covered[step] = true;
                    if (turns < Result.MinTurns)
                    { Result.MinTurns = turns; Result.EasiestPath = (int[])Path.Clone(); }
                    return true;
                }
                visited |= 1UL << cell;
                int x = cell % Width, y = cell / Width;
                bool found = false;
                if (x > 0) found |= Next(cell - 1, index, visited, -1, previousDirection, turns);
                if (x + 1 < Width) found |= Next(cell + 1, index, visited, 1, previousDirection, turns);
                if (y > 0) found |= Next(cell - Width, index, visited, -Width, previousDirection, turns);
                if (y + 1 < Height) found |= Next(cell + Width, index, visited, Width, previousDirection, turns);
                if (!found && !CutOff) Result.DeadPrefixes++;
                return found;
            }

            private bool Next(int cell, int index, ulong visited, int direction, int previousDirection, int turns)
            {
                return Visit(cell, index + 1, visited, direction,
                    turns + (previousDirection != 0 && previousDirection != direction ? 1 : 0));
            }
        }

        public static DifficultyReport Analyze(GeneratedLevel level, WordFrequencyLookup frequencies, DifficultyWeights weights = null,
            Func<bool> cancelled = null, int nodeLimit = MaxSearchNodes, int pathLimit = MaxPathsPerWord)
        {
            if (level == null || level.width < 2 || level.width > 6 || level.height < 2 || level.height > 6 || level.letters == null)
                throw new ArgumentException("需要宽高为 2–6 的关卡及 letters 字段。");
            string[] rows = level.letters.Split(',');
            if (rows.Length != level.height || rows.Any(row => row.Length != level.width || !WordDictionary.IsWord(row)))
                throw new ArgumentException("棋盘行列数不匹配，或含非大写英文字母。");
            if (level.target_words == null || level.target_words.Length == 0 || level.target_words.Length > 1000 ||
                level.target_words.Any(word => word == null || !WordDictionary.IsWord(word.word)) ||
                level.target_words.Select(word => word.word).Distinct(StringComparer.Ordinal).Count() != level.target_words.Length)
                throw new ArgumentException("目标词须为不重复的大写英文词，数量为 1–1000。");
            if (nodeLimit < 1 || nodeLimit > MaxSearchNodes || pathLimit < 1 || pathLimit > MaxPathsPerWord)
                throw new ArgumentOutOfRangeException("分析搜索上限非法。");
            float[] normalized = (weights ?? new DifficultyWeights()).Normalized();
            var search = new Search(string.Concat(rows).ToCharArray(), level.width, level.height, nodeLimit, pathLimit, cancelled);
            var words = new List<WordDifficulty>();
            foreach (LevelWord target in level.target_words)
            {
                var result = new WordDifficulty { Word = target.word, MinTurns = int.MaxValue };
                search.Result = result;
                search.WordNodes = 0;
                search.CutOff = false;
                search.Path = new int[Math.Min(target.word.Length, search.Board.Length)];
                if (target.word.Length <= search.Board.Length)
                    for (int cell = 0; cell < search.Board.Length && !search.CutOff; cell++) search.Visit(cell, 0, 0UL, 0, 0);
                result.SearchComplete = !search.CutOff;
                result.SearchNodes = search.WordNodes;
                result.FrequencyKnown = frequencies != null && frequencies.TryGet(target.word, out result.Zipf);
                result.FamiliarityScore = result.FrequencyKnown ? Clamp((5.5f - result.Zipf) / 3f) * 100 : 50;
                result.LengthScore = Clamp((target.word.Length - 3) / 7f) * 100;
                if (result.PathCount > 0)
                {
                    result.TurnScore = (float)(result.MinTurns / (double)Math.Max(1, target.word.Length - 2) * 100 /
                        (1 + 0.15 * Math.Log(result.PathCount, 2)));
                    result.InterferenceScore = Clamp((float)(Math.Log(1 + result.DeadPrefixes) / Math.Log(51))) * 100;
                    result.Score = Weighted(result.FamiliarityScore, result.LengthScore, result.TurnScore, result.InterferenceScore, normalized);
                }
                else result.MinTurns = -1;
                words.Add(result);
            }
            bool allFound = words.All(word => word.PathCount > 0);
            bool complete = words.All(word => word.SearchComplete);
            var notes = new List<string> { "基础棋盘按四方向连接分析，单个词不能重复使用格子；评分不模拟字母耗尽。" };
            int missing = words.Count(word => !word.FrequencyKnown);
            if (missing > 0) notes.Add(missing + " 个目标词缺少词频，熟悉度暂用中性 50 分；不将缺失视为生僻词。");
            if (!complete) notes.Add("达到路径数或搜索节点上限；路径数是已发现的下限，转弯及干扰为部分搜索结果，分数仅作暂估。");
            if (level.obstacles != null && level.obstacles.Length > 0) notes.Add("此关卡含障碍：只分析基础棋盘，未计入障碍解锁过程。");
            if (level.target_words.Any(word => word.type != 0)) notes.Add("目标词含非 0 类型：按普通词分析，未解释特殊类型行为。");
            int covered = search.Covered.Count(value => value);
            if (complete && covered < search.Board.Length) notes.Add("所有目标词路径仅覆盖 " + covered + "/" + search.Board.Length + " 格，存在不属于目标词的格子。");
            var report = new DifficultyReport
            {
                LevelId = level.id, Width = level.width, Height = level.height, Words = words.ToArray(), Weights = normalized,
                ScoreAvailable = allFound, SearchComplete = complete, SearchNodes = search.TotalNodes, CoveredCells = covered,
                MissingFrequencies = missing, UnsolvableWords = words.Count(word => word.PathCount == 0 && word.SearchComplete),
                UnfinishedWords = words.Count(word => word.PathCount == 0 && !word.SearchComplete), Notes = notes.ToArray(),
                FrequencySource = frequencies == null ? "无词频数据" : frequencies.Source,
                FrequencyLicense = frequencies == null ? "无" : frequencies.License,
                FamiliarityScore = words.Average(word => word.FamiliarityScore), LengthScore = words.Average(word => word.LengthScore),
                TurnScore = words.Average(word => word.TurnScore), InterferenceScore = words.Average(word => word.InterferenceScore)
            };
            report.Score = Weighted(report.FamiliarityScore, report.LengthScore, report.TurnScore, report.InterferenceScore, normalized);
            report.Grade = report.UnsolvableWords > 0 ? "不可解（四方向规则）" : !allFound ? "搜索未完成，无法判定" :
                (complete ? "" : "暂估：") + (report.Score < 35 ? "简单" : report.Score < 65 ? "普通" : "困难");
            return report;
        }

        private static float Clamp(float value) { return Math.Max(0, Math.Min(1, value)); }
        private static float Weighted(float familiarity, float length, float turns, float interference, float[] weights)
        { return familiarity * weights[0] + length * weights[1] + turns * weights[2] + interference * weights[3]; }
    }
}

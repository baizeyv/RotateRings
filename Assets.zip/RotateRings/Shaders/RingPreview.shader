// 圆环预览材质：用固定方向光做塑料外观，支持颜色图及切线空间法线图。
// 这是自定义 Unlit 通道，不接收场景灯光、实时阴影或反射探针。
Shader "RotateRings/Rounded Plastic Preview"
{
    Properties
    {
        // 实例颜色由 ProceduralRing 的 MaterialPropertyBlock 覆盖，和颜色图相乘。
        _BaseColor ("Color", Color) = (0.2,0.6,1,1)
        // 高光指数；数值越大，高光越集中。
        _Gloss ("Gloss", Range(8,128)) = 48
        _BaseMap ("Albedo Atlas", 2D) = "white" {}
        // 法线图要按 Normal Map 导入；_NormalStrength 控制其切线空间扰动幅度。
        [Normal] _BumpMap ("Normal Atlas", 2D) = "bump" {}
        _NormalStrength ("Normal Strength", Range(0,2)) = 1
    }
    SubShader
    {
        // 仅用于 URP；作为不透明几何绘制，写深度并剔除背面。
        Tags { "RenderPipeline"="UniversalPipeline" "RenderType"="Opaque" "Queue"="Geometry" }
        Pass
        {
            // SRPDefaultUnlit 可供当前 URP Renderer 绘制；外观光照由 Frag 自行计算。
            Tags { "LightMode"="SRPDefaultUnlit" }
            ZWrite On
            Cull Back
            HLSLPROGRAM
            #pragma vertex Vert
            #pragma fragment Frag
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            #include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Packing.hlsl"
            // 声明两张纹理及采样器；材质参数放到 UnityPerMaterial 常量缓冲中。
            TEXTURE2D(_BaseMap); SAMPLER(sampler_BaseMap);
            TEXTURE2D(_BumpMap); SAMPLER(sampler_BumpMap);
            CBUFFER_START(UnityPerMaterial)
            float4 _BaseColor;
            float _Gloss;
            float _NormalStrength;
            CBUFFER_END
            // 顶点输入：对象空间位置、法线、切线及 UV。切线 w 保存切线空间手性。
            struct Attributes { float4 positionOS : POSITION; float3 normalOS : NORMAL; float4 tangentOS : TANGENT; float2 uv : TEXCOORD0; };
            // 顶点输出：裁剪空间坐标用于光栅化；其他世界空间数据会插值后交给像素着色器。
            struct Varyings { float4 positionCS : SV_POSITION; float3 positionWS : TEXCOORD0; float3 normalWS : TEXCOORD1; float4 tangentWS : TEXCOORD2; float2 uv : TEXCOORD3; };
            // 顶点阶段：只做坐标/方向变换，网格形状在 CPU 生成，此处不对顶点做形变。
            Varyings Vert(Attributes input)
            {
                Varyings output;
                // 1. 局部位置变为世界位置，再投影到裁剪空间，让 GPU 确定屏幕位置。
                output.positionWS = TransformObjectToWorld(input.positionOS.xyz);
                output.positionCS = TransformWorldToHClip(output.positionWS);
                // 2. 变换法线与切线；负缩放会翻转基底，因此切线 w 还要乘镜像缩放符号。
                output.normalWS = TransformObjectToWorldNormal(input.normalOS);
                output.tangentWS = float4(TransformObjectToWorldDir(input.tangentOS.xyz), input.tangentOS.w * GetOddNegativeScale());
                // 3. UV 原样传递，直接使用几何生成器已经计算的图集坐标。
                output.uv = input.uv;
                return output;
            }
            // 像素阶段：重建切线空间 → 采样纹理法线 → 计算固定光照 → 输出不透明颜色。
            half4 Frag(Varyings input) : SV_Target
            {
                // 1. 插值可能破坏正交关系，先归一化法线，再去掉切线在法线方向上的分量。
                float3 normal = normalize(input.normalWS);
                float3 tangent = input.tangentWS.xyz - normal * dot(normal, input.tangentWS.xyz);
                // 切线过小时构造备用方向，避免归一化零向量；选择不与法线平行的参考轴。
                if (dot(tangent, tangent) < 1e-8) tangent = cross(abs(normal.y) < 0.99 ? float3(0,1,0) : float3(1,0,0), normal);
                tangent = normalize(tangent);
                // 2. 用法线、切线和手性构造副切线，形成 T/B/N 三轴基底。
                float3 bitangent = cross(normal, tangent) * input.tangentWS.w;
                // 3. 解码 Unity 格式的法线图，再从切线空间转换到世界空间；强度 0 使用几何法线。
                float3 normalTS = UnpackNormalScale(SAMPLE_TEXTURE2D(_BumpMap, sampler_BumpMap, input.uv), _NormalStrength);
                normal = normalize(tangent * normalTS.x + bitangent * normalTS.y + normal * normalTS.z);
                // 4. 固定世界光方向及视线方向；diffuse 是漫反射，specular 是半角向量高光。
                float3 light = normalize(float3(-0.45,0.65,-1));
                float3 view = normalize(GetWorldSpaceViewDir(input.positionWS));
                float diffuse = saturate(dot(normal, light));
                float specular = pow(saturate(dot(normal, normalize(light + view))), _Gloss);
                // 5. 视线与法线越垂直，轮廓加亮越明显；颜色图与实例颜色相乘得到基础色。
                float rim = pow(1 - saturate(dot(normal, view)), 3);
                float3 albedo = SAMPLE_TEXTURE2D(_BaseMap, sampler_BaseMap, input.uv).rgb * _BaseColor.rgb;
                // 6. 合成固定基础亮度、漫反射、白色高光和弱轮廓光。返回 alpha=1，Color.a 不做透明度。
                float3 color = albedo * (0.32 + 0.68 * diffuse) + specular * 0.48 + rim * albedo * 0.12;
                return half4(color, 1);
            }
            ENDHLSL
        }
    }
}

using System.IO;
using RotateRings;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

[CustomEditor(typeof(Ring2DShapeAppearance))]
public sealed class Ring2DShapeAppearanceEditor : Editor
{
    public const string NormalPath = "Assets/RotateRings/Ring2D/Textures/ringextra_2d_n.png";
    public const string MaskPath = "Assets/RotateRings/Ring2D/Textures/ringextra_2d_sdf.png";
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector(); var appearance = (Ring2DShapeAppearance)target;
        if (GUILayout.Button("使用 ringextra 法线与 SDF")) { Undo.RecordObject(appearance, "指定阴影和法线"); AssignTextures(appearance); appearance.Refresh(); EditorUtility.SetDirty(appearance); }
        if (GUILayout.Button("保存阴影 Mesh（先保存本体 Mesh）"))
        {
            var source = appearance.GetComponent<MeshFilter>().sharedMesh;
            if (source == null || !EditorUtility.IsPersistent(source)) { Debug.LogWarning("请先保存本体 Mesh，再保存阴影资源。", appearance); return; }
            string path = EditorUtility.SaveFilePanelInProject("保存阴影 Mesh", appearance.name + "_Shadow", "asset", "保存可复用的柔边阴影 Mesh。", "Assets/Mesh");
            if (string.IsNullOrEmpty(path)) return;
            appearance.Refresh(true); var saved = Instantiate(appearance.ShadowMesh); saved.hideFlags = HideFlags.None;
            AssetDatabase.CreateAsset(saved, AssetDatabase.GenerateUniqueAssetPath(path)); AssetDatabase.SaveAssets();
            Undo.RecordObject(appearance, "绑定阴影资源"); appearance.UseSavedShadow(saved); EditorUtility.SetDirty(appearance);
            if (appearance.gameObject.scene.IsValid()) EditorSceneManager.MarkSceneDirty(appearance.gameObject.scene);
        }
        EditorGUILayout.HelpBox("阴影额外使用一次绘制，不参与碰撞。偏移为世界 XY 单位；柔边为本体局部单位。法线及 SDF 必须与 A/B 贴图布局一致，重新打图集时须同步打包。", MessageType.Info);
    }
    public static void AssignTextures(Ring2DShapeAppearance appearance)
    { appearance.NormalMap = AssetDatabase.LoadAssetAtPath<Texture2D>(NormalPath); appearance.ShadowMask = AssetDatabase.LoadAssetAtPath<Texture2D>(MaskPath); }

    [MenuItem("Tools/Rotate Rings/给当前场景 Shape 添加阴影与法线")]
    public static void AddToScene()
    {
        foreach (var ring in Object.FindObjectsByType<ProceduralRing2D>(FindObjectsSortMode.None))
        {
            var appearance = ring.GetComponent<Ring2DShapeAppearance>(); if (appearance == null) appearance = Undo.AddComponent<Ring2DShapeAppearance>(ring.gameObject);
            Undo.RecordObject(appearance, "设置阴影与法线"); AssignTextures(appearance); ring.Rebuild(); appearance.Refresh(); EditorUtility.SetDirty(appearance);
        }
        EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene());
    }
}

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using RotateRings;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering.Universal;

/// <summary>以参考图像素位置建立关卡，资源与原 Demo 分开保存。</summary>
public static class RingReferenceLevelEditor
{
    public const string ScenePath = "Assets/RotateRings/Scenes/RingReferenceLevel.unity";
    private const float Ppu = 55;
    private static readonly Color Green = new Color(0.16f, 0.86f, 0.38f), Blue = new Color(0.08f, 0.72f, 1), Red = new Color(1, 0.13f, 0.16f), Purple = new Color(0.69f, 0.17f, 1), Orange = new Color(1, 0.49f, 0.05f), Lime = new Color(0.43f, 0.93f, 0.22f), DeepBlue = new Color(0.22f, 0.37f, 1);
    private static Vector2 Point(float x, float y) { return new Vector2((x - 254.5f) / Ppu, (318.5f - y) / Ppu); }

    [MenuItem("Tools/Rotate Rings/打开参考图解环关卡")]
    public static void Open()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        if (File.Exists(ScenePath)) EditorSceneManager.OpenScene(ScenePath); else Build();
    }
    public static Ring2DLevelController Build()
    {
        Directory.CreateDirectory("Assets/RotateRings/Scenes"); Directory.CreateDirectory("Assets/RotateRings/ReferenceLevelMeshes"); AssetDatabase.Refresh();
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        var camera = new GameObject("Main Camera").AddComponent<Camera>(); camera.tag = "MainCamera"; camera.transform.position = new Vector3(0, 0, -20);
        camera.orthographic = true; camera.orthographicSize = 9.6f; camera.backgroundColor = new Color(1, 0.95f, 0.83f); camera.clearFlags = CameraClearFlags.SolidColor;
        camera.gameObject.AddComponent<AudioListener>(); camera.gameObject.AddComponent<UniversalAdditionalCameraData>();
        // 参考图不满 9:16，围绕中心整体等比缩放，保留图内相对位置。
        var stage = new GameObject("Reference Layout").transform; stage.localScale = Vector3.one * 1.14f;
        var shapes = new List<ProceduralRing2D>(); var guides = new List<Ring2DClasp>();
        Func<string, float, float, float, float, float, Color, ProceduralRing2D> arc = (name, x, y, r, start, sweep, color) =>
        {
            var s = Add(name, x, y, Ring2DShape.CShape, color, stage); s.Settings.Radius = r / Ppu; s.Settings.StartDegrees = start; s.Settings.SweepDegrees = sweep; shapes.Add(s); return s;
        };
        var greenTop = arc("01 Green top C", 136, 58, 48, 80, 250, Green);
        var blueLeft = arc("02 Blue left C", 77, 165, 49, 230, 260, Blue);
        var redUpper = arc("03 Red upper C", 139, 276, 48, 310, 252, Red);
        var purpleMiddle = arc("04 Purple middle C", 326, 165, 48, 52, 256, Purple);
        var purpleCup = arc("05 Purple upper cup", 428, 135, 48, 149, 246, Purple);
        var greenMiddle = arc("06 Green middle C", 297, 276, 48, 287, 271, Lime);
        var orangeRight = arc("07 Orange right C", 413, 260, 47, 43, 254, Orange);
        var redCircle = Add("08 Red closed circle", 379, 371, Ring2DShape.Circle, Red, stage); redCircle.Settings.Radius = 49 / Ppu; shapes.Add(redCircle);
        var greenLower = arc("09 Green lower C", 261, 405, 48, 196, 256, Lime);
        var blueLowerLeft = arc("10 Blue lower left C", 210, 511, 47, 314, 250, DeepBlue);
        var blueLowerRight = arc("11 Blue lower right C", 344, 489, 47, 331, 238, DeepBlue);
        // 局部 Seven 是顶部横边 + 右侧竖边；镜像/旋转覆盖图片中另一侧竖边或下横边。
        var cyanTop = Line("12 Cyan top 7", 246, 45, 160, 42, Ring2DShape.Seven, Blue, stage, shapes);
        var cyanL = Line("13 Cyan upper L", 316, 69, 160, 38, Ring2DShape.Seven, Blue, stage, shapes, 180);
        var purplePole = Line("14 Purple upper 7", 406.5f, 89.5f, 41, 131, Ring2DShape.Seven, Purple, stage, shapes);
        var orangeGate = Line("15 Orange gate", 201.5f, 156, 95, 64, Ring2DShape.Gate, Orange, stage, shapes);
        orangeGate.MovementAxis = Ring2DMovementAxis.Vertical;
        var bluePole = Line("16 Blue middle 7", 196, 276, 32, 132, Ring2DShape.Seven, DeepBlue, stage, shapes); bluePole.MovementAxis = Ring2DMovementAxis.Vertical;
        var cyanGate = Line("17 Cyan lower U", 86, 311, 96, 62, Ring2DShape.Gate, Blue, stage, shapes, 180);
        var orangePole = Line("18 Orange left 7", 82.5f, 390, 93, 30, Ring2DShape.Seven, Orange, stage, shapes);
        var redPole = Line("19 Red left 7", 53.5f, 469, 31, 122, Ring2DShape.Seven, Red, stage, shapes, 0, true);
        var blueSideGate = Line("20 Blue left lower L", 85.5f, 466.5f, 29, 123, Ring2DShape.Seven, DeepBlue, stage, shapes, 180, true);
        var pinkPole = Line("21 Red middle 7", 171, 404, 32, 130, Ring2DShape.Seven, Red, stage, shapes, 0, true);
        var greenGate = Line("22 Green bottom U", 279, 543, 130, 60, Ring2DShape.Gate, Green, stage, shapes, 180);
        var purpleBottom = Line("23 Purple bottom L", 296.5f, 570.5f, 177, 49, Ring2DShape.Seven, Purple, stage, shapes, 180, true);
        var greenRight = Line("24 Green right 7", 473, 447.5f, 32, 251, Ring2DShape.Seven, Green, stage, shapes, 0, true);
        var greenLeftBottom = Line("25 Green left bottom 7", 109.5f, 584, 147, 42, Ring2DShape.Seven, Lime, stage, shapes);
        var greenBottomBar = Line("26 Green bottom bar", 98, 598, 130, 20, Ring2DShape.Straight, Lime, stage, shapes);
        Head(blueLeft, 113, 99); Head(blueLeft, 154, 165);
        Head(redUpper, 102, 210); Head(redUpper, 212, 276);
        Head(purpleMiddle, 250, 165); Head(purpleMiddle, 326, 89); Head(purpleMiddle, 309, 230);
        Head(purpleCup, 420, 210); Head(orangeRight, 345, 276);
        Head(redCircle, 330, 319); Head(redCircle, 307, 392); Head(redCircle, 354, 442);
        Head(greenLower, 232, 466); Head(greenLower, 312, 454); Head(blueLowerRight, 415, 489);
        greenMiddle.Connections = new[] { new Ring2DConnection { Name = "无头短杆", AngleDegrees = 112, Direction = Ring2DConnectionDirection.Outward, ToCenter = false, ShowHead = false, Length = 0.45f, RodWidth = 7 / Ppu } };
        Guide(cyanTop, 238, 24, false, stage, guides);
        Guide(purplePole, 427, 91, true, stage, guides);
        Guide(cyanGate, 38, 298, true, stage, guides); Guide(cyanGate, 134, 298, true, stage, guides);
        Guide(orangePole, 81, 375, false, stage, guides);
        Guide(redPole, 38, 474, true, stage, guides); Guide(blueSideGate, 100, 460, true, stage, guides); Guide(pinkPole, 155, 412, true, stage, guides);
        Guide(greenGate, 214, 530, true, stage, guides); Guide(greenGate, 344, 530, true, stage, guides);
        Guide(purpleBottom, 267, 595, false, stage, guides); Guide(greenRight, 457, 459, true, stage, guides);
        Guide(greenLeftBottom, 114, 563, false, stage, guides); Guide(greenBottomBar, 91, 598, false, stage, guides);
        foreach (var s in shapes)
        {
            if (!s.Rebuild()) throw new InvalidOperationException("关卡形状生成失败：" + s.name);
            // 单独关卡资源目录，场景中的显示网格复用保存资源，不保存运行时临时 Mesh。
            ProceduralRing2DEditor.SaveMeshAsset(s, "Assets/RotateRings/ReferenceLevelMeshes/" + s.name.Replace(' ', '_') + ".asset");
        }
        var controller = new GameObject("Level - release independent shapes").AddComponent<Ring2DLevelController>(); controller.Shapes = shapes.ToArray(); controller.Guides = guides.ToArray();
        EditorSceneManager.SaveScene(scene, ScenePath); AssetDatabase.SaveAssets(); return controller;
    }
    private static ProceduralRing2D Add(string name, float x, float y, Ring2DShape shape, Color color, Transform stage)
    {
        var s = new GameObject(name).AddComponent<ProceduralRing2D>(); s.transform.SetParent(stage, false); s.transform.localPosition = Point(x, y);
        s.Settings.Shape = shape; s.Settings.Thickness = 13 / Ppu; s.ColliderSegments = 64; s.AllowStraightHeadPassage = true; s.Color = color;
        s.Connections = new Ring2DConnection[0]; Ring2DDemoEditor.AssignSprites(s); return s;
    }
    private static ProceduralRing2D Line(string name, float x, float y, float width, float height, Ring2DShape shape, Color color, Transform stage, List<ProceduralRing2D> shapes, float rotation = 0, bool mirror = false)
    {
        var s = Add(name, x, y, shape, color, stage); s.Settings.Width = width / Ppu; s.Settings.Height = height / Ppu;
        s.Settings.CornerRadius = 10 / Ppu; s.transform.localRotation = Quaternion.Euler(0, 0, rotation);
        if (mirror) s.transform.localScale = new Vector3(-1, 1, 1); shapes.Add(s); return s;
    }
    private static void Head(ProceduralRing2D owner, float x, float y)
    {
        var delta = Point(x, y) - (Vector2)owner.transform.localPosition; float angle = Mathf.Atan2(delta.y, delta.x) * Mathf.Rad2Deg;
        float depth = 24 / Ppu, rod = 7 / Ppu;
        var c = new Ring2DConnection { Name = "扣合连接头", AngleDegrees = angle, Direction = Ring2DConnectionDirection.Outward, ToCenter = false,
            Length = delta.magnitude - owner.Settings.Radius - owner.Settings.Thickness / 2 - depth / 2 + 0.02f, RodWidth = rod, HeadWidth = 20 / Ppu, HeadDepth = depth, PassageAngleDegrees = 65 };
        owner.Connections = owner.Connections.Concat(new[] { c }).ToArray();
    }
    private static void Guide(ProceduralRing2D owner, float x, float y, bool vertical, Transform stage, List<Ring2DClasp> guides)
    {
        var clasp = new GameObject(owner.name + " - fixed guide").AddComponent<Ring2DClasp>(); clasp.transform.SetParent(stage, false); clasp.transform.localPosition = Point(x, y);
        clasp.transform.localRotation = Quaternion.Euler(0, 0, vertical ? 0 : -90); clasp.ClaspSprite = Ring2DDemoEditor.GetClaspSprite(); clasp.RenderMaterial = owner.RenderMaterial;
        clasp.Width = 25 / Ppu; clasp.Length = 23 / Ppu; clasp.ChannelWidth = 16 / Ppu; clasp.Refresh(); guides.Add(clasp);
        owner.Clasps = owner.Clasps.Concat(new[] { clasp }).ToArray();
    }
}

Shader "RotateRings/Shape Shadow"
{
    Properties { _ShadowColor("Shadow Color", Color)=(0,0,0,0.3) _ShadowMask("Mask Alpha",2D)="white"{} _UseMask("Use Mask",Float)=0 }
    SubShader
    {
        Tags { "RenderPipeline"="UniversalPipeline" "Queue"="Transparent" "RenderType"="Transparent" }
        Pass
        {
            Tags { "LightMode"="SRPDefaultUnlit" }
            Cull Off ZWrite Off Blend SrcAlpha OneMinusSrcAlpha
            HLSLPROGRAM
            #pragma vertex Vert
            #pragma fragment Frag
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            TEXTURE2D(_ShadowMask); SAMPLER(sampler_ShadowMask);
            CBUFFER_START(UnityPerMaterial)
            float4 _ShadowColor; float _UseMask;
            CBUFFER_END
            struct A { float4 positionOS:POSITION; float2 uv:TEXCOORD0; float4 color:COLOR; };
            struct V { float4 positionCS:SV_POSITION; float2 uv:TEXCOORD0; float alpha:TEXCOORD1; };
            V Vert(A a){V o;o.positionCS=TransformObjectToHClip(a.positionOS.xyz);o.uv=a.uv;o.alpha=a.color.a;return o;}
            half4 Frag(V i):SV_Target { half mask=lerp(1,SAMPLE_TEXTURE2D(_ShadowMask,sampler_ShadowMask,i.uv).a,_UseMask);half alpha=smoothstep(0,1,i.alpha);return half4(_ShadowColor.rgb,_ShadowColor.a*alpha*mask); }
            ENDHLSL
        }
    }
}

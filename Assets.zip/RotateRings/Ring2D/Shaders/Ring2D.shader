Shader "RotateRings/Ring 2D"
{
    Properties
    {
        [PerRendererData] _MainTex ("Texture", 2D) = "white" {}
        _Color ("Tint", Color) = (1,1,1,1)
        [HideInInspector] _RendererColor ("Renderer Color", Color) = (1,1,1,1)
        [Normal] _NormalMap ("Normal Map", 2D) = "bump" {}
        _UseNormal ("Use Normal", Float) = 0
        _NormalStrength ("Normal Strength", Range(0,2)) = 0.55
        _LightDirection ("Light Direction", Vector) = (-0.35,0.6,-1,0)
        _Ambient ("Ambient", Float) = 0.72
        _Diffuse ("Diffuse", Float) = 0.4
    }
    SubShader
    {
        Tags { "RenderPipeline"="UniversalPipeline" "Queue"="Transparent" "RenderType"="Transparent" }
        Pass
        {
            Tags { "LightMode"="SRPDefaultUnlit" }
            Cull Off ZWrite Off Blend SrcAlpha OneMinusSrcAlpha
            HLSLPROGRAM
            #pragma vertex Vert
            #pragma fragment Frag
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            #include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Packing.hlsl"
            TEXTURE2D(_MainTex); SAMPLER(sampler_MainTex);
            TEXTURE2D(_NormalMap); SAMPLER(sampler_NormalMap);
            CBUFFER_START(UnityPerMaterial)
            float4 _Color;
            float4 _LightDirection;
            float _UseNormal, _NormalStrength, _Ambient, _Diffuse;
            CBUFFER_END
            float4 _RendererColor;
            struct A { float4 positionOS:POSITION; float2 uv:TEXCOORD0; float4 color:COLOR; };
            struct V { float4 positionCS:SV_POSITION; float2 uv:TEXCOORD0; float4 color:COLOR; float3 world:TEXCOORD1; };
            V Vert(A input) { V o; o.positionCS=TransformObjectToHClip(input.positionOS.xyz); o.world=TransformObjectToWorld(input.positionOS.xyz); o.uv=input.uv; o.color=input.color*_Color*_RendererColor; return o; }
            half4 Frag(V input):SV_Target
            {
                half4 color=SAMPLE_TEXTURE2D(_MainTex,sampler_MainTex,input.uv)*input.color;
                // 从 UV 与世界坐标导数求切线，旧的保存 Mesh 无须补建法线/切线或增加顶点。
                float3 dx=ddx(input.world),dy=ddy(input.world);float2 ux=ddx(input.uv),uy=ddy(input.uv);
                float det=ux.x*uy.y-ux.y*uy.x;
                if(_UseNormal>0.5 && abs(det)>1e-10)
                {
                    float3 t=normalize((dx*uy.y-dy*ux.y)/det);
                    float3 b=normalize((-dx*uy.x+dy*ux.x)/det);
                    float3 n=UnpackNormal(SAMPLE_TEXTURE2D(_NormalMap,sampler_NormalMap,input.uv));
                    n.xy*=_NormalStrength;n.z=sqrt(saturate(1-dot(n.xy,n.xy)));
                    float3 worldNormal=normalize(t*n.x+b*n.y+float3(0,0,-1)*n.z);
                    float3 light=normalize(_LightDirection.xyz+float3(0,0,-1e-6));
                    color.rgb*=max(0,_Ambient+_Diffuse*saturate(dot(worldNormal,light)));
                }
                return color;
            }
            ENDHLSL
        }
    }
}

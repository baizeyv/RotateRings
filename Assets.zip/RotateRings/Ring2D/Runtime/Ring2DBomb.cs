using System;
using UnityEngine;

namespace RotateRings
{
    /// <summary>所属 shape 的子对象；独立圆形几何轮廓，首次碰到其他 shape 时移除双方。</summary>
    [ExecuteAlways, RequireComponent(typeof(SpriteRenderer))]
    public sealed class Ring2DBomb : MonoBehaviour
    {
        public Sprite BombSprite;
        [Min(0.001f)] public float Radius = 0.2f;
        public Color Color = UnityEngine.Color.white;
        [SerializeField, HideInInspector] private bool spent;
        private ProceduralRing2D owner;
        private static Sprite defaultSprite;
        public ProceduralRing2D Owner { get { return owner; } }
        public float VisualScale { get; private set; } = 1;
        public bool Armed { get { return !spent && isActiveAndEnabled && owner != null && owner.isActiveAndEnabled && Radius > 0 && !float.IsNaN(Radius) && !float.IsInfinity(Radius); } }
        public event Action<ProceduralRing2D, ProceduralRing2D, Vector3> Exploded;
        private void OnEnable() { Refresh(); Notify(); }
        private void OnValidate() { Notify(); }
        private void OnDisable() { Notify(); }
        private void OnTransformParentChanged() { Notify(); Refresh(); Notify(); }
        private void Notify() { if(owner!=null)owner.NotifyCollisionChanged(); }
        private void LateUpdate()
        {
            Refresh();
            if(Application.isPlaying && Armed)owner.CheckBombContacts();
        }
        public void Refresh()
        {
            owner=GetComponentInParent<ProceduralRing2D>();
            var renderer=GetComponent<SpriteRenderer>();
            renderer.sprite=BombSprite!=null?BombSprite:DefaultSprite();renderer.color=Color;
            renderer.drawMode=SpriteDrawMode.Simple;
            float diameter=2*Mathf.Max(0.001f,Radius);
            renderer.transform.localScale=Vector3.one;
            // Sprite 尺寸由对象缩放设置；碰撞半径会同步使用该缩放。
            float scale=diameter/(renderer.sprite.rect.width/renderer.sprite.pixelsPerUnit);
            VisualScale=scale;
            renderer.transform.localScale=new Vector3(scale,scale,1);
            if(owner!=null){renderer.sortingOrder=5;renderer.sortingLayerName=owner.SortingLayer;if(owner.RenderMaterial!=null)renderer.sharedMaterial=owner.RenderMaterial;}
        }
        public bool Detonate(ProceduralRing2D other, Vector3 point)
        {
            if(!Armed || other==null || other==owner || !other.isActiveAndEnabled)return false;
            spent=true;var source=owner;
            source.gameObject.SetActive(false);other.gameObject.SetActive(false);
            Exploded?.Invoke(source,other,point);return true;
        }
        public void ResetBomb(){spent=false;Notify();}
        private static Sprite DefaultSprite()
        {
            if(defaultSprite!=null)return defaultSprite;
            var texture=new Texture2D(32,32,TextureFormat.RGBA32,false){name="默认炸弹",hideFlags=HideFlags.DontSave};
            var pixels=new Color[32*32];
            for(int y=0;y<32;y++)for(int x=0;x<32;x++)
            {float dx=x-15.5f,dy=y-13;pixels[y*32+x]=dx*dx+dy*dy<12*12?new Color(0.12f,0.12f,0.12f,1):UnityEngine.Color.clear;
                if(x>=15 && x<=17 && y>=24 && y<=28)pixels[y*32+x]=new Color(0.65f,0.35f,0.1f,1);
                if(x>=16 && x<=20 && y>=28 && y<=30)pixels[y*32+x]=new Color(1,0.45f,0.05f,1);}
            texture.SetPixels(pixels);texture.Apply();
            // 圆球直径占满 Sprite 横向范围，Pivot 放在球心，便于视觉半径与碰撞半径一致。
            defaultSprite=Sprite.Create(texture,new Rect(3.5f,1,24,31),new Vector2(0.5f,12f/31),32);
            defaultSprite.hideFlags=HideFlags.DontSave;return defaultSprite;
        }
    }
}

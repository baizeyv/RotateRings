using System;
using System.Collections.Generic;
using UnityEngine;

namespace RotateRings
{
    /// <summary>根据当前几何重新建立扣合关系：没有任何关系持续一小段时间的物件自动消失。</summary>
    public sealed class Ring2DLevelController : MonoBehaviour
    {
        public ProceduralRing2D[] Shapes = new ProceduralRing2D[0];
        public Ring2DClasp[] Guides = new Ring2DClasp[0];
        [Min(0)] public float ReleaseDelay = 0.2f;
        public int SolvedCount { get; private set; }
        public int ConstraintCount { get; private set; }
        public bool Completed { get { return Shapes.Length > 0 && SolvedCount == Shapes.Length; } }
        public event Action<ProceduralRing2D> ShapeSolved;
        public event Action LevelCompleted;
        private readonly Dictionary<ProceduralRing2D, float> independentSince = new Dictionary<ProceduralRing2D, float>();
        private readonly HashSet<ProceduralRing2D> solved = new HashSet<ProceduralRing2D>();
        private bool completionRaised;
        private readonly List<Body> bodies = new List<Body>();
        private readonly Dictionary<ProceduralRing2D, Body> bodyCache = new Dictionary<ProceduralRing2D, Body>();
        private Vector3[] initialPositions, initialScales;
        private Quaternion[] initialRotations;
        private float nextCheck, readyAt;
        private Font font;
        private sealed class Body
        {
            public ProceduralRing2D Shape;
            public readonly List<Ring2DCollisionShape> Segments = new List<Ring2DCollisionShape>();
            public readonly List<Ring2DCollisionShape> Heads = new List<Ring2DCollisionShape>();
            public readonly List<Vector2> Polygon = new List<Vector2>();
            public bool Linked;
            public Matrix4x4 Matrix;
            public string Configuration;
        }
        private void Start() { Initialize(); }
        public void Initialize()
        {
            initialPositions = new Vector3[Shapes.Length]; initialRotations = new Quaternion[Shapes.Length]; initialScales = new Vector3[Shapes.Length];
            for (int i = 0; i < Shapes.Length; i++)
            { initialPositions[i] = Shapes[i].transform.position; initialRotations[i] = Shapes[i].transform.rotation; initialScales[i] = Shapes[i].transform.localScale; }
            readyAt = Time.time + 0.6f; SolvedCount = 0; independentSince.Clear(); solved.Clear(); completionRaised = false;
        }
        private void LateUpdate()
        {
            if (!Application.isPlaying || Time.time < readyAt || Time.time < nextCheck) return;
            nextCheck = Time.time + 0.05f; CheckNow(Time.time);
        }

        /// <summary>只检测真实扣合/穿入，不把附近普通碰撞当作连接；全部判定完成后统一移除，避免顺序影响。</summary>
        public int CheckNow(float now)
        {
            int before = SolvedCount;
            bool changed;
            // 删除后立即重新建立关系；新独立的对象自动开始倒计时，无须再次拖动。
            do
            {
                changed = false;
                foreach (var shape in Shapes)
                    if (shape != null && !shape.gameObject.activeInHierarchy && !solved.Contains(shape)) { RegisterSolved(shape); changed = true; }
                bodies.Clear(); ConstraintCount = 0;
                foreach (var shape in Shapes) if (shape != null && shape.isActiveAndEnabled) bodies.Add(BuildBody(shape));
                for (int i = 0; i < bodies.Count; i++) for (int j = i + 1; j < bodies.Count; j++)
                {
                    if (HeadLinks(bodies[i], bodies[j]) || HeadLinks(bodies[j], bodies[i]) || Captures(bodies[i], bodies[j]) || Captures(bodies[j], bodies[i]))
                    { bodies[i].Linked = bodies[j].Linked = true; ConstraintCount++; }
                }
                // 空卡扣是否独立取决于实际穿过它的物件，而非旧的所属引用。
                foreach (var guide in Guides)
                {
                    if (guide == null || !guide.isActiveAndEnabled || !guide.Valid) continue;
                    bool occupied = false;
                    foreach (var body in bodies)
                        if (InGuide(body, guide)) { body.Linked = true; ConstraintCount++; occupied = true; }
                    if (!occupied) { guide.gameObject.SetActive(false); changed = true; }
                }
                var remove = new List<ProceduralRing2D>();
                foreach (var body in bodies)
                {
                    float since;
                    if (body.Linked) independentSince.Remove(body.Shape);
                    else
                    {
                        if (!independentSince.TryGetValue(body.Shape, out since)) { since = now; independentSince[body.Shape] = since; }
                        if (now - since >= ReleaseDelay) remove.Add(body.Shape);
                    }
                }
                foreach (var shape in remove)
                    shape.gameObject.SetActive(false);
                foreach (var shape in remove) RegisterSolved(shape);
                changed |= remove.Count > 0;
            } while (changed);
            if (Completed && !completionRaised) { completionRaised = true; LevelCompleted?.Invoke(); }
            return SolvedCount - before;
        }

        private void RegisterSolved(ProceduralRing2D shape)
        {
            if (!solved.Add(shape)) return;
            independentSince.Remove(shape); bodyCache.Remove(shape); SolvedCount = solved.Count; ShapeSolved?.Invoke(shape);
        }

        private Body BuildBody(ProceduralRing2D shape)
        {
            var matrix = shape.transform.localToWorldMatrix;
            string configuration = JsonUtility.ToJson(shape.Settings) + "|" + shape.ColliderSegments;
            foreach (var c in shape.Connections) configuration += JsonUtility.ToJson(c);
            Body result;
            if (bodyCache.TryGetValue(shape, out result) && result.Matrix == matrix && result.Configuration == configuration)
            { result.Linked = false; return result; }
            result = new Body { Shape = shape, Matrix = matrix, Configuration = configuration }; bodyCache[shape] = result;
            var path = Ring2DGeometry.ColliderPath(shape.Settings, Mathf.Max(48, shape.ColliderSegments));
            foreach (var p in path)
            { var world = shape.transform.TransformPoint(new Vector3((float)p.X, (float)p.Y, 0)); result.Polygon.Add(world); }
            double scale = shape.transform.TransformVector(Vector3.right).magnitude;
            for (int i = 1; i < result.Polygon.Count; i++)
            {
                var segment = new Ring2DCollisionShape(2) { Radius = shape.Settings.Thickness / 2 * scale };
                var a = result.Polygon[i - 1]; var b = result.Polygon[i]; segment.Points[0] = new Ring2DPoint(a.x, a.y); segment.Points[1] = new Ring2DPoint(b.x, b.y); segment.UpdateBounds(); result.Segments.Add(segment);
            }
            foreach (var c in shape.Connections)
            {
                if (!c.ShowHead) continue;
                var pose = Ring2DGeometry.ConnectionPose(shape.Settings, c);
                var head = new Ring2DCollisionShape(4);
                for (int i = 0; i < 4; i++)
                {
                    double x = (i == 0 || i == 3 ? -1 : 1) * c.HeadWidth / 2, y = (i < 2 ? -1 : 1) * c.HeadDepth / 2;
                    var p = shape.transform.TransformPoint(new Vector3((float)(pose.Head.X + pose.DY * x + pose.DX * y), (float)(pose.Head.Y - pose.DX * x + pose.DY * y), 0));
                    head.Points[i] = new Ring2DPoint(p.x, p.y);
                }
                head.UpdateBounds(); result.Heads.Add(head);
            }
            return result;
        }
        private static bool HeadLinks(Body a, Body b)
        {
            foreach (var head in a.Heads) foreach (var segment in b.Segments)
                if (Ring2DCollision.BoundsDistance(head, segment) < 0.01 && Ring2DCollision.Clearance(head, segment) <= 0.01) return true;
            return false;
        }
        /// <summary>C 环口由两端之间的虚拟线封闭，只用于判定内部的杆端/头，虚拟线不参与阻挡。</summary>
        private static bool Captures(Body cavity, Body other)
        {
            if (cavity.Shape.Settings.Shape != Ring2DShape.CShape && cavity.Shape.Settings.Shape != Ring2DShape.Circle) return false;
            foreach (var head in other.Heads)
            {
                var p = new Vector2((float)(head.Points[0].X + head.Points[2].X) / 2, (float)(head.Points[0].Y + head.Points[2].Y) / 2);
                if (Inside(cavity.Polygon, p, 0)) return true;
            }
            if (other.Shape.DragsByMovement)
            {
                float radius = (float)other.Segments[0].Radius;
                if (Inside(cavity.Polygon, other.Polygon[0], radius) || Inside(cavity.Polygon, other.Polygon[other.Polygon.Count - 1], radius)) return true;
            }
            return false;
        }
        private static bool Inside(List<Vector2> polygon, Vector2 p, float radius)
        {
            bool inside = false;
            for (int i = 0, j = polygon.Count - 1; i < polygon.Count; j = i++)
            {
                var a = polygon[i]; var b = polygon[j];
                if ((a.y > p.y) != (b.y > p.y) && p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x) inside = !inside;
                var d = b - a; float t = d.sqrMagnitude > 0 ? Mathf.Clamp01(Vector2.Dot(p - a, d) / d.sqrMagnitude) : 0;
                if ((p - a - d * t).sqrMagnitude <= radius * radius) return true;
            }
            return inside;
        }
        private static bool InGuide(Body body, Ring2DClasp guide)
        {
            var box = new Ring2DCollisionShape(4); var along = guide.Direction; var across = new Vector2(-along.y, along.x);
            float scale = guide.transform.TransformVector(Vector3.right).magnitude;
            for (int i = 0; i < 4; i++)
            { var p = (Vector2)guide.transform.position + across * (i == 0 || i == 3 ? -1 : 1) * guide.ChannelWidth * scale / 2 + along * (i < 2 ? -1 : 1) * guide.Length * scale / 2; box.Points[i] = new Ring2DPoint(p.x, p.y); }
            box.UpdateBounds(); foreach (var segment in body.Segments) if (Ring2DCollision.BoundsDistance(box, segment) <= 0 && Ring2DCollision.Clearance(box, segment) <= 0) return true;
            return false;
        }
        public void Restart()
        {
            if (initialPositions == null) Initialize();
            for (int i = 0; i < Shapes.Length; i++)
            { var s = Shapes[i]; s.gameObject.SetActive(false); s.transform.position = initialPositions[i]; s.transform.rotation = initialRotations[i]; s.transform.localScale = initialScales[i]; s.gameObject.SetActive(true); s.Rebuild(); }
            foreach (var guide in Guides) { guide.gameObject.SetActive(true); guide.Refresh(); }
            independentSince.Clear(); solved.Clear(); bodyCache.Clear(); completionRaised = false; SolvedCount = 0; readyAt = Time.time + 0.6f;
        }
        private void OnGUI()
        {
            if (font == null) font = Font.CreateDynamicFontFromOSFont(new[] { "Microsoft YaHei", "SimHei", "Arial" }, 20);
            float scale = Mathf.Min(Screen.width / 540f, Screen.height / 960f); var previous = GUI.matrix; GUI.matrix = Matrix4x4.Scale(Vector3.one * scale);
            var style = new GUIStyle(GUI.skin.label) { font = font, fontSize = 18, normal = { textColor = new Color(0.23f, 0.25f, 0.21f) } };
            GUI.Label(new Rect(14, 8, 440, 26), Completed ? "全部解开！" : "已解开 " + SolvedCount + " / " + Shapes.Length + "   ·   拖动环旋转 / 拖动杆滑动", style);
            if (GUI.Button(new Rect(430, 8, 96, 30), "重新开始", new GUIStyle(GUI.skin.button) { font = font, fontSize = 16 })) Restart();
            GUI.matrix = previous;
        }
        private void OnDestroy() { if (font != null) { if (Application.isPlaying) Destroy(font); else DestroyImmediate(font); } }
    }
}

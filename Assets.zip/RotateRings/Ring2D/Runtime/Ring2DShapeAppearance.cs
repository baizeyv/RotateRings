using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace RotateRings
{
    /// <summary>复用本体网格生成一层偏移柔边阴影，并为 A/B 贴图绑定法线光照；不参与碰撞。</summary>
    [ExecuteAlways, DisallowMultipleComponent, RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]
    public sealed class Ring2DShapeAppearance : MonoBehaviour
    {
        [InspectorName("显示阴影")] public bool ShowShadow = true;
        [InspectorName("阴影颜色")] public Color ShadowColor = new Color(0.16f, 0.12f, 0.07f, 0.28f);
        [InspectorName("阴影世界偏移")] public Vector2 ShadowOffset = new Vector2(0.035f, -0.055f);
        [Min(0), InspectorName("阴影柔边（局部单位）")] public float Softness = 0.045f;
        [InspectorName("阴影 SDF（使用 Alpha）")] public Texture2D ShadowMask;
        [InspectorName("启用法线")] public bool UseNormal = true;
        [InspectorName("法线贴图")] public Texture2D NormalMap;
        [Range(0, 2), InspectorName("法线强度")] public float NormalStrength = 0.55f;
        [InspectorName("光照方向（朝向光源）")] public Vector3 LightDirection = new Vector3(-0.35f, 0.6f, -1);
        [Range(0, 1.5f), InspectorName("环境亮度")] public float Ambient = 0.72f;
        [Range(0, 1.5f), InspectorName("方向光亮度")] public float Diffuse = 0.4f;
        private GameObject shadowObject;
        [SerializeField, HideInInspector] private Mesh savedShadow, savedSource;
        [SerializeField, HideInInspector] private float savedSoftness;
        [SerializeField, HideInInspector] private int savedShadowVersion;
        private const int ShadowGeometryVersion = 2;
        private Mesh generated, previousSource;
        private Material shadowMaterial;
        private float previousSoftness = -1;
        private int previousRevision = -1;
        private MaterialPropertyBlock bodyBlock, shadowBlock;
        public Mesh ShadowMesh { get { return shadowObject == null ? null : shadowObject.GetComponent<MeshFilter>().sharedMesh; } }
        private void LateUpdate() { Refresh(); }

        /// <summary>只有源 Mesh 或柔边变化才重建；移动/旋转仅更新阴影位置和渲染参数。</summary>
        public void Refresh(bool geometryChanged = false)
        {
            if (bodyBlock == null) bodyBlock = new MaterialPropertyBlock();
            if (shadowBlock == null) shadowBlock = new MaterialPropertyBlock();
            var source = GetComponent<MeshFilter>().sharedMesh;
            var bodyRenderer = GetComponent<MeshRenderer>();
            bodyRenderer.GetPropertyBlock(bodyBlock);
            bodyBlock.SetFloat("_UseNormal", UseNormal && NormalMap != null ? 1 : 0);
            if (NormalMap != null) bodyBlock.SetTexture("_NormalMap", NormalMap);
            bodyBlock.SetFloat("_NormalStrength", NormalStrength); bodyBlock.SetVector("_LightDirection", LightDirection);
            bodyBlock.SetFloat("_Ambient", Ambient); bodyBlock.SetFloat("_Diffuse", Diffuse); bodyRenderer.SetPropertyBlock(bodyBlock);
            if (!ShowShadow || source == null) { if (shadowObject != null) shadowObject.SetActive(false); return; }
            if (shadowObject == null)
            {
                var existing = transform.Find("Shape shadow");
                if (existing != null && existing.GetComponent<MeshFilter>() != null && existing.GetComponent<MeshRenderer>() != null) shadowObject = existing.gameObject;
                else { shadowObject = new GameObject("Shape shadow", typeof(MeshFilter), typeof(MeshRenderer)); shadowObject.transform.SetParent(transform, false); }
                shadowObject.hideFlags = HideFlags.DontSave;
            }
            shadowObject.SetActive(true); shadowObject.layer = gameObject.layer;
            shadowObject.transform.position = transform.position + new Vector3(ShadowOffset.x, ShadowOffset.y, 0);
            shadowObject.transform.localRotation = Quaternion.identity; shadowObject.transform.localScale = Vector3.one;
            var ring = GetComponent<ProceduralRing2D>(); int revision = ring != null ? ring.MeshRevision : 0;
            if (geometryChanged || previousSource != source || previousSoftness != Softness || previousRevision != revision || shadowObject.GetComponent<MeshFilter>().sharedMesh == null)
            {
                if (savedShadow != null && savedSource == source && savedSoftness == Softness && savedShadowVersion == ShadowGeometryVersion)
                    shadowObject.GetComponent<MeshFilter>().sharedMesh = savedShadow;
                else
                {
                    if (generated == null) generated = new Mesh { name = name + " Shadow", hideFlags = HideFlags.DontSave };
                    BuildShadow(source, generated, Mathf.Max(0, Softness)); shadowObject.GetComponent<MeshFilter>().sharedMesh = generated;
                }
                previousSource = source; previousSoftness = Softness; previousRevision = revision;
            }
            if (shadowMaterial == null) shadowMaterial = new Material(Shader.Find("RotateRings/Shape Shadow")) { hideFlags = HideFlags.DontSave };
            var renderer = shadowObject.GetComponent<MeshRenderer>(); renderer.sharedMaterial = shadowMaterial;
            renderer.sortingLayerID = bodyRenderer.sortingLayerID; renderer.sortingOrder = bodyRenderer.sortingOrder - 1;
            renderer.shadowCastingMode = ShadowCastingMode.Off; renderer.receiveShadows = false;
            Color tint = ShadowColor; if (ring != null) tint.a *= ring.Color.a;
            shadowBlock.SetColor("_ShadowColor", tint); shadowBlock.SetFloat("_UseMask", ShadowMask != null ? 1 : 0);
            if (ShadowMask != null) shadowBlock.SetTexture("_ShadowMask", ShadowMask); renderer.SetPropertyBlock(shadowBlock);
        }
        public void UseSavedShadow(Mesh mesh)
        { savedShadow = mesh; savedSource = GetComponent<MeshFilter>().sharedMesh; savedSoftness = Softness; savedShadowVersion = ShadowGeometryVersion; Refresh(true); }
        public void ConfigureMaterial(Material material)
        {
            material.SetFloat("_UseNormal", UseNormal && NormalMap != null ? 1 : 0);
            if (NormalMap != null) material.SetTexture("_NormalMap", NormalMap);
            material.SetFloat("_NormalStrength", NormalStrength); material.SetVector("_LightDirection", LightDirection);
            material.SetFloat("_Ambient", Ambient); material.SetFloat("_Diffuse", Diffuse);
        }

        private struct Edge { public int A, B, Count; }
        /// <summary>按位置合并边拓扑，UV 接缝不产生假边；原网格外加一圈 Alpha 从 1 降至 0 的共享顶点柔边。</summary>
        public static void BuildShadow(Mesh source, Mesh output, float softness)
        {
            var positions = new List<Vector3>(source.vertices); var uv = new List<Vector2>(source.uv);
            var colors = new List<Color32>(); foreach (var p in positions) colors.Add(new Color32(255, 255, 255, 255));
            var indices = new List<int>(source.triangles);
            var ids = new Dictionary<Vector3, List<int>>(); var welded = new List<Vector3>(); var canonical = new int[positions.Count];
            for (int i = 0; i < canonical.Length; i++)
            {
                var p = positions[i]; var key = new Vector3(Mathf.Round(p.x * 100000), Mathf.Round(p.y * 100000), Mathf.Round(p.z * 100000)); int id = -1;
                // 相邻量化格也要检查，避免极小的浮点差把圆头接缝误判成外边界。
                for (int x = -1; x <= 1 && id < 0; x++) for (int y = -1; y <= 1 && id < 0; y++)
                {
                    List<int> bucket;
                    if (ids.TryGetValue(key + new Vector3(x, y, 0), out bucket)) foreach (int candidate in bucket)
                        if ((welded[candidate] - p).sqrMagnitude <= 1e-10f) { id = candidate; break; }
                }
                if (id < 0)
                {
                    id = welded.Count; welded.Add(p); List<int> bucket;
                    if (!ids.TryGetValue(key, out bucket)) { bucket = new List<int>(); ids.Add(key, bucket); } bucket.Add(id);
                }
                canonical[i] = id;
            }
            var edges = new Dictionary<long, Edge>(); var normals = new Dictionary<int, Vector2>();
            for (int i = 0; i < indices.Count; i += 3) for (int j = 0; j < 3; j++)
            {
                int a = indices[i + j], b = indices[i + (j + 1) % 3], ca = canonical[a], cb = canonical[b];
                long key = ((long)Mathf.Min(ca, cb) << 32) | (uint)Mathf.Max(ca, cb); Edge e;
                if (edges.TryGetValue(key, out e)) e.Count++; else e = new Edge { A = a, B = b, Count = 1 }; edges[key] = e;
            }
            // 圆头扇形在直径上有中心顶点，环身只有一条完整直径边。
            // 把这些 T 形接缝拆成同样的短边再计数，否则内部接缝会被扩成阴影尖刺。
            var splitEdges = new Dictionary<long, Edge>();
            var representatives = new int[welded.Count];
            for (int i = 0; i < canonical.Length; i++) representatives[canonical[i]] = i;
            foreach (var e in edges.Values)
            {
                var cuts = new List<KeyValuePair<float, int>> { new KeyValuePair<float, int>(0, e.A), new KeyValuePair<float, int>(1, e.B) };
                var start = positions[e.A]; var delta = positions[e.B] - start;
                if (e.Count == 1 && delta.sqrMagnitude > 1e-10f)
                    for (int id = 0; id < welded.Count; id++)
                    {
                        float t = Vector3.Dot(welded[id] - start, delta) / delta.sqrMagnitude;
                        if (t > 0.00001f && t < 0.99999f && (welded[id] - start - delta * t).sqrMagnitude <= 1e-10f)
                            cuts.Add(new KeyValuePair<float, int>(t, representatives[id]));
                    }
                cuts.Sort((a, b) => a.Key.CompareTo(b.Key));
                for (int i = 1; i < cuts.Count; i++)
                {
                    int a = cuts[i - 1].Value, b = cuts[i].Value, ca = canonical[a], cb = canonical[b];
                    if (ca == cb) continue;
                    long key = ((long)Mathf.Min(ca, cb) << 32) | (uint)Mathf.Max(ca, cb); Edge part;
                    if (splitEdges.TryGetValue(key, out part)) part.Count += e.Count;
                    else part = new Edge { A = a, B = b, Count = e.Count };
                    splitEdges[key] = part;
                }
            }
            edges = splitEdges;
            foreach (var e in edges.Values) if (e.Count == 1)
            {
                var d = (Vector2)(positions[e.B] - positions[e.A]); var n = new Vector2(-d.y, d.x).normalized;
                foreach (int id in new[] { canonical[e.A], canonical[e.B] }) { Vector2 current; normals.TryGetValue(id, out current); normals[id] = current + n; }
            }
            var outer = new Dictionary<int, int>();
            foreach (var e in edges.Values) if (e.Count == 1 && softness > 0)
            {
                var d = (Vector2)(positions[e.B] - positions[e.A]); var edgeNormal = new Vector2(-d.y, d.x).normalized;
                foreach (int i in new[] { e.A, e.B }) if (!outer.ContainsKey(i))
                {
                    var n = normals[canonical[i]].normalized; float miter = Mathf.Min(2, 1 / Mathf.Max(0.5f, Vector2.Dot(n, edgeNormal)));
                    outer[i] = positions.Count; positions.Add(positions[i] + (Vector3)(n * softness * miter)); uv.Add(uv[i]); colors.Add(new Color32(255, 255, 255, 0));
                }
                indices.Add(e.A); indices.Add(outer[e.A]); indices.Add(e.B); indices.Add(e.B); indices.Add(outer[e.A]); indices.Add(outer[e.B]);
            }
            output.Clear(); output.SetVertices(positions); output.SetUVs(0, uv); output.SetColors(colors); output.SetTriangles(indices, 0); output.RecalculateBounds();
        }
        private void OnDisable()
        {
            if (shadowObject != null) shadowObject.SetActive(false);
            if (bodyBlock == null) bodyBlock = new MaterialPropertyBlock();
            var renderer = GetComponent<MeshRenderer>(); renderer.GetPropertyBlock(bodyBlock); bodyBlock.SetFloat("_UseNormal", 0); renderer.SetPropertyBlock(bodyBlock);
        }
        private void OnDestroy()
        {
            Release(shadowObject); Release(generated); Release(shadowMaterial);
        }
        private static void Release(Object value) { if (value == null) return; if (Application.isPlaying) Destroy(value); else DestroyImmediate(value); }
    }
}

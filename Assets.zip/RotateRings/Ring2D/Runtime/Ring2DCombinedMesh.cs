using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Sprites;

namespace RotateRings
{
    /// <summary>单材质合并 A 本体与 B 九宫格；精确复用同位置/UV 顶点，保留贴图接缝。</summary>
    public static class Ring2DCombinedMesh
    {
        private struct Key : IEquatable<Key>
        {
            public Vector3 Position; public Vector2 UV;
            public bool Equals(Key other){return Position.Equals(other.Position)&&UV.Equals(other.UV);}
            public override bool Equals(object obj){return obj is Key && Equals((Key)obj);}
            public override int GetHashCode(){return Position.GetHashCode()*397 ^ UV.GetHashCode();}
        }
        private sealed class Builder
        {
            public readonly List<Vector3> Vertices=new List<Vector3>();
            public readonly List<Vector2> UV=new List<Vector2>();
            public readonly List<int> Indices=new List<int>();
            private readonly Dictionary<Key,int> shared=new Dictionary<Key,int>();
            public int Vertex(Vector3 position,Vector2 uv)
            {
                var key=new Key{Position=position,UV=uv};int index;
                if(shared.TryGetValue(key,out index))return index;
                index=Vertices.Count;shared.Add(key,index);Vertices.Add(position);UV.Add(uv);return index;
            }
            public void Triangle(int a,int b,int c)
            {
                if(a==b||b==c||a==c)return;
                var area=Vector3.Cross(Vertices[b]-Vertices[a],Vertices[c]-Vertices[a]).z;
                if(Mathf.Abs(area)<1e-20f)return;
                Indices.Add(a);Indices.Add(area<0?b:c);Indices.Add(area<0?c:b);
            }
        }

        /// <summary>用户分段是上限；误差为局部单位，按外侧圆弧的弦高计算更少的三角形。</summary>
        private static Ring2DSettings Reduced(Ring2DSettings original,float error)
        {
            var s=JsonUtility.FromJson<Ring2DSettings>(JsonUtility.ToJson(original));
            if(error<=0)return s;
            double radius=(s.Shape==Ring2DShape.Circle||s.Shape==Ring2DShape.CShape?s.Radius:s.CornerRadius)+s.Thickness/2;
            double sweep=s.Shape==Ring2DShape.CShape?s.SweepDegrees*Math.PI/180:2*Math.PI;
            s.Segments=Math.Min(s.Segments,Math.Max(8,Count(radius,sweep,error)));
            s.CapSegments=Math.Min(s.CapSegments,Math.Max(4,Count(s.Thickness/2,Math.PI,error)));
            return s;
        }
        private static int Count(double radius,double sweep,double error)
        {double angle=2*Math.Acos(Math.Max(-1,Math.Min(1,1-error/radius)));return angle<1e-9?int.MaxValue:(int)Math.Ceiling(sweep/angle);}

        public static void Build(Mesh mesh,Ring2DSettings settings,Sprite body,Sprite connector,Ring2DConnection[] connections,float error)
        {
            if(float.IsNaN(error)||float.IsInfinity(error)||error<0)throw new ArgumentException("网格轮廓误差须为非负有限数。");
            if(connections.Length>0 && body.texture!=connector.texture)throw new ArgumentException("单次绘制要求 A/B 使用同一张贴图或同一图集，请将两张 Sprite 打进同一图集。");
            if(body.packed && body.packingRotation!=SpritePackingRotation.None || connector!=null && connector.packed && connector.packingRotation!=SpritePackingRotation.None)
                throw new ArgumentException("合并网格的 SpriteAtlas 请关闭旋转打包。");
            var builder=new Builder();
            // 原来的排序是杆 → 头 → 本体；合并后保留该覆盖顺序。
            for(int part=0;part<2;part++)foreach(var c in connections)
            {
                var pose=Ring2DGeometry.ConnectionPose(settings,c);float angle=Mathf.Atan2((float)pose.DY,(float)pose.DX);
                if(part==0 && pose.Length>0.00001)Slice(builder,connector,new Vector2((float)(pose.Start.X+pose.End.X)/2,(float)(pose.Start.Y+pose.End.Y)/2),angle,new Vector2((float)pose.Length,c.RodWidth));
                if(part==1 && c.ShowHead)Slice(builder,connector,new Vector2((float)pose.Head.X,(float)pose.Head.Y),angle-Mathf.PI/2,new Vector2(c.HeadWidth,c.HeadDepth));
            }
            double cap=body.border.x>0?body.border.x/body.rect.width:body.rect.height/2/body.rect.width;
            var data=Ring2DGeometry.Build(Reduced(settings,error),cap);var bounds=DataUtility.GetOuterUV(body);var map=new int[data.Vertices.Length];
            for(int i=0;i<map.Length;i++)
            {var v=data.Vertices[i];map[i]=builder.Vertex(new Vector3(v.X,v.Y,0),new Vector2(Mathf.Lerp(bounds.x,bounds.z,v.U),Mathf.Lerp(bounds.y,bounds.w,v.V)));}
            for(int i=0;i<data.Triangles.Length;i+=3)builder.Triangle(map[data.Triangles[i]],map[data.Triangles[i+1]],map[data.Triangles[i+2]]);
            mesh.Clear();mesh.SetVertices(builder.Vertices);mesh.SetUVs(0,builder.UV);
            var colors=new Color32[builder.Vertices.Count];for(int i=0;i<colors.Length;i++)colors[i]=UnityEngine.Color.white;
            mesh.colors32=colors;mesh.SetTriangles(builder.Indices,0);mesh.RecalculateBounds();
        }

        /// <summary>B 的 3×3 九宫格共用 4×4 顶点；缩放边框的方式与原连接件一致。</summary>
        private static void Slice(Builder builder,Sprite sprite,Vector2 center,float angle,Vector2 size)
        {
            Vector4 border=sprite.border;
            if(border==Vector4.zero){float b=Mathf.Min(sprite.rect.width,sprite.rect.height)*0.12f;border=new Vector4(b,b,b,b);}
            float scale=size.y/sprite.rect.height,left=border.x*scale,right=border.z*scale,bottom=border.y*scale,top=border.w*scale;
            if(left+right>size.x){float factor=size.x/(left+right);left*=factor;right*=factor;}
            if(bottom+top>size.y){float factor=size.y/(bottom+top);bottom*=factor;top*=factor;}
            var uv=DataUtility.GetOuterUV(sprite);
            float[] xs={-size.x/2,-size.x/2+left,size.x/2-right,size.x/2};
            float[] ys={-size.y/2,-size.y/2+bottom,size.y/2-top,size.y/2};
            float[] us={uv.x,Mathf.Lerp(uv.x,uv.z,border.x/sprite.rect.width),Mathf.Lerp(uv.x,uv.z,1-border.z/sprite.rect.width),uv.z};
            float[] vs={uv.y,Mathf.Lerp(uv.y,uv.w,border.y/sprite.rect.height),Mathf.Lerp(uv.y,uv.w,1-border.w/sprite.rect.height),uv.w};
            var indices=new int[16];float cos=Mathf.Cos(angle),sin=Mathf.Sin(angle);
            for(int y=0;y<4;y++)for(int x=0;x<4;x++)indices[y*4+x]=builder.Vertex(new Vector3(center.x+xs[x]*cos-ys[y]*sin,center.y+xs[x]*sin+ys[y]*cos,0),new Vector2(us[x],vs[y]));
            for(int y=0;y<3;y++)for(int x=0;x<3;x++){int i=y*4+x;builder.Triangle(indices[i],indices[i+1],indices[i+4]);builder.Triangle(indices[i+1],indices[i+5],indices[i+4]);}
        }
    }
}

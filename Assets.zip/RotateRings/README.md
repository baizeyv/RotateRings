# 程序化 3D 圆环

最新的 **二维 A/B 圆环 + 真实 Physics2D 阻挡** 已独立放到 [`Ring2D`](Ring2D/README.md)，父级管理连接点、连接杆与头，支持圆环、直线、C 环和门字环。此前 UI / 3D 原型在原目录保留。

打开 `Assets/RotateRings/Scenes/ProceduralRingsDemo.unity`，或使用菜单 **Tools → Rotate Rings → 打开圆环示例场景**。

示例从左到右、从上到下展示：圆管闭环、扁平圆角闭环、70° 缺口 C 环、大缺口 C 环、半圆环、椭圆环、圆角矩形环和圆头直条。Play 模式按住环身拖动可绕自身中心旋转。

这是 Rotate Rings 风格的几何与旋转展示场景。此造型展示场景只演示自由旋转；带解锁规则的玩法请打开下面的七环试玩关卡。

## ring.png 的 UI 版本

打开 **Tools → Rotate Rings → 打开 UI 圆环示例**，或打开 `Scenes/RingUIDemo.unity`。示例包含细直条、粗直条、闭圆环及两种缺口大小的 C 环；Play 后可拖动旋转。通过 **GameObject → UI → 程序化 Ring Image** 在 Canvas 下新建对象。

`RingImage` 继承 Unity UI 的 `Image`，在 `OnPopulateMesh(VertexHelper)` 中生成二维网格，使用原始 `Textures/ring.png`，PNG 字节未改动。颜色使用 Image 的 Color，材质使用默认 UI 材质，支持 UI 透明度、裁剪与遮罩。无须 MeshRenderer、MeshCollider 或法线贴图。这里仅实现无连接头造型，尚未将 UI 圆环接入七环解锁玩法。

| 参数 | 作用 |
| --- | --- |
| Shape | Straight 直条、Circle 闭圆环、CShape 开口环。 |
| Thickness | 环身宽度，单位为 Canvas 局部单位。 |
| UseRectSize | 默认启用：用 RectTransform 宽高计算圆半径或直条长度。关闭后使用 Radius / Length。 |
| Radius / Length | 圆的中心线路径半径 / 直条的中心线长度，圆头额外伸出 Thickness 的一半。 |
| StartDegrees / SweepDegrees | C 环起始角和覆盖角，0°向右，90°向上；覆盖 270° 对应 90°缺口。Circle 始终闭合。 |
| Segments / CapSegments | 圆弧与圆头的分段数量。 |
| AllowDrag / HitPadding | 是否允许鼠标或触摸拖动；点击范围额外增加的容差。 |

Inspector 的“按 Radius / Length / Thickness 设置 RectTransform”可用参数自动调整包围矩形，并关闭 UseRectSize。创建时 Pivot 默认为中心，拖动绕该 Pivot 旋转。运行时直接修改 Settings 后请调用 `SetVerticesDirty()`；正常旋转只修改 RectTransform，不重新生成网格。

贴图中间区域沿路径展开，左右端头以半圆网格映射；闭环仅使用中段，避免接缝处出现端头。默认 UV 排除 ring.png 顶部和底部的透明余量，对应 448×85 原图中的纵向 10–75 像素区间。UVLeft / UVRight / UVBottom / UVTop / UVCapFraction 可调整其他同布局贴图。Sprite 使用 Full Rect 导入，默认无压缩、无 mipmap、Clamp；此版不支持 Sprite 图集的旋转打包。

点击过滤通过环形距离、角度和圆头距离计算，内孔与 C 环缺口可以穿透到其他 UI。使用默认 `GraphicRaycaster`、`EventSystem` 和拖动事件即可，无需读取贴图像素或开启 Read/Write。

### 有花纹的 ring2.png

打开 **Tools → Rotate Rings → 打开纹理 UI 圆环示例**，场景为 `Scenes/RingUITextureDemo.unity`。上排对比拉伸一次与镜像重复的直条，下排展示闭圆环和两种缺口的 C 环。新建 Ring Image 默认使用 ring2；已有组件可点击 Inspector 的 **应用 ring2 贴图 / UV / 镜像重复** 一次配置。

原始 ring2.png 为 449×128，其主要不透明环身位于纵向 31–95 像素；预设使用 `UVBottom=32/128`、`UVTop=97/128` 和 `UVCapFraction=32.5/449`，排除上下透明余量。导入保留 PNG 原始字节。

| 参数 | 效果 |
| --- | --- |
| BodyTextureMode = Stretch | 中段只展开一次，保持之前的默认行为。 |
| BodyTextureMode = Repeat | 中段正向重复；左右花纹需能衔接，否则会看见纹理接缝。 |
| BodyTextureMode = MirrorRepeat | 相邻中段交替镜像，拼接处使用相同 UV；适合当前 ring2 的花纹。 |
| BodyTileLength | 每次重复的目标长度，单位为 Canvas 局部单位。数值越小，重复次数越多。 |

圆头始终独立使用原图左右区域，不参与重复。网格会在重复边界拆分顶点，UV 始终限制在中段区域，不依赖整张贴图的 Repeat 模式。为保持整次数衔接，实际纹理长度会在目标值附近调整；Inspector 会显示最终次数和每段长度。镜像闭环使用偶数次，开放形状使用奇数次，以分别保持闭合处和左右圆头的 UV 衔接，最多 64 次（开放镜像最多 63 次）。这会使花纹方向交替翻转；希望保持单一方向时使用 Repeat 并提供可无缝衔接的中段。

**按原图比例设置中段纹理长度** 根据 Sprite 及 UV 区域计算中段长宽比，用当前 Thickness 得到目标长度。调整 Thickness 后可再次使用该按钮。纹理模式、长度和 UV 在运行时改变后仍需调用 `SetVerticesDirty()`。

## 七环试玩关卡

打开 **Tools → Rotate Rings → 打开试玩关卡**，然后点击 Unity 的 **Play**，在 Game 窗口体验。保存的场景为 `Scenes/RingPuzzleDemo.unity`。布局参考提供的截图：上部橙环接蓝环，中央紫环分叉到左侧红环和右下黄绿环，黄绿环再连接右侧绿环与底部蓝环。三个橡果使用简单的程序化立体造型。

- 按住环身，围绕环中心拖动；支持鼠标和单指触摸。
- 连接块沿相邻圆环的圆形轨道滑动，移动越过轨道范围时阻挡旋转。开口对准连接块并留出宽度后，连接解除。
- 所有连接都解除的圆环自动缩小移除，收集其中心的橡果；七环清空后显示通关。
- “提示”标出可先处理的外围环；“重玩”恢复全部圆环、碰撞体和收集进度。

可从红环、绿环、底部蓝环开始，随后解开黄绿环、紫环、上部蓝环；最后的橙环会随最后一条连接解除自动移除。无需在 Inspector 手动调整角度。

`RingPuzzleRules.cs` 使用独立的圆轨道几何规则计算旋转、开口和连接状态；`RingPuzzleGame.cs` 负责拾取、输入、动画与界面。关卡对象保存 Layout、Connections 与各 ProceduralRing 引用，规则数据与模型尺寸/位置需要保持一致。`Source` 是连接块所属环，`Target` 是被该连接块扣住的环；`Angle` 为连接块在所属环上的局部角度，`PegRadius` 为连接块约束点到所属环中心的距离，`ClearanceDegrees` 为通过开口需要预留的角度。

首版规则支持同一平面中的圆形 C 环，并以几何轨道约束代替刚体关节；它实现可玩的拆环流程，不是竞品内部物理代码的还原。椭圆、非圆形锁扣、跨层穿插和重新扣合尚未接入玩法规则。造型示例仍可独立使用。

使用 **Tools → Rotate Rings → 重建七环试玩关卡** 可重新生成默认布局；它会重建该 Demo 场景，保存自定义关卡时请另存为新场景。

## 调整形状

3D 生成链已补充中文方法注释和内部步骤说明。建议先读 `Runtime/ProceduralRing.cs` 的 `Rebuild`，再沿调用进入 `Runtime/RingGeometry.cs` 的 `Build` 与 `Runtime/RingConnectorGeometry.cs` 的 `Append`。前者负责 Unity 网格、碰撞体及材质，后两者负责纯几何；`RingSettings`、`RingVertex` 和路径基底 `Frame` 的字段也有说明。`Assets/Editor/ProceduralRingEditor.cs` 注释了 Inspector、Undo、材质预设及 Mesh 另存流程；`Shaders/RingPreview.shader` 注释了坐标变换、切线空间法线和固定光照；`Runtime/RingDemoLabels.cs` 注释了示例标签的位置换算。

选择对象，在 `ProceduralRing` 中修改 Settings，编辑器会重新生成。也可点击“重新生成 Mesh”。通过 **GameObject → 3D Object → 程序化圆环** 新建对象。

| 参数 | 作用 |
| --- | --- |
| Shape | Circle 闭圆环、Arc 开口弧、Ellipse 椭圆环、RoundedRectangle 圆角矩形环、Straight 直条。 |
| Radius | 圆形路径的中心线半径，外半径约为 Radius + TubeRadius。 |
| Width / Height | 椭圆、圆角矩形的中心线宽高；直条长度使用 Width。 |
| CornerRadius | 圆角矩形中心线路径的圆角半径。 |
| TubeRadius | 环身在 XY 平面的半宽。 |
| DepthRatio | Z 厚度相对环身半宽的比例；0.4–0.6 适合较扁的竞品风格。 |
| ProfilePower | 2 为圆/椭圆截面，4–6 为更平坦的圆角截面，8 更接近圆角方形。 |
| StartDegrees / ArcDegrees | 起始角和开口弧覆盖角；例如 290° 覆盖角意味着 70° 缺口。 |
| RoundedEnds | 开口弧和直条使用圆头；关闭后为平面封口。 |
| PathSegments / ProfileSegments / CapSegments | 路径、截面和端盖分段，越高越平滑、顶点越多。 |

路径位于对象局部 XY 平面，厚度沿 Z；可以用 Transform 旋转到任意平面。尺寸非法时会报错而不是静默夹取。很窄的 C 形缺口需要避免圆头彼此重叠。

Mesh 由截面沿路径扫掠生成，包括解析法线、UV、切线、三角形和圆头/平端盖。闭环路径及截面 UV 接缝采用重复顶点；图集映射在同一区域内复用原顶点索引，仅在前后图集区域边界保留拆分。即使两个图集区域重叠，也保留各自的切线方向，避免法线贴图镜像错误。默认圆头 C 环（96 路径段、24 截面段、8 圆头段）仍为 5,328 个三角形，图集顶点数由 15,984 降到 2,942；闭圆环由 13,824 降到 2,522。生成的临时 Mesh 由组件持有并在禁用时释放。已保存的 Mesh 资源需要重新生成并另存，才能采用新的共享索引。MeshCollider 为非凸网格，保持实际孔洞；不要直接用于动态非运动学 Rigidbody，物理锁扣玩法需要单独设计碰撞体。

演示材质 `RingPlastic.mat` 使用 `RingPreview.shader` 内置的固定方向光和高光，兼容当前 URP 2D 渲染器。它不接收场景灯光或阴影。若改用 URP Lit 材质，需要能渲染该材质的 3D Renderer。

## RingFinal 贴图和法线

示例材质已绑定用户提供的 `Textures/RingFinal.png` 和 `Textures/RingFinal_N.png`，文件复制时保持原始 PNG 字节。前者按普通 sRGB 颜色贴图导入，后者按 Normal Map、线性数据导入，均使用 Clamp 和 Bilinear。灰度颜色图与组件的 Color 相乘得到彩色环身。

使用这种图集时启用 Settings 的 `UseRingFinalAtlas`，也可点击 Inspector 的“启用 RingFinal 图集 UV”。示例中的八个对象已经启用。默认将朝局部 -Z 的半侧映射到上部长条区域，另一半映射到下部；环身使用中段，圆头逐渐映射到左右端部。分开上下 UV 区域，避免三角形跨图集采样。圆角矩形、椭圆、闭圆及开口弧均支持。

`AtlasMinU / AtlasMaxU` 控制环身横向取样范围，`AtlasCapWidth` 控制左右圆头区域宽度，`AtlasFrontV / AtlasBackV` 控制两片区域的纵向中心，`AtlasFrontHalfHeight / AtlasBackHalfHeight` 控制其半高。默认值针对提供的两张图片设置，可按其他同类图集调整。此映射由本工具重新设计，不是对原模型 UV 的逐顶点复制。

组件的 `BaseMap`、`NormalMap` 可覆盖共享材质的贴图；留空时使用材质中已有贴图。`NormalStrength=0` 可关闭法线效果，`1` 使用默认强度。Shader 根据 Mesh 的切线、法线和镜像缩放符号将切线空间法线转换到世界空间；可继续旋转模型。普通平铺贴图可以关闭图集 UV，使用常规 U 沿路径、V 沿截面的映射。

若换用自己的图片，请把法线贴图的 Texture Type 设置为 Normal Map，不要按普通颜色贴图导入。法线图和颜色图必须使用相同图集布局。

## 外伸连接块与 ringextra 图集

使用 **Tools → Rotate Rings → 打开连接块示例场景** 打开 `Scenes/RingConnectorsDemo.unity`。八个实例展示单块、多块、不同角度、长直条外伸及直条两端连接块。

选择圆环，在 Inspector 设置“外伸连接块数量”（0–16），展开每个连接块独立调整：

| 参数 | 作用 |
| --- | --- |
| AngleDegrees | 局部 XY 平面的连接位置与外伸角度：0° 向右、90° 向上、180° 向左、270° 向下。开口环不能连接在缺口内。 |
| StemLength / StemWidth / StemDepth | 外伸直条的长度、宽度和厚度；长度为 0 时连接块直接贴近环身。 |
| BlockWidth / BlockLength / BlockDepth | 末端连接块的切向宽度、外伸方向长度和厚度。中间连接直条的图集方向旋转 90°，末端连接块保持原方向。 |
| Bevel | 连接块边缘的圆角尺寸。 |
| Style | FlatTab 使用图集中间的矩形区域，Clasp 使用右侧锁扣区域；这里只改变贴图区域，不包含锁扣行为。 |

点击“应用 ringextra 贴图与图集 UV”可同时设置环身 UV 和 `RingExtra.mat`，该材质已绑定 `ringextra.png` 与 Normal Map 类型的 `ringextra_n.png`。环身使用左侧长条区域，连接直条和块使用独立区域。数量大于 0 时 Inspector 自动应用该配置。连接块与环身合并为一个 Mesh，拾取碰撞体随之更新。

`Tools/Build-RingConnectorDemo.py` 可重建连接块示例场景及材质。

## 检查

`powershell -NoProfile -ExecutionPolicy Bypass -File Tools/Test-RingGeometry.ps1` 检查各种路径、截面和端盖的顶点、法线、UV、索引、朝向与闭合性，并编译运行时及编辑器脚本。

同一命令还运行七环玩法检查，验证轨道阻挡、开口通过、完整解法、大角度输入和重新创建关卡。`Tools/Prepare-RingPuzzleCheck.py` 配合独立测试项目中的 `RingPuzzleSceneCheck.Run` 检查实际 Unity 渲染、Play Mode 拾取、完整解锁、移除动画和重玩。

UI 版本同样由该命令检查网格、UV、圆头、内孔和缺口。`Tools/Prepare-RingUICheck.py` 配合独立测试项目中的 `RingUISceneCheck.Run` 检查实际 UI 渲染、GraphicRaycaster 点击过滤、EventSystem 拖动和参数更新；`Tools/Copy-RingUIDemo.py` 将验证后的场景保存回项目。

`Tools/Build-RingDemo.py` 可重建场景和演示材质。实际 Unity 导入与渲染校验使用 `Tools/Prepare-RingSceneCheck.py` 生成的独立 Temp 测试项目，不修改现有项目渲染配置。

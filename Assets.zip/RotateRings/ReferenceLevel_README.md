# 参考图解环关卡

打开 `Assets/RotateRings/Scenes/RingReferenceLevel.unity`，或使用 **Tools → Rotate Rings → 打开参考图解环关卡**，点击 Play。建议将 Game View 设置为竖屏 1080×1920。按图片摆放 26 个形状及 14 个灰色固定卡扣，忽略松果。左上显示解开数量，右上“重新开始”恢复整关。

圆环 / C 环拖动旋转；直杆、门形、7 形拖动滑动。固定卡扣决定滑动轴，没有固定卡扣的移动形状使用自身 MovementAxis。顶部相邻的两个蓝色折杆按图片拆成独立物件。少数连接头位置、侧门宽度调整了几像素，给实体阻挡留出间隙。

## 独立与消失

`Ring2DLevelController` 每 0.05 秒根据当前几何检查关系，不使用固定的解锁顺序：

- B 连接头仍扣住另一个物件的本体时，两者保持关联。
- 另一个物件的连接头或移动杆的末端仍在 C 环 / 完整圆环内部时，保持关联。C 环两端之间的虚拟口线只用于内部判定，不产生阻挡。
- 物件仍穿过关卡中固定卡扣的通道时，保持约束；卡扣是否独立按实际穿过它的物件判断。
- 不把附近普通碰撞接触当作扣合。没有上述关系连续 0.2 秒后，物件整体 `SetActive(false)`，表示解开；关联的空固定卡扣随后消失。

所有物件解开触发 `LevelCompleted`，单个物件解开触发 `ShapeSolved(shape)`，每个物件及通关事件只触发一次。恢复关联会取消尚未完成的消失倒计时。轮廓缓存在物件位置和参数未变时复用。

一个物件消失后立即重算剩余关系：空卡扣自动消失，新独立的物件自动开始消失倒计时，无须玩家再次拖动。即使其他游戏逻辑直接停用 shape，也会同步计数并触发后续检查。卡扣不会因为旧的所属引用还指向活跃物件而留在场景，也不会在其他物件仍实际穿过它时被误删。ReleaseDelay 为 0 时同次检查完成连锁消失；重新开始恢复物件、卡扣和事件计数。

本关移动杆启用 `AllowStraightHeadPassage`：与 B 头横轴匹配的直线路径段可滑过连接头。灰色 C 卡扣继续使用实体轨道阻挡，不允许折杆圆角穿过。形状之间仍使用现有几何扫掠阻挡，不启用真实 Physics2D。用户修正后的场景摆放不通过生成器覆盖。

场景直接复用 `Assets/RotateRings/ReferenceLevelMeshes` 内的合并 Mesh；这些资源同时带配套材质，旧 Demo 和 PM 场景不变。关卡生成器代码位于 `Ring2D/Editor/RingReferenceLevelEditor.cs`，运行时控制器在 `Ring2D/Runtime/Ring2DLevelController.cs`。

## 验证

`Tools/Prepare-RingClaspCheck.py` 和 `Tools/Prepare-CascadeReleaseCheck.py` 准备隔离项目，Unity 执行 `CascadeReleaseCheck.Run` 验证连锁消失、外部停用物件、空卡扣、实际占用、事件去重及重新开始。测试只打开用户修正后的场景，不重新生成或保存主项目场景。

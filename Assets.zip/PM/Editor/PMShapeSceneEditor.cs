using System;
using System.IO;
using System.Linq;
using System.Reflection;
using RotateRings;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering.Universal;
using WordTile.PM;

/// <summary>建立独立 PM 场景并选中横屏 Game View，不修改原 Ring2DDemo。</summary>
public static class PMShapeSceneEditor
{
    public const string ScenePath = "Assets/PM/Scenes/PMShapeWorkbench.unity";

    [MenuItem("Tools/PM/打开 Shape 配置工作台")]
    public static void Open()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        if (File.Exists(ScenePath)) EditorSceneManager.OpenScene(ScenePath);
        else Build();
        LandscapeGameView();
        Selection.activeObject = UnityEngine.Object.FindFirstObjectByType<PMShapeWorkbench>();
    }

    public static PMShapeWorkbench Build()
    {
        Directory.CreateDirectory("Assets/PM/Scenes"); AssetDatabase.Refresh();
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        var main = new GameObject("Main Camera").AddComponent<Camera>(); main.tag = "MainCamera";
        main.transform.position = new Vector3(0, 0, -20); main.clearFlags = CameraClearFlags.SolidColor;
        main.backgroundColor = new Color(0.055f, 0.075f, 0.11f); main.cullingMask = 0; main.depth = 1;
        main.gameObject.AddComponent<UniversalAdditionalCameraData>();
        var preview = new GameObject("1080x1920 Preview Camera").AddComponent<Camera>();
        preview.transform.position = new Vector3(0, 0, -20); preview.orthographic = true; preview.orthographicSize = 9.6f;
        preview.aspect = 1080f / 1920; preview.cullingMask = 1 << PMShapeWorkbench.PreviewLayer; preview.depth = 0;
        preview.clearFlags = CameraClearFlags.SolidColor; preview.backgroundColor = new Color(0.94f, 0.95f, 0.92f); preview.enabled = false;
        preview.gameObject.AddComponent<UniversalAdditionalCameraData>();
        var target = new GameObject("Shape Preview", typeof(MeshFilter), typeof(MeshRenderer)); target.layer = PMShapeWorkbench.PreviewLayer;
        var tool = new GameObject("PM Shape Workbench").AddComponent<PMShapeWorkbench>();
        tool.PreviewCamera = preview; tool.PreviewShape = target.GetComponent<MeshFilter>();
        // 复用项目内 A/B 切片和材质，无须另造一套贴图或生成算法。
        var sprites = AssetDatabase.LoadAllAssetsAtPath("Assets/RotateRings/Ring2D/Textures/ringextra_2d.png").OfType<Sprite>().ToArray();
        tool.BodySprite = sprites.First(s => s.name == "RingBody_A"); tool.ConnectionSprite = sprites.First(s => s.name == "RingConnector_B");
        tool.RenderMaterial = AssetDatabase.LoadAssetAtPath<Material>("Assets/RotateRings/Ring2D/Materials/Ring2D.mat");
        EditorSceneManager.SaveScene(scene, ScenePath); AssetDatabase.SaveAssets(); return tool;
    }

    /// <summary>使用编辑器自身的固定分辨率列表；失败时工作台仍按横屏比例缩放。</summary>
    private static void LandscapeGameView()
    {
        try
        {
            var assembly = typeof(Editor).Assembly;
            var sizesType = assembly.GetType("UnityEditor.GameViewSizes");
            var singleton = typeof(ScriptableSingleton<>).MakeGenericType(sizesType);
            var sizes = singleton.GetProperty("instance").GetValue(null);
            var groupEnum = assembly.GetType("UnityEditor.GameViewSizeGroupType");
            var group = sizesType.GetMethod("GetGroup").Invoke(sizes, new[] { Enum.Parse(groupEnum, "Standalone") });
            var type = group.GetType(); int count = (int)type.GetMethod("GetTotalCount").Invoke(group, null), index = -1;
            var get = type.GetMethod("GetGameViewSize");
            for (int i = 0; i < count; i++)
            {
                var size = get.Invoke(group, new object[] { i }); var st = size.GetType();
                if ((int)st.GetProperty("width").GetValue(size) == 1920 && (int)st.GetProperty("height").GetValue(size) == 1080) { index = i; break; }
            }
            if (index < 0)
            {
                var sizeType = assembly.GetType("UnityEditor.GameViewSize"); var mode = assembly.GetType("UnityEditor.GameViewSizeType");
                var size = Activator.CreateInstance(sizeType, new object[] { Enum.Parse(mode, "FixedResolution"), 1920, 1080, "PM Workbench 1920x1080" });
                type.GetMethod("AddCustomSize").Invoke(group, new[] { size }); index = count;
            }
            var viewType = assembly.GetType("UnityEditor.GameView"); var view = EditorWindow.GetWindow(viewType);
            viewType.GetProperty("selectedSizeIndex", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).SetValue(view, index);
            view.Show();
        }
        catch (Exception e) { Debug.LogWarning("PM 工作台：请在 Game View 手动选择横屏 1920×1080。" + e.Message); }
    }
}

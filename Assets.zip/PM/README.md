# PM Shape 配置工作台

打开 `Assets/PM/Scenes/PMShapeWorkbench.unity` 并点击 Play，或者使用 **Tools → PM → 打开 Shape 配置工作台**。菜单会将 Game View 设为横屏 1920×1080；工作台随窗口等比缩放，建议最大化 Game View。整个工具为横屏，中央的蓝色边框代表 **1080×1920 竖屏画面**，左右两侧为可滚动的中文配置面板。

- 左侧：圆环、直线、C 环、门形、7 形、Z 形，形状尺寸、圆角、颜色/透明度、位置/旋转、曲线及端头分段、精简误差。
- 右侧：添加/删除/选择最多 16 个连接点，调整位置、向内/向外、延伸至中心、杆长/宽度、头宽/厚度、显示连接头和通道参数；查看实际顶点/三角形及外接像素尺寸，保存、导入配置。
- 默认自动应用。输入非法数值时保留上次有效画面并显示原因，禁止保存无效配置；可关闭自动应用后点击“应用当前参数”。切换形状保留尺寸和连接配置；不适合新形状的参数会提示修改。
- 拖动中央预览移动造型，Shift + 拖动旋转；“居中并归零旋转”恢复摆放。网格间隔 100 px，超出竖屏边界时提示裁切。此场景用于创建造型，不运行游戏碰撞逻辑。

尺寸统一在界面输入像素，**100 px = 1 Unity 单位**，尺寸沿中心线测量；整体外轮廓还包含厚度与连接件。原点是竖屏中心，X 向右、Y 向上。1080×1920 对应世界空间宽 10.8、高 19.2；之后在同样相机尺度中使用即可。Mesh 本身保持局部坐标，位置和角度单独保存到 JSON。

## 保存与复用

在 Unity Play 模式点击 **保存 Unity Mesh + 材质 + 配置**，将资源写入 `Assets/PM/Exports/<名称_时间>/`：共享顶点的 `.asset`、绑定 A/B 贴图和颜色的 `.mat`、格式化 `.json`。每次创建新目录，退出 Play 后资源仍在。将 Mesh/材质赋给 MeshFilter/MeshRenderer 即可显示；这些资源不包含游戏行为、连接件脚本或碰撞缓存。旧场景不会被修改。

“导出 OBJ + 贴图 + 配置”在编辑器中允许选择目录，输出 OBJ、MTL、atlas.png 和 JSON。构建后的桌面程序也支持该导出，写入 `Application.persistentDataPath/PMExports`，界面显示实际位置。OBJ 使用 Unity 的标准坐标转换（镜像 X 并反转三角形顺序），单位仍为 100 px/单位。

“从文件导入 JSON 配置”在编辑器中读取之前保存的 JSON；也可以粘贴 JSON 到右侧文本框后点击“导入下方 JSON”。导入失败不会覆盖当前配置。使用项目自带 A/B 贴图和材质；如要替换素材，在场景的 PMShapeWorkbench Inspector 指定 BodySprite、ConnectionSprite、RenderMaterial，A/B 必须共用同一贴图或图集，图集禁止旋转打包。当前 UI 中文字体使用系统 Microsoft YaHei / SimHei；目标机器无中文字体时可在 Inspector 指定项目中的字体资源。

此目录仅引用 Ring2D 的现有生成算法和素材，不修改它们。运行时脚本在 Runtime，场景创建菜单在 Editor，场景在 Scenes。

## 验证

`python Tools/Prepare-PMCheck.py` 创建隔离项目 `Temp/PMCheck`；使用 Unity `-batchmode -screen-width 1920 -screen-height 1080 -projectPath <Temp/PMCheck绝对路径> -executeMethod PMWorkbenchCheck.Run -logFile <日志路径>` 运行原生验证。覆盖六种形状、连接件增删及朝向、Z 独立宽度、像素换算、非法输入、JSON 往返、Unity 及 OBJ 资源导出、运行时编辑和 Play 模式保存。

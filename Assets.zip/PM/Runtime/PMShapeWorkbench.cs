using System;
using System.Globalization;
using System.IO;
using System.Text;
using RotateRings;
using UnityEngine;

namespace WordTile.PM
{
    /// <summary>以 100 像素对应一个 Unity 单位，记录可重新编辑的完整造型；Mesh 保持局部坐标。</summary>
    [Serializable]
    public sealed class PMShapeConfig
    {
        public int Version = 1, PreviewWidth = 1080, PreviewHeight = 1920;
        public float PixelsPerUnit = 100;
        public string Name = "PMShape";
        public Ring2DSettings Settings = new Ring2DSettings { Radius = 3, Width = 6, Height = 6, CornerRadius = 0.8f, Thickness = 0.4f, TopWidth = 3, BottomWidth = 3 };
        public Ring2DConnection[] Connections = new Ring2DConnection[0];
        public Color Color = new Color(0.22f, 0.7f, 0.94f, 1);
        public Vector2 PositionPixels;
        public float RotationDegrees, MeshOutlineError = 0.003f;
    }

    /// <summary>产品经理运行时工作台：左右配置、中间固定竖屏预览，不启用游戏碰撞或拖动脚本。</summary>
    public sealed class PMShapeWorkbench : MonoBehaviour
    {
        public PMShapeConfig Config = new PMShapeConfig();
        public Sprite BodySprite, ConnectionSprite;
        public Material RenderMaterial;
        public Camera PreviewCamera;
        public MeshFilter PreviewShape;
        public Font ChineseFont;
        public bool ShowHeadChannelPreview = true;
        public const int PreviewLayer = 31;
        public RenderTexture PreviewTexture { get; private set; }
        public string Status { get; private set; } = "拖动预览移动；按住 Shift 拖动旋转。";
        public Mesh CurrentMesh { get { return PreviewShape == null ? null : PreviewShape.sharedMesh; } }
        public bool HasValidPreview { get; private set; }
        private Mesh ownedMesh;
        private Material ownedMaterial;
        private Font ownedFont;
        private GUIStyle title, section, label, button, field, note, toggle;
        private Vector2 leftScroll, rightScroll;
        private bool showGrid = true, autoApply = true, dragging;
        private string appliedJson, jsonText = "", invalidInput;
        private int selectedConnection;
        private struct HeadChannelPreview
        {
            public Vector2 Center, Along, Across;
            public float Length, Width, Depth;
            public int ConnectionIndex;
            public string Label;
        }
        private readonly System.Collections.Generic.List<HeadChannelPreview> previewChannels = new System.Collections.Generic.List<HeadChannelPreview>(16);
        private bool? pendingExport;
        private readonly System.Collections.Generic.Dictionary<string, string> edits = new System.Collections.Generic.Dictionary<string, string>();
        private static readonly string[] ShapeNames = { "圆环", "直线", "C 环", "门形", "7 形", "Z 形" };
        private static readonly CultureInfo Culture = CultureInfo.InvariantCulture;

        private void Start()
        {
            if (!Application.isEditor && (Application.platform == RuntimePlatform.WindowsPlayer || Application.platform == RuntimePlatform.OSXPlayer || Application.platform == RuntimePlatform.LinuxPlayer))
                Screen.SetResolution(1920, 1080, FullScreenMode.Windowed);
            Initialize();
        }

        public void Initialize()
        {
            if (PreviewCamera == null || PreviewShape == null) { Status = "场景缺少预览相机或 MeshFilter。"; return; }
            if (PreviewTexture == null)
            {
                PreviewTexture = new RenderTexture(1080, 1920, 24, RenderTextureFormat.ARGB32) { name = "PM 1080x1920 Preview", antiAliasing = 1 };
                PreviewTexture.Create();
            }
            PreviewCamera.targetTexture = PreviewTexture;
            PreviewCamera.orthographic = true; PreviewCamera.orthographicSize = 9.6f; PreviewCamera.aspect = 1080f / 1920;
            PreviewCamera.cullingMask = 1 << PreviewLayer; PreviewCamera.enabled = true;
            PreviewShape.gameObject.layer = PreviewLayer;
            if (ownedMaterial == null)
            {
                ownedMaterial = RenderMaterial != null ? new Material(RenderMaterial) : new Material(Shader.Find("RotateRings/Ring 2D"));
                ownedMaterial.name = "PM Preview Material";
            }
            PreviewShape.GetComponent<MeshRenderer>().sharedMaterial = ownedMaterial;
            Apply();
        }

        /// <summary>先验证全部输入，再更新显示；非法输入保留上一帧画面，但禁止导出旧结果。</summary>
        public bool Apply()
        {
            HasValidPreview = false;
            try
            {
                ValidateConfig(Config);
                if (BodySprite == null || (Config.Connections.Length > 0 && ConnectionSprite == null)) throw new ArgumentException("缺少 A / B Sprite。");
                if (PreviewShape == null || ownedMaterial == null) throw new ArgumentException("请先初始化预览。");
                if (ownedMesh == null) ownedMesh = new Mesh { name = "PM Shape Preview" };
                Ring2DCombinedMesh.Build(ownedMesh, Config.Settings, BodySprite, ConnectionSprite, Config.Connections, Config.MeshOutlineError);
                PreviewShape.sharedMesh = ownedMesh;
                PreviewShape.transform.localPosition = new Vector3(Config.PositionPixels.x / 100, Config.PositionPixels.y / 100, 0);
                PreviewShape.transform.localRotation = Quaternion.Euler(0, 0, Config.RotationDegrees);
                PreviewShape.transform.localScale = Vector3.one;
                var block = new MaterialPropertyBlock(); block.SetTexture("_MainTex", BodySprite.texture);
                block.SetColor("_Color", Config.Color); block.SetColor("_RendererColor", UnityEngine.Color.white);
                PreviewShape.GetComponent<MeshRenderer>().SetPropertyBlock(block);
                CacheHeadChannels();
                appliedJson = JsonUtility.ToJson(Config); HasValidPreview = true;
                Status = "已更新预览。"; return true;
            }
            catch (Exception e) { Status = "参数未应用：" + e.Message; return false; }
        }

        private void CacheHeadChannels()
        {
            previewChannels.Clear();
            for (int i = 0; i < Config.Connections.Length; i++)
            {
                var c = Config.Connections[i];
                if (!c.ShowHead || !c.AllowRingBodyPassage) continue;
                var pose = Ring2DGeometry.ConnectionPose(Config.Settings, c);
                previewChannels.Add(new HeadChannelPreview
                {
                    Center = new Vector2((float)pose.Head.X, (float)pose.Head.Y), Along = new Vector2((float)pose.DY, (float)-pose.DX),
                    Across = new Vector2((float)pose.DX, (float)pose.DY), Length = c.HeadWidth, Width = c.ResolvedHeadChannelWidth, Depth = c.HeadDepth,
                    ConnectionIndex = i, Label = "净通道 " + (c.ResolvedHeadChannelWidth * Config.PixelsPerUnit).ToString("0.##", Culture) + " px"
                });
            }
        }

        public static void ValidateConfig(PMShapeConfig config)
        {
            if (config == null || config.Settings == null || config.Connections == null) throw new ArgumentException("配置内容不完整。");
            if (config.Version != 1 || config.PreviewWidth != 1080 || config.PreviewHeight != 1920 || config.PixelsPerUnit != 100)
                throw new ArgumentException("仅支持版本 1、1080×1920、100 像素/单位的配置。");
            config.Settings.Validate();
            if (config.Connections.Length > 16) throw new ArgumentException("最多 16 个连接点。");
            foreach (var c in config.Connections)
            {
                if (c == null) throw new ArgumentException("连接点为空。");
                c.Validate(); Ring2DGeometry.ConnectionPose(config.Settings, c);
            }
            foreach (float value in new[] { config.MeshOutlineError, config.PositionPixels.x, config.PositionPixels.y, config.RotationDegrees, config.Color.r, config.Color.g, config.Color.b, config.Color.a })
                if (float.IsNaN(value) || float.IsInfinity(value)) throw new ArgumentException("请输入有限数值。");
            if (config.MeshOutlineError < 0) throw new ArgumentException("网格误差不能为负数。");
            if (config.Color.r < 0 || config.Color.r > 1 || config.Color.g < 0 || config.Color.g > 1 || config.Color.b < 0 || config.Color.b > 1 || config.Color.a < 0 || config.Color.a > 1)
                throw new ArgumentException("颜色各通道须在 0–1 之间。");
        }

        public bool ImportJson(string json)
        {
            try
            {
                var imported = JsonUtility.FromJson<PMShapeConfig>(json); ValidateConfig(imported);
                // 同步检查当前 A/B 图是否适用于配置；导入失败不会替换工作中的配置。
                var probe = new Mesh();
                try { Ring2DCombinedMesh.Build(probe, imported.Settings, BodySprite, ConnectionSprite, imported.Connections, imported.MeshOutlineError); }
                finally { Release(probe); }
                Config = imported; edits.Clear(); selectedConnection = 0; return Apply();
            }
            catch (Exception e) { Status = "导入失败：" + e.Message; return false; }
        }

        private void RequireCurrent()
        {
            if (invalidInput != null) throw new ArgumentException(invalidInput);
            if (!Apply()) throw new InvalidOperationException(Status);
        }

        /// <summary>Play 模式可保存真正的 Unity Mesh / 材质；构建后的程序导出 OBJ / MTL / JSON。</summary>
        public string Export(string parentDirectory, bool unityAssets)
        {
            RequireCurrent();
#if UNITY_EDITOR
            if (unityAssets && !Path.GetFullPath(parentDirectory).StartsWith(Path.GetFullPath(Application.dataPath) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException("Unity 资源必须保存在 Assets 下。");
#else
            if (unityAssets) throw new InvalidOperationException("Unity .asset 只能在编辑器中保存。");
#endif
            string safeName = Config.Name;
            foreach (char c in Path.GetInvalidFileNameChars()) safeName = safeName.Replace(c, '_');
            if (string.IsNullOrWhiteSpace(safeName)) safeName = "PMShape";
            string folder = Path.Combine(parentDirectory, safeName + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff", Culture));
            for (int i = 1; Directory.Exists(folder); i++) folder = Path.Combine(parentDirectory, safeName + "_" + i);
#if UNITY_EDITOR
            if (unityAssets)
            {
                string assetDirectory = "Assets/" + Path.GetFullPath(folder).Substring((Path.GetFullPath(Application.dataPath) + Path.DirectorySeparatorChar).Length).Replace('\\', '/');
                string parent = "Assets";
                foreach (string segment in assetDirectory.Substring(7).Split('/'))
                {
                    string next = parent + "/" + segment;
                    if (!UnityEditor.AssetDatabase.IsValidFolder(next)) UnityEditor.AssetDatabase.CreateFolder(parent, segment);
                    parent = next;
                }
            }
            else
#endif
                Directory.CreateDirectory(folder);
            File.WriteAllText(Path.Combine(folder, safeName + ".json"), JsonUtility.ToJson(Config, true), new UTF8Encoding(false));
#if UNITY_EDITOR
            if (unityAssets)
            {
                string root = Path.GetFullPath(Application.dataPath) + Path.DirectorySeparatorChar;
                string absolute = Path.GetFullPath(folder);
                if (!absolute.StartsWith(root, StringComparison.OrdinalIgnoreCase)) throw new ArgumentException("Unity 资源必须保存在 Assets 下。");
                string assetFolder = "Assets/" + absolute.Substring(root.Length).Replace('\\', '/');
                var saved = Instantiate(ownedMesh); saved.name = safeName; saved.hideFlags = HideFlags.None;
                UnityEditor.AssetDatabase.CreateAsset(saved, assetFolder + "/" + safeName + ".asset");
                var material = new Material(ownedMaterial) { name = safeName, hideFlags = HideFlags.None };
                material.SetTexture("_MainTex", BodySprite.texture); material.SetColor("_Color", Config.Color); material.SetColor("_RendererColor", UnityEngine.Color.white);
                UnityEditor.AssetDatabase.CreateAsset(material, assetFolder + "/" + safeName + ".mat");
                UnityEditor.AssetDatabase.SaveAssets();
                UnityEditor.AssetDatabase.ImportAsset(assetFolder + "/" + safeName + ".json");
                Status = "已保存 Mesh、材质和配置：" + assetFolder; return folder;
            }
#else
            if (unityAssets) throw new InvalidOperationException("Unity .asset 只能在编辑器中保存。");
#endif
            WriteObj(folder, safeName);
            Status = "已导出 OBJ、贴图、材质和配置：" + folder; return folder;
        }

        private void WriteObj(string folder, string name)
        {
            var mesh = ownedMesh; var b = new StringBuilder("# PM shape, local units; 100 pixels = 1 unit\nmtllib " + name + ".mtl\nusemtl shape\n");
            foreach (var p in mesh.vertices) b.AppendFormat(Culture, "v {0} {1} {2}\n", -p.x, p.y, p.z);
            foreach (var uv in mesh.uv) b.AppendFormat(Culture, "vt {0} {1}\n", uv.x, uv.y);
            var indices = mesh.triangles;
            for (int i = 0; i < indices.Length; i += 3) b.AppendFormat(Culture, "f {0}/{0} {1}/{1} {2}/{2}\n", indices[i] + 1, indices[i + 2] + 1, indices[i + 1] + 1);
            File.WriteAllText(Path.Combine(folder, name + ".obj"), b.ToString(), new UTF8Encoding(false));
            File.WriteAllText(Path.Combine(folder, name + ".mtl"), string.Format(Culture, "newmtl shape\nKd {0} {1} {2}\nd {3}\nmap_Kd atlas.png\n", Config.Color.r, Config.Color.g, Config.Color.b, Config.Color.a));
            var rt = RenderTexture.GetTemporary(BodySprite.texture.width, BodySprite.texture.height, 0, RenderTextureFormat.ARGB32);
            var previous = RenderTexture.active; Texture2D image = null;
            try
            {
                Graphics.Blit(BodySprite.texture, rt); RenderTexture.active = rt;
                image = new Texture2D(rt.width, rt.height, TextureFormat.RGBA32, false); image.ReadPixels(new Rect(0, 0, rt.width, rt.height), 0, 0); image.Apply();
                File.WriteAllBytes(Path.Combine(folder, "atlas.png"), image.EncodeToPNG());
            }
            finally { RenderTexture.active = previous; RenderTexture.ReleaseTemporary(rt); if (image != null) Release(image); }
        }

        private void Styles()
        {
            if (label != null) return;
            if (ChineseFont == null)
            {
                ownedFont = Font.CreateDynamicFontFromOSFont(new[] { "Microsoft YaHei", "SimHei", "Noto Sans CJK SC", "Arial" }, 20);
                ChineseFont = ownedFont;
            }
            label = new GUIStyle(GUI.skin.label) { font = ChineseFont, fontSize = 20, normal = { textColor = new Color(0.85f, 0.89f, 0.94f) } };
            note = new GUIStyle(label) { fontSize = 17, wordWrap = true, normal = { textColor = new Color(0.57f, 0.65f, 0.75f) } };
            title = new GUIStyle(label) { fontSize = 28, fontStyle = FontStyle.Bold };
            section = new GUIStyle(label) { fontSize = 22, fontStyle = FontStyle.Bold };
            button = new GUIStyle(GUI.skin.button) { font = ChineseFont, fontSize = 19, fixedHeight = 38 };
            field = new GUIStyle(GUI.skin.textField) { font = ChineseFont, fontSize = 20, fixedHeight = 32 };
            toggle = new GUIStyle(GUI.skin.toggle) { font = ChineseFont, fontSize = 20, normal = { textColor = label.normal.textColor }, onNormal = { textColor = label.normal.textColor } };
        }

        private void OnGUI()
        {
            Styles(); invalidInput = null;
            float scale = Mathf.Min(Screen.width / 1920f, Screen.height / 1080f);
            Vector2 offset = new Vector2((Screen.width - 1920 * scale) / 2, (Screen.height - 1080 * scale) / 2);
            Vector2 pointer = (Event.current.mousePosition - offset) / scale;
            var oldMatrix = GUI.matrix;
            GUI.matrix = Matrix4x4.TRS(offset, Quaternion.identity, Vector3.one * scale);
            Fill(new Rect(0, 0, 1920, 1080), new Color(0.055f, 0.075f, 0.11f));
            GUI.Label(new Rect(26, 18, 900, 42), "SHAPE STUDIO   /   产品配置工作台", title);
            GUI.Label(new Rect(1260, 26, 620, 30), "1080 × 1920   ·   100 像素 = 1 Unity 单位", label);
            DrawLeft(new Rect(24, 82, 630, 926));
            DrawPreview(new Rect(696, 82, 528, 528 * 1920f / 1080), pointer);
            DrawRight(new Rect(1266, 82, 630, 926));
            GUI.color = invalidInput != null || !HasValidPreview ? new Color(1, 0.65f, 0.5f) : UnityEngine.Color.white;
            GUI.Label(new Rect(26, 1029, 1870, 44), invalidInput ?? Status, note); GUI.color = UnityEngine.Color.white;
            if (autoApply && invalidInput == null && appliedJson != JsonUtility.ToJson(Config)) Apply();
            GUI.matrix = oldMatrix;
        }

        private void DrawLeft(Rect area)
        {
            Fill(area, new Color(0.085f, 0.11f, 0.16f)); GUILayout.BeginArea(new Rect(area.x + 20, area.y + 14, area.width - 40, area.height - 28));
            leftScroll = GUILayout.BeginScrollView(leftScroll);
            Heading("01  形状与尺寸");
            int shape = GUILayout.SelectionGrid((int)Config.Settings.Shape, ShapeNames, 3, button);
            if (shape != (int)Config.Settings.Shape)
            {
                Config.Settings.Shape = (Ring2DShape)shape; edits.Clear();
            }
            var s = Config.Settings; bool ring = s.Shape == Ring2DShape.Circle || s.Shape == Ring2DShape.CShape;
            if (ring) s.Radius = Pixels("radius", "中心线半径", s.Radius);
            else if (s.Shape == Ring2DShape.ZShape) { s.TopWidth = Pixels("top", "上横段宽度", s.ZTopWidth); s.BottomWidth = Pixels("bottom", "下横段宽度", s.ZBottomWidth); }
            else s.Width = Pixels("width", "中心线宽度", s.Width);
            if (!ring && s.Shape != Ring2DShape.Straight)
            { s.Height = Pixels("height", "中心线高度", s.Height); s.CornerRadius = Pixels("corner", "圆角半径", s.CornerRadius); }
            s.Thickness = Pixels("thickness", "环身厚度", s.Thickness);
            if (s.Shape == Ring2DShape.CShape) { s.StartDegrees = Number("start", "起始角度（°）", s.StartDegrees); s.SweepDegrees = Number("sweep", "覆盖角度（°）", s.SweepDegrees); }
            GUILayout.Label("尺寸沿中心线测量，外轮廓还会增加半个环身厚度。圆角须大于厚度的一半。", note);
            Heading("02  外观与摆放");
            Config.Color = new Color(Channel("red", "红 R", Config.Color.r), Channel("green", "绿 G", Config.Color.g), Channel("blue", "蓝 B", Config.Color.b), Channel("alpha", "透明度", Config.Color.a));
            Config.PositionPixels = new Vector2(Number("x", "中心偏移 X（px，向右）", Config.PositionPixels.x), Number("y", "中心偏移 Y（px，向上）", Config.PositionPixels.y));
            Config.RotationDegrees = Number("rotation", "旋转角度（°）", Config.RotationDegrees);
            if (GUILayout.Button("居中并归零旋转", button)) { Config.PositionPixels = Vector2.zero; Config.RotationDegrees = 0; edits.Clear(); }
            Heading("03  网格精度");
            s.Segments = Mathf.RoundToInt(Number("segments", "曲线分段上限（8–512）", s.Segments, true));
            s.CapSegments = Mathf.RoundToInt(Number("caps", "端头分段上限（4–64）", s.CapSegments, true));
            Config.MeshOutlineError = Pixels("error", "轮廓误差目标", Config.MeshOutlineError);
            GUILayout.Label("误差越大，三角形越少；填 0 保留原分段。顶点在位置与 UV 相同时共享。", note);
            GUILayout.BeginHorizontal(); autoApply = GUILayout.Toggle(autoApply, " 自动应用", toggle); showGrid = GUILayout.Toggle(showGrid, " 显示网格", toggle);
            ShowHeadChannelPreview = GUILayout.Toggle(ShowHeadChannelPreview, " 预览头通道", toggle); GUILayout.EndHorizontal();
            if (GUILayout.Button("应用当前参数", button)) { if (invalidInput == null) Apply(); }
            GUILayout.EndScrollView(); GUILayout.EndArea();
        }

        private void DrawRight(Rect area)
        {
            Fill(area, new Color(0.085f, 0.11f, 0.16f)); GUILayout.BeginArea(new Rect(area.x + 20, area.y + 14, area.width - 40, area.height - 28));
            rightScroll = GUILayout.BeginScrollView(rightScroll);
            Heading("04  连接点  /  B 图");
            GUILayout.Label("连接杆与连接头互相垂直；最多 16 个连接点。", note);
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("＋ 添加连接点", button) && Config.Connections.Length < 16) AddConnection();
            if (GUILayout.Button("删除选中", button) && Config.Connections.Length > 0) RemoveConnection();
            GUILayout.EndHorizontal();
            if (Config.Connections.Length > 0)
            {
                var names = new string[Config.Connections.Length]; for (int i = 0; i < names.Length; i++) names[i] = "连接 " + (i + 1);
                int next = GUILayout.SelectionGrid(selectedConnection, names, 4, button);
                if (next != selectedConnection) { selectedConnection = next; edits.Clear(); }
                var c = Config.Connections[selectedConnection];
                if (Config.Settings.Shape == Ring2DShape.Circle || Config.Settings.Shape == Ring2DShape.CShape) c.AngleDegrees = Number("angle", "位置角度（°）", c.AngleDegrees);
                else c.PathPosition = Number("path", "路径位置（0–1）", c.PathPosition);
                c.Direction = (Ring2DConnectionDirection)GUILayout.SelectionGrid((int)c.Direction, new[] { "向外伸出", "向内延伸" }, 2, button);
                if (c.Direction == Ring2DConnectionDirection.Inward) c.ToCenter = GUILayout.Toggle(c.ToCenter, " 延伸到中心点", toggle);
                if (c.Direction == Ring2DConnectionDirection.Outward || !c.ToCenter)
                { c.Length = Pixels("length", "连接杆长度", c.Length); c.DirectionOffsetDegrees = Number("offset", "方向偏转角（°）", c.DirectionOffsetDegrees); }
                c.RodWidth = Pixels("rod", "连接杆宽度", c.RodWidth);
                c.ShowHead = GUILayout.Toggle(c.ShowHead, " 显示连接头", toggle);
                if (c.ShowHead)
                {
                    c.HeadWidth = Pixels("headwidth", "连接头横向宽度", c.HeadWidth); c.HeadDepth = Pixels("headdepth", "连接头厚度", c.HeadDepth);
                    c.AllowRingBodyPassage = GUILayout.Toggle(c.AllowRingBodyPassage, " 游戏配置：连接头中间允许物件穿过", toggle);
                    if (c.AllowRingBodyPassage)
                    {
                        c.HeadChannelWidth = Pixels("headchannel", "连接头净通道宽度", c.HeadChannelWidth);
                        GUILayout.Label("通道沿连接头横向贯通；净宽须小于连接头厚度。填 0 自动取厚度的 60%（当前 " + (c.ResolvedHeadChannelWidth * 100).ToString("0.##", Culture) + " px）。Game 按实际几何阻挡，穿过物件须比通道更薄。", note);
                        GUILayout.Label("预览中蓝色是净通道，金色是两侧轨道；左侧「预览头通道」可开关标记。", note);
                    }
                }
            }
            else GUILayout.Label("当前无连接点，本体单独生成。", note);
            Heading("05  检查与导出");
            var mesh = CurrentMesh;
            if (mesh != null) GUILayout.Label(mesh.vertexCount + " 顶点    /    " + mesh.triangles.Length / 3 + " 三角形    /    1 子网格", label);
            if (PreviewShape != null && mesh != null)
            {
                var bounds = PreviewShape.GetComponent<MeshRenderer>().bounds;
                GUILayout.Label("当前外接尺寸：" + (bounds.size.x * 100).ToString("F1", Culture) + " × " + (bounds.size.y * 100).ToString("F1", Culture) + " px", label);
                if (bounds.min.x < -5.4f || bounds.max.x > 5.4f || bounds.min.y < -9.6f || bounds.max.y > 9.6f) GUILayout.Label("外轮廓超出 1080×1920 框，将被裁切。", note);
            }
            GUILayout.BeginHorizontal(); GUILayout.Label("资源名称", label, GUILayout.Width(110)); Config.Name = GUILayout.TextField(Config.Name, field); GUILayout.EndHorizontal();
            bool oldEnabled = GUI.enabled; GUI.enabled = oldEnabled && invalidInput == null;
#if UNITY_EDITOR
            if (GUILayout.Button("保存 Unity Mesh + 材质 + 配置", button)) TryExport(true);
#endif
            if (GUILayout.Button("导出 OBJ + 贴图 + 配置", button)) TryExport(false);
            GUI.enabled = oldEnabled;
            GUILayout.Label("Mesh 使用局部坐标。摆放位置、角度与生成参数写入 JSON；分享配置后可重新导入编辑。", note);
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("查看当前 JSON", button)) jsonText = JsonUtility.ToJson(Config, true);
            if (GUILayout.Button("导入下方 JSON", button)) { if (ImportJson(jsonText)) Status = "配置已导入。"; }
            GUILayout.EndHorizontal();
#if UNITY_EDITOR
            if (GUILayout.Button("从文件导入 JSON 配置", button))
            {
                string path = UnityEditor.EditorUtility.OpenFilePanel("导入 PM Shape 配置", Path.Combine(Application.dataPath, "PM/Exports"), "json");
                if (!string.IsNullOrEmpty(path))
                {
                    try { jsonText = File.ReadAllText(path); if (ImportJson(jsonText)) Status = "配置已从文件导入。"; }
                    catch (Exception e) { Status = "读取失败：" + e.Message; }
                }
            }
#endif
            jsonText = GUILayout.TextArea(jsonText, new GUIStyle(field) { fixedHeight = 0, wordWrap = false }, GUILayout.Height(140));
            if (GUILayout.Button("恢复默认配置", button)) { Config = new PMShapeConfig(); selectedConnection = 0; edits.Clear(); Apply(); }
            GUILayout.EndScrollView(); GUILayout.EndArea();
        }

        public void AddConnection()
        {
            if (Config.Connections.Length >= 16) return;
            var c = new Ring2DConnection { Name = "连接 " + (Config.Connections.Length + 1), Length = 1, RodWidth = 0.3f, HeadWidth = 0.8f, HeadDepth = 0.4f, HeadChannelWidth = 0.24f };
            if (Config.Settings.Shape == Ring2DShape.CShape) c.AngleDegrees = Config.Settings.StartDegrees + Config.Settings.SweepDegrees / 2;
            Array.Resize(ref Config.Connections, Config.Connections.Length + 1); selectedConnection = Config.Connections.Length - 1; Config.Connections[selectedConnection] = c; edits.Clear();
        }
        public void RemoveConnection()
        {
            if (Config.Connections.Length == 0) return;
            var list = new System.Collections.Generic.List<Ring2DConnection>(Config.Connections); list.RemoveAt(selectedConnection);
            Config.Connections = list.ToArray(); selectedConnection = Mathf.Max(0, Mathf.Min(selectedConnection, list.Count - 1)); edits.Clear();
        }
        private void TryExport(bool assets)
        {
            // 资源刷新和文件对话框不能在 OnGUI 的布局栈中执行，否则会触发编辑器循环重入。
            pendingExport = assets;
        }

        private void Update()
        {
            if (!pendingExport.HasValue) return;
            bool assets = pendingExport.Value;
            pendingExport = null;
            ExecuteExport(assets);
        }

        private void ExecuteExport(bool assets)
        {
            try
            {
#if UNITY_EDITOR
                string parent = assets ? Path.Combine(Application.dataPath, "PM/Exports") : UnityEditor.EditorUtility.OpenFolderPanel("选择导出目录（自动创建新子文件夹）", Application.dataPath, "");
                if (string.IsNullOrEmpty(parent)) return;
#else
                string parent = Path.Combine(Application.persistentDataPath, "PMExports");
#endif
                Export(parent, assets);
            }
            catch (Exception e) { Status = "保存失败：" + e.Message; }
        }

        private void DrawPreview(Rect rect, Vector2 pointer)
        {
            Fill(new Rect(rect.x - 3, rect.y - 3, rect.width + 6, rect.height + 6), new Color(0.27f, 0.65f, 0.82f));
            if (PreviewTexture != null) GUI.DrawTexture(rect, PreviewTexture, ScaleMode.StretchToFill, false);
            if (showGrid)
            {
                Color grid = new Color(0.2f, 0.35f, 0.4f, 0.12f);
                for (int x = 100; x < 1080; x += 100) Fill(new Rect(rect.x + x / 1080f * rect.width, rect.y, 1, rect.height), grid);
                for (int y = 100; y < 1920; y += 100) Fill(new Rect(rect.x, rect.y + y / 1920f * rect.height, rect.width, 1), grid);
                Fill(new Rect(rect.center.x, rect.y, 1, rect.height), grid); Fill(new Rect(rect.x, rect.center.y, rect.width, 1), grid);
            }
            if (ShowHeadChannelPreview && Event.current.type == EventType.Repaint) DrawHeadChannels(rect);
            GUI.Label(new Rect(rect.x + 16, rect.y + 14, rect.width - 32, 30), "1080 × 1920   /   竖屏画面边界", new GUIStyle(note) { normal = { textColor = new Color(0.22f, 0.32f, 0.36f) } });
            var e = Event.current;
            if (e.type == EventType.MouseDown && e.button == 0 && rect.Contains(pointer)) { dragging = true; GUI.FocusControl(null); e.Use(); }
            if (e.type == EventType.MouseUp) dragging = false;
            if (dragging && e.type == EventType.MouseDrag)
            {
                float scale = Mathf.Min(Screen.width / 1920f, Screen.height / 1080f);
                if (e.shift) Config.RotationDegrees -= e.delta.x / scale * 0.5f;
                else Config.PositionPixels += new Vector2(e.delta.x / scale / rect.width * 1080, -e.delta.y / scale / rect.height * 1920);
                edits.Remove("x"); edits.Remove("y"); edits.Remove("rotation"); if (autoApply) Apply(); e.Use();
            }
        }
        private void DrawHeadChannels(Rect rect)
        {
            if (PreviewCamera == null || PreviewShape == null) return;
            Matrix4x4 previous = GUI.matrix;
            Vector2 origin = previous.MultiplyPoint3x4(rect.position), opposite = previous.MultiplyPoint3x4(rect.position + rect.size);
            var screenRect = new Rect(origin, opposite - origin);
            float scale = screenRect.width / rect.width;
            GUI.matrix = Matrix4x4.identity;
            try
            {
                foreach (var channel in previewChannels)
                {
                    Vector2 center = ChannelPoint(channel.Center, screenRect);
                    DrawChannelBox(channel, -channel.Depth / 2, -channel.Width / 2, screenRect, new Color(1, 0.75f, 0.1f, 0.9f));
                    DrawChannelBox(channel, channel.Width / 2, channel.Depth / 2, screenRect, new Color(1, 0.75f, 0.1f, 0.9f));
                    DrawChannelBox(channel, -channel.Width / 2, channel.Width / 2, screenRect, new Color(0, 0.75f, 1, 1), true);
                    if (channel.ConnectionIndex == selectedConnection && screenRect.Contains(center))
                    {
                        Vector2 halfAlong = ChannelPoint(channel.Center + channel.Along * channel.Length / 2, screenRect) - center;
                        Vector2 halfAcross = ChannelPoint(channel.Center + channel.Across * channel.Depth / 2, screenRect) - center;
                        var labelRect = new Rect(Mathf.Clamp(center.x + Mathf.Abs(halfAlong.x) + Mathf.Abs(halfAcross.x) + 8 * scale, screenRect.xMin, screenRect.xMax - 150 * scale),
                            Mathf.Clamp(center.y - 14 * scale, screenRect.yMin, screenRect.yMax - 28 * scale), 150 * scale, 28 * scale);
                        Fill(labelRect, new Color(0.03f, 0.08f, 0.12f, 0.85f));
                        int previousSize = note.fontSize;
                        note.fontSize = Mathf.Max(1, Mathf.RoundToInt(previousSize * scale));
                        GUI.Label(new Rect(labelRect.x + 5 * scale, labelRect.y + 2 * scale, 140 * scale, 26 * scale), channel.Label, note);
                        note.fontSize = previousSize;
                    }
                }
            }
            finally { GUI.matrix = previous; }
        }
        private Vector2 ChannelPoint(Vector2 local, Rect rect)
        {
            Vector3 viewport = PreviewCamera.WorldToViewportPoint(PreviewShape.transform.TransformPoint(local));
            return new Vector2(rect.x + viewport.x * rect.width, rect.y + (1 - viewport.y) * rect.height);
        }
        private void DrawChannelBox(HeadChannelPreview c, float bottom, float top, Rect rect, Color color, bool fill = false)
        {
            Vector2 a = ChannelPoint(c.Center - c.Along * c.Length / 2 + c.Across * bottom, rect);
            Vector2 b = ChannelPoint(c.Center + c.Along * c.Length / 2 + c.Across * bottom, rect);
            Vector2 d = ChannelPoint(c.Center - c.Along * c.Length / 2 + c.Across * top, rect);
            Vector2 e = ChannelPoint(c.Center + c.Along * c.Length / 2 + c.Across * top, rect);
            if (fill && rect.Contains(a) && rect.Contains(b) && rect.Contains(d) && rect.Contains(e))
                PreviewLine((a + d) / 2, (b + e) / 2, Vector2.Distance(a, d), new Color(color.r, color.g, color.b, 0.25f), rect);
            PreviewLine(a, b, 1.5f, color, rect); PreviewLine(b, e, 1.5f, color, rect); PreviewLine(e, d, 1.5f, color, rect); PreviewLine(d, a, 1.5f, color, rect);
        }
        private static bool ClipRange(float p, float q, ref float start, ref float end)
        {
            if (Mathf.Abs(p) < 0.000001f) return q >= 0;
            float t = q / p;
            if (p < 0) start = Mathf.Max(start, t); else end = Mathf.Min(end, t);
            return start <= end;
        }
        private static void PreviewLine(Vector2 a, Vector2 b, float width, Color color, Rect clip)
        {
            Vector2 delta = b - a; float start = 0, end = 1;
            if (!ClipRange(-delta.x, a.x - clip.xMin, ref start, ref end) || !ClipRange(delta.x, clip.xMax - a.x, ref start, ref end) ||
                !ClipRange(-delta.y, a.y - clip.yMin, ref start, ref end) || !ClipRange(delta.y, clip.yMax - a.y, ref start, ref end)) return;
            b = a + delta * end; a += delta * start;
            Matrix4x4 previousMatrix = GUI.matrix; Color previousColor = GUI.color;
            GUI.color = color;
            GUI.matrix = previousMatrix * Matrix4x4.TRS(a, Quaternion.Euler(0, 0, Mathf.Atan2(b.y - a.y, b.x - a.x) * Mathf.Rad2Deg), Vector3.one);
            GUI.DrawTexture(new Rect(0, -width / 2, Vector2.Distance(a, b), width), Texture2D.whiteTexture);
            GUI.matrix = previousMatrix; GUI.color = previousColor;
        }
        private float Pixels(string key, string text, float units) { return Number(key, text + "（px）", units * 100) / 100; }
        private float Channel(string key, string text, float value)
        {
            GUILayout.BeginHorizontal(); GUILayout.Label(text, label, GUILayout.Width(110));
            float next = GUILayout.HorizontalSlider(value, 0, 1); GUILayout.Label(next.ToString("F2", Culture), label, GUILayout.Width(56)); GUILayout.EndHorizontal(); return next;
        }
        private float Number(string key, string text, float value, bool integer = false)
        {
            string buffer;
            if (!edits.TryGetValue(key, out buffer)) buffer = value.ToString("0.###", Culture);
            GUILayout.BeginHorizontal(); GUILayout.Label(text, label, GUILayout.Width(370));
            string next = GUILayout.TextField(buffer, field); GUILayout.EndHorizontal(); edits[key] = next;
            float result;
            if (!float.TryParse(next, NumberStyles.Float, Culture, out result) || float.IsNaN(result) || float.IsInfinity(result) || (integer && result != Mathf.Round(result)))
            { invalidInput = text + "：请输入" + (integer ? "整数。" : "有效数字。"); return value; }
            return result;
        }
        private void Heading(string text) { GUILayout.Space(12); GUILayout.Label(text, section); GUILayout.Space(8); }
        private static void Fill(Rect rect, Color color) { Color old = GUI.color; GUI.color = color; GUI.DrawTexture(rect, Texture2D.whiteTexture); GUI.color = old; }
        private static void Release(UnityEngine.Object value) { if (Application.isPlaying) Destroy(value); else DestroyImmediate(value); }
        private void OnDestroy()
        {
            if (PreviewCamera != null) PreviewCamera.targetTexture = null;
            if (PreviewTexture != null) { PreviewTexture.Release(); Release(PreviewTexture); }
            if (ownedMesh != null) Release(ownedMesh); if (ownedMaterial != null) Release(ownedMaterial); if (ownedFont != null) Release(ownedFont);
        }
    }
}

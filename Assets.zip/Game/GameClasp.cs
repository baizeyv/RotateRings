using System;
using System.Collections.Generic;
using UnityEngine;
using Collision = WordTile.Game.GameCollision2D;

namespace WordTile.Game
{
    /// <summary>独立固定卡扣：局部 X 为通道，两侧矩形参与阻挡，不绑定任何 Shape。</summary>
    [ExecuteAlways, DisallowMultipleComponent, RequireComponent(typeof(SpriteRenderer))]
    public sealed class GameClasp : MonoBehaviour
    {
        [Min(0)] public int Id;
        internal GameLevelController Level;
        internal int LevelIndex = -1;
        public Sprite ClaspSprite;
        public Material RenderMaterial;
        public Color Color = UnityEngine.Color.white;
        [Min(0.0001f)] public float Length = 0.65f;
        [Min(0.0001f)] public float Width = 0.5f;
        [Min(0.0001f)] public float ChannelWidth = 0.28f;
        public string SortingLayer = "Default";
        public int SortingOrder = 10;
        public bool ShowCollisionGizmos = true;
        public bool Ready { get; private set; }
        public string Error { get; private set; }

        internal static readonly List<GameClasp> Active = new List<GameClasp>(128);
        internal Collision.Part Rail0, Rail1;
        internal Collision.Bounds Bounds;
        private Collision.Part local0, local1;
        private Matrix4x4 cachedMatrix;
        private bool configured, cacheValid, dirty;
        private float savedLength, savedWidth, savedChannel;

        private void OnEnable()
        {
            if (!Active.Contains(this)) Active.Add(this);
            Refresh();
        }
        private void OnDisable() { Active.Remove(this); Ready = false; if (Level != null) Level.ClaspChanged(LevelIndex); }
        private void OnValidate() { dirty = true; }

        /// <summary>改变外观/尺寸后调用。失败时清除旧轮廓；运动查询也会检查尺寸变化。</summary>
        public bool Refresh()
        {
            savedLength = Length; savedWidth = Width; savedChannel = ChannelWidth;
            dirty = false; configured = cacheValid = Ready = false;
            Rail0 = Rail1 = default(Collision.Part); Bounds = default(Collision.Bounds);
            if (!Collision.TryClaspRails(Length, Width, ChannelWidth, out local0, out local1))
            {
                Error = "Length、Channel Width 须为有限正数，Width 须大于 Channel Width。";
                Debug.LogError("GameClasp：" + Error, this); if (Level != null) Level.ClaspChanged(LevelIndex); return false;
            }
            configured = true;
            var renderer = GetComponent<SpriteRenderer>();
            renderer.sprite = ClaspSprite; renderer.color = Color;
            renderer.sortingLayerName = SortingLayer; renderer.sortingOrder = SortingOrder;
            if (RenderMaterial != null) renderer.sharedMaterial = RenderMaterial;
            renderer.drawMode = SpriteDrawMode.Sliced;
            renderer.size = new Vector2(Length, Width);
            bool ready = SyncWorld();
            if (Level != null) Level.ClaspChanged(LevelIndex);
            return ready;
        }

        internal bool SyncWorld()
        {
            if (dirty || !Length.Equals(savedLength) || !Width.Equals(savedWidth) || !ChannelWidth.Equals(savedChannel)) return Refresh();
            if (!configured) return false;
            Matrix4x4 matrix = transform.localToWorldMatrix;
            if (cacheValid && matrix.Equals(cachedMatrix)) return true;
            Vector3 x = matrix.GetColumn(0), y = matrix.GetColumn(1), z = matrix.GetColumn(2);
            double scale = Math.Sqrt((double)x.x * x.x + (double)x.y * x.y);
            double otherScale = Math.Sqrt((double)y.x * y.x + (double)y.y * y.y);
            if (!GameCollisionPart.Finite(matrix.m03) || !GameCollisionPart.Finite(matrix.m13) || double.IsNaN(scale) || double.IsInfinity(scale) ||
                double.IsNaN(otherScale) || double.IsInfinity(otherScale) || scale < 0.000001 || Math.Abs(scale - otherScale) > scale * 0.0001 ||
                Math.Abs(Vector3.Dot(x, y)) > scale * scale * 0.0001 || Math.Abs(x.z) > scale * 0.0001 || Math.Abs(y.z) > scale * 0.0001 ||
                x.x * y.y - x.y * y.x <= 0 || z.z <= 0)
            {
                Ready = cacheValid = false; Rail0 = Rail1 = default(Collision.Part); Bounds = default(Collision.Bounds);
                Error = "仅支持 XY 平面及正的均匀缩放，不支持倾斜、镜像或父级剪切。"; return false;
            }
            Rail0 = Collision.Transform(local0, matrix.m03, matrix.m13, x.x / scale, x.y / scale, scale);
            Rail1 = Collision.Transform(local1, matrix.m03, matrix.m13, x.x / scale, x.y / scale, scale);
            Bounds = Rail0.Bounds; Bounds.Include(Rail1.Bounds);
            cachedMatrix = matrix; cacheValid = Ready = true; Error = null;
            return true;
        }

#if UNITY_EDITOR
        private void OnDrawGizmosSelected()
        {
            if (!ShowCollisionGizmos || !SyncWorld()) return;
            Color previous = Gizmos.color;
            Gizmos.color = UnityEngine.Color.cyan;
            DrawRail(Rail0); DrawRail(Rail1);
            Gizmos.color = UnityEngine.Color.green;
            Gizmos.DrawLine(transform.TransformPoint(new Vector3(-Length, 0, 0)), transform.TransformPoint(new Vector3(Length, 0, 0)));
            Gizmos.color = previous;
        }
        private void DrawRail(Collision.Part rail)
        {
            Vector3 center = new Vector3((float)rail.A.X, (float)rail.A.Y, transform.position.z);
            Vector3 x = new Vector3((float)(rail.Axis.X * rail.HalfWidth), (float)(rail.Axis.Y * rail.HalfWidth), 0);
            Vector3 y = new Vector3((float)(-rail.Axis.Y * rail.HalfHeight), (float)(rail.Axis.X * rail.HalfHeight), 0);
            Gizmos.DrawLine(center - x - y, center + x - y); Gizmos.DrawLine(center + x - y, center + x + y);
            Gizmos.DrawLine(center + x + y, center - x + y); Gizmos.DrawLine(center - x + y, center - x - y);
        }
#endif
    }
}

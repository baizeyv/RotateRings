using System;

namespace WordTile.Game
{
    public enum GameShapeOperation { Rotate, Translate }

    /// <summary>输入增量计算，不读取平台输入，不保存未执行的运动。</summary>
    public static class GameDrag2D
    {
        public static bool RotationDelta(double previousX, double previousY, double currentX, double currentY, double deadRadius, out float degrees)
        {
            degrees = 0;
            double radiusSquared = deadRadius * deadRadius;
            if (previousX * previousX + previousY * previousY <= radiusSquared || currentX * currentX + currentY * currentY <= radiusSquared) return false;
            degrees = (float)(Math.Atan2(previousX * currentY - previousY * currentX, previousX * currentX + previousY * currentY) * 180 / Math.PI);
            return !float.IsNaN(degrees) && !float.IsInfinity(degrees);
        }

        public static bool MovementDelta(double dx, double dy, double axisX, double axisY, out float x, out float y)
        {
            x = y = 0;
            double lengthSquared = axisX * axisX + axisY * axisY;
            if (lengthSquared < 1e-12 || double.IsNaN(lengthSquared) || double.IsInfinity(lengthSquared)) return false;
            double amount = (dx * axisX + dy * axisY) / lengthSquared;
            x = (float)(axisX * amount); y = (float)(axisY * amount);
            return !float.IsNaN(x) && !float.IsNaN(y) && !float.IsInfinity(x) && !float.IsInfinity(y);
        }
    }
}

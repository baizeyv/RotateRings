using System;
using System.Collections.Generic;
using UnityEngine;

namespace WordTile.Game
{
    public enum GameShapeType { Unknown, Circle, CShape, Gate, Seven, ZShape, Straight }
    public enum GameOperationState { Disabled, Move, Rotate, HeadLocked }

    [Serializable]
    public struct GameHeadChannel
    {
        public int ConnectionIndex;
        public Vector2 Center;
        public float Angle, Length, ChannelWidth;
        public GameCollision2D.Part Bake()
        {
            return new GameCollisionPart { Kind = GameCollisionKind.Box, Center = Center,
                Size = new Vector2(Length, ChannelWidth), Angle = Angle }.Bake();
        }
    }

    [Serializable]
    public struct GameElementPose
    {
        public Vector3 Position, Scale;
        public float Angle;
        public void Apply(Transform target)
        {
            target.localPosition = Position; target.localRotation = Quaternion.Euler(0, 0, Angle); target.localScale = Scale;
        }
        public static GameElementPose Capture(Transform target, Transform relativeTo)
        {
            Matrix4x4 m = relativeTo.worldToLocalMatrix * target.localToWorldMatrix;
            Vector3 x = m.GetColumn(0), y = m.GetColumn(1), z = m.GetColumn(2);
            float scale = new Vector2(x.x, x.y).magnitude;
            if (!GameCollisionPart.Finite(scale) || scale <= 0.000001f || Mathf.Abs(y.magnitude - scale) > scale * 0.0001f ||
                Mathf.Abs(Vector3.Dot(x, y)) > scale * scale * 0.0001f || Mathf.Abs(x.z) + Mathf.Abs(y.z) > scale * 0.0001f ||
                Mathf.Abs(z.x) + Mathf.Abs(z.y) > Mathf.Abs(z.z) * 0.0001f || x.x * y.y - x.y * y.x <= 0)
                throw new ArgumentException(target.name + "：仅支持正的均匀 XY 缩放、XY 平面旋转，无剪切。");
            var pose = new GameElementPose { Position = m.GetColumn(3), Scale = new Vector3(scale, scale, z.z),
                Angle = Mathf.Atan2(x.y, x.x) * Mathf.Rad2Deg };
            pose.Validate(); return pose;
        }
        public void Validate()
        {
            if (!GameCollisionPart.Finite(Position.x) || !GameCollisionPart.Finite(Position.y) || !GameCollisionPart.Finite(Position.z) ||
                !GameCollisionPart.Finite(Angle) || !GameCollisionPart.Finite(Scale.x) || !GameCollisionPart.Finite(Scale.y) ||
                !GameCollisionPart.Finite(Scale.z) || Scale.x <= 0.000001f || Scale.z <= 0 || Mathf.Abs(Scale.x - Scale.y) > Scale.x * 0.0001f)
                throw new ArgumentException("关卡布局中的位置、角度或缩放无效。");
        }
    }

    [Serializable]
    public sealed class GameShapeRecord
    {
        public int Id;
        public string Name;
        public GameShapeType Type;
        public GameElementPose Pose;
        public bool Active = true, Enabled = true, AllowDrag = true, BlockMovement = true;
        public GameShapeOperation Operation;
        public Vector2 MovementDirection = Vector2.right;
        public float CollisionSkin = 0.0005f;
        public Mesh Mesh;
        public Material Material;
        public Sprite CollectionSprite;
        public int SortingLayerId, SortingOrder;
        public GameCollisionPart[] CollisionParts;
        public int BodyPartCount;
        public GameHeadChannel[] HeadChannels;
        public GameOperationState InitialState;
    }
    [Serializable]
    public sealed class GameClaspRecord
    {
        public int Id;
        public string Name;
        public GameElementPose Pose;
        public bool Active = true, Enabled = true;
        public Sprite Sprite;
        public Material Material;
        public Color Color = Color.white;
        public float Length, Width, ChannelWidth;
        public string SortingLayer;
        public int SortingOrder;
    }
    [Serializable]
    public sealed class GameBombRecord
    {
        public int Id, OwnerShapeId;
        public string Name;
        public GameElementPose Pose;
        public bool Active = true, Enabled = true;
        public Sprite Sprite;
        public float ImageWidth = 0.5f, Radius = 0.2f;
        public Vector2 CenterOffset;
        public int SortingOffset = 5;
    }
    [Serializable]
    public struct GameHeadRelation
    {
        public int OwnerShapeId, HeadIndex, BodyShapeId;
    }
    [Serializable]
    public struct GameClaspRelation
    {
        public int ClaspId, ShapeId;
    }

    [CreateAssetMenu(menuName = "Game/关卡数据", fileName = "GameLevel")]
    public sealed class GameLevelData : ScriptableObject
    {
        public int Version = 1;
        public GameShapeRecord[] Shapes = Array.Empty<GameShapeRecord>();
        public GameClaspRecord[] Clasps = Array.Empty<GameClaspRecord>();
        public GameBombRecord[] Bombs = Array.Empty<GameBombRecord>();
        public int[] RingShapeIds = Array.Empty<int>(), OtherShapeIds = Array.Empty<int>();
        public GameHeadRelation[] InitialHeadRelations = Array.Empty<GameHeadRelation>();
        public GameClaspRelation[] InitialClaspRelations = Array.Empty<GameClaspRelation>();
        public static bool IsRing(GameShapeType type) { return type == GameShapeType.Circle || type == GameShapeType.CShape; }

        public void Validate()
        {
            if (Version != 1 || Shapes == null || Shapes.Length == 0 || Clasps == null || Bombs == null)
                throw new ArgumentException("关卡版本无效或关卡未包含 Shape。");
            var ids = new HashSet<int>(); var shapes = new Dictionary<int, GameShapeRecord>();
            foreach (var s in Shapes)
            {
                if (s == null) throw new ArgumentException("Shape 记录为空。");
                CheckId(ids, s.Id); shapes.Add(s.Id, s); s.Pose.Validate();
                if (s.Type == GameShapeType.Unknown || !Enum.IsDefined(typeof(GameShapeType), s.Type) ||
                    !Enum.IsDefined(typeof(GameShapeOperation), s.Operation) || s.CollisionParts == null || s.BodyPartCount <= 0 ||
                    s.BodyPartCount > s.CollisionParts.Length || s.HeadChannels == null)
                    throw new ArgumentException("Shape " + s.Id + " 缺少类型、本体范围或连接头元数据，请重新烘焙或补充。");
                if (s.Mesh == null || s.Material == null) throw new ArgumentException("Shape " + s.Id + " 缺少 Mesh 或材质。");
                if (!GameCollisionPart.Finite(s.CollisionSkin) || s.CollisionSkin <= 0 || !GameCollisionPart.Finite(s.MovementDirection.x) ||
                    !GameCollisionPart.Finite(s.MovementDirection.y) || (s.Operation == GameShapeOperation.Translate && s.MovementDirection.sqrMagnitude < 1e-12f))
                    throw new ArgumentException("Shape " + s.Id + " 操作轴或碰撞间距无效。");
                if (!IsRing(s.Type) && s.CollectionSprite != null) throw new ArgumentException("仅圆环类可绑定 Collection Sprite。");
                foreach (var p in s.CollisionParts) p.Bake();
                foreach (var h in s.HeadChannels) { if (h.ConnectionIndex < 0) throw new ArgumentException("连接头索引无效。"); h.Bake(); }
            }
            foreach (var c in Clasps)
            {
                if (c == null) throw new ArgumentException("卡扣记录为空。");
                CheckId(ids, c.Id); c.Pose.Validate(); GameCollision2D.Part a, b;
                if (c.Sprite == null || !GameCollision2D.TryClaspRails(c.Length, c.Width, c.ChannelWidth, out a, out b))
                    throw new ArgumentException("卡扣 " + c.Id + " 缺少图片或通道尺寸无效。");
            }
            foreach (var b in Bombs)
            {
                if (b == null) throw new ArgumentException("炸弹记录为空。");
                CheckId(ids, b.Id); b.Pose.Validate();
                if (!shapes.ContainsKey(b.OwnerShapeId) || b.Sprite == null || !GameCollisionPart.Finite(b.Radius) || b.Radius <= 0 ||
                    !GameCollisionPart.Finite(b.ImageWidth) || b.ImageWidth <= 0 || !GameCollisionPart.Finite(b.CenterOffset.x) || !GameCollisionPart.Finite(b.CenterOffset.y))
                    throw new ArgumentException("炸弹 " + b.Id + " 缺少所属 Shape、图片或有效尺寸。");
            }
            ValidateGroup(RingShapeIds, true, shapes); ValidateGroup(OtherShapeIds, false, shapes);
            if (RingShapeIds.Length + OtherShapeIds.Length != Shapes.Length) throw new ArgumentException("Shape ID 列表未覆盖全部 Shape。");
        }
        private static void CheckId(HashSet<int> ids, int id)
        { if (id <= 0 || !ids.Add(id)) throw new ArgumentException("关卡元素 ID 必须为不重复的正整数：" + id); }
        private static void ValidateGroup(int[] ids, bool ring, Dictionary<int, GameShapeRecord> shapes)
        {
            if (ids == null) throw new ArgumentException("缺少 Shape ID 列表。");
            int previous = 0;
            foreach (int id in ids)
            {
                GameShapeRecord shape;
                if (id <= previous || !shapes.TryGetValue(id, out shape) || IsRing(shape.Type) != ring)
                    throw new ArgumentException("Shape ID 分组无效或未按 ID 排序。");
                previous = id;
            }
        }
    }
}

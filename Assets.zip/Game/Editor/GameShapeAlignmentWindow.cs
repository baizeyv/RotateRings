using System;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using WordTile.Game;
using Collision = WordTile.Game.GameCollision2D;

public struct GameShapeAlignmentPose
{
    public Vector3 Position;
    public Quaternion Rotation;
    public int BodyIndex;
}

/// <summary>Editor-only placement: keep parenting, dimensions and configured gameplay axes.</summary>
public static class GameShapeAlignment
{
    public static bool TrySolveGroup(GameShape moving,Component target,int headIndex,int bodyIndex,bool rotate,
        out GameShapeAlignmentPose pose,out GameShape[] group,out string error)
    {
        pose = default(GameShapeAlignmentPose); group = Array.Empty<GameShape>(); error = null;
        try
        {
            if (Application.isPlaying || moving == null) throw new ArgumentException("请在编辑模式选择待放 Shape。");
            var root = moving.GetComponentInParent<GameLevelAuthoring>(true);
            if (root == null) throw new ArgumentException("整体套入需要 GameLevelAuthoring 关卡根对象。");
            var shapes = root.GetComponentsInChildren<GameShape>(true);
            foreach (var shape in shapes)
                if (shape.isActiveAndEnabled && (shape.MetadataVersion != 1 || shape.HeadChannels == null || shape.CollisionParts == null ||
                    shape.BodyPartCount <= 0 || shape.BodyPartCount > shape.CollisionParts.Length || !shape.Initialize()))
                    throw new ArgumentException(shape.name+" 缺少有效的本体/连接头碰撞元数据，请先重新烘焙。");
            var relations = new GameLevelRelations(shapes,Array.Empty<GameClasp>()); relations.Rebuild();
            var selected = new bool[shapes.Length]; var unusedClasps = Array.Empty<bool>();
            int index = Array.IndexOf(shapes,moving);
            if (index < 0 || !moving.isActiveAndEnabled) throw new ArgumentException("待放 Shape 必须启用并位于当前关卡中。");
            selected[index] = true;
            bool changed;
            do
            {
                changed = false;
                for (int i = 0; i < shapes.Length; i++) if (selected[i])
                {
                    int before = 0; for (int j = 0; j < selected.Length; j++) if (selected[j]) before++;
                    relations.MarkNeighbors(i,selected,unusedClasps);
                    int after = 0; for (int j = 0; j < selected.Length; j++) if (selected[j]) after++;
                    changed |= before != after;
                }
            } while (changed);
            var members = new System.Collections.Generic.List<GameShape>();
            for (int i = 0; i < shapes.Length; i++) if (selected[i]) members.Add(shapes[i]);
            group = members.ToArray();
            foreach (var member in group)
            {
                foreach (var clasp in root.GetComponentsInChildren<GameClasp>(true))
                    if (clasp.transform.IsChildOf(member.transform)) throw new ArgumentException("固定卡扣不能位于随行 Shape 的子层级中，请先移到关卡根对象下。");
                foreach (var other in shapes)
                    if (Array.IndexOf(group,other) < 0 && other.transform.IsChildOf(member.transform))
                        throw new ArgumentException("随行 Shape 的子层级包含未关联 Shape，请先分离层级。");
            }
            if (target is GameShape owner && Array.IndexOf(group,owner) >= 0)
                throw new ArgumentException("目标连接头属于当前关联组，请选择组外 Shape。");
            return TrySolveTarget(moving,target,headIndex,bodyIndex,rotate,out pose,out error,group);
        }
        catch (ArgumentException e) { error = e.Message; return false; }
    }
    private static GameShapeAlignmentPose MemberPose(GameShape moving,GameShape member,GameShapeAlignmentPose pose)
    {
        var turn = pose.Rotation*Quaternion.Inverse(moving.transform.rotation);
        return new GameShapeAlignmentPose { Position = pose.Position+turn*(member.transform.position-moving.transform.position), Rotation = turn*member.transform.rotation };
    }
    private static bool GroupFits(GameShape moving,GameShape[] group,GameShapeAlignmentPose pose,
        System.Collections.Generic.List<Obstacle> obstacles,out string error)
    {
        error = null;
        foreach (var member in group)
        {
            if (member == moving) continue;
            double scale,angle; ReadMatrix(member.transform.localToWorldMatrix,out scale,out angle);
            if (!Fits(Parts(member,Vector3.zero,0,1),MemberPose(moving,member,pose),scale,obstacles,out error))
            { error = "关联 Shape「"+member.name+"」："+error; return false; }
        }
        return true;
    }
    public static bool ApplyGroup(GameShape moving,Component target,int headIndex,int bodyIndex,bool rotate,out string error)
    {
        GameShapeAlignmentPose pose; GameShape[] group;
        if (!TrySolveGroup(moving,target,headIndex,bodyIndex,rotate,out pose,out group,out error)) return false;
        var poses = new GameShapeAlignmentPose[group.Length]; var transforms = new UnityEngine.Object[group.Length];
        for (int i = 0; i < group.Length; i++) { poses[i] = MemberPose(moving,group[i],pose); transforms[i] = group[i].transform; }
        Undo.IncrementCurrentGroup(); int undo = Undo.GetCurrentGroup(); Undo.SetCurrentGroupName("关联 Shape 整体套入通道");
        Undo.RecordObjects(transforms,"关联 Shape 整体套入通道");
        for (int i = 0; i < group.Length; i++)
        {
            var t = group[i].transform;
            if (rotate) t.SetPositionAndRotation(poses[i].Position,poses[i].Rotation); else t.position = poses[i].Position;
            PrefabUtility.RecordPrefabInstancePropertyModifications(t); EditorUtility.SetDirty(t);
        }
        Undo.CollapseUndoOperations(undo); EditorSceneManager.MarkSceneDirty(moving.gameObject.scene); SceneView.RepaintAll();
        return true;
    }
    public static bool TrySolve(GameShape moving, GameShape owner, int headIndex, int bodyIndex, bool rotate,
        out GameShapeAlignmentPose pose, out string error)
    {
        return TrySolveTarget(moving,owner,headIndex,bodyIndex,rotate,out pose,out error);
    }
    public static bool TrySolve(GameShape moving,GameClasp clasp,int bodyIndex,bool rotate,out GameShapeAlignmentPose pose,out string error)
    {
        return TrySolveTarget(moving,clasp,0,bodyIndex,rotate,out pose,out error);
    }
    private static bool TrySolveTarget(GameShape moving,Component target,int headIndex,int bodyIndex,bool rotate,out GameShapeAlignmentPose pose,out string error,GameShape[] group = null)
    {
        var owner = target as GameShape; var clasp = target as GameClasp;
        pose = default(GameShapeAlignmentPose); error = null;
        try
        {
            if (Application.isPlaying) throw new ArgumentException("自动对齐仅用于编辑关卡，请先退出 Play。");
            if (moving == null || target == null || moving == owner) throw new ArgumentException("请选择对齐目标和不同的待放 Shape。");
            if (moving.gameObject.scene != target.gameObject.scene || EditorUtility.IsPersistent(moving) || EditorUtility.IsPersistent(target))
                throw new ArgumentException("请选择同一场景中的 Shape 对象。");
            if (moving.transform.IsChildOf(target.transform) || target.transform.IsChildOf(moving.transform))
                throw new ArgumentException("两个 Shape 不能互为父子。");
            var root = target.GetComponentInParent<GameLevelAuthoring>(true);
            if (root != moving.GetComponentInParent<GameLevelAuthoring>(true)) throw new ArgumentException("请先将两个 Shape 放在同一个关卡设计根对象下。");
            if (moving.MetadataVersion != 1 || moving.CollisionParts == null || moving.BodyPartCount <= 0 ||
                moving.BodyPartCount > moving.CollisionParts.Length || (owner != null && (owner.MetadataVersion != 1 || owner.HeadChannels == null || headIndex < 0 || headIndex >= owner.HeadChannels.Length)))
                throw new ArgumentException("需要本体与开放连接头元数据，请先重新烘焙或补充手动配置。");
            if (bodyIndex < -1 || bodyIndex >= moving.BodyPartCount) throw new ArgumentException("本体段索引无效。");
            if (clasp != null && (GameLevelData.IsRing(moving.ShapeType) || moving.ShapeType == GameShapeType.Unknown || !Enum.IsDefined(typeof(GameShapeType),moving.ShapeType)))
                throw new ArgumentException("固定卡扣只接受门、7、Z、直线等非环类 Shape；完整圆环和 C 环请使用连接头对齐。");
            double ownerScale, ownerAngle, sourceScale, sourceAngle;
            ReadMatrix(target.transform.localToWorldMatrix,out ownerScale,out ownerAngle);
            ReadMatrix(moving.transform.localToWorldMatrix,out sourceScale,out sourceAngle);
            Collision.Part localChannel;
            if (owner != null) localChannel = owner.HeadChannels[headIndex].Bake();
            else
            {
                Collision.Part lower,upper;
                if (!Collision.TryClaspRails(clasp.Length,clasp.Width,clasp.ChannelWidth,out lower,out upper)) throw new ArgumentException("卡扣通道尺寸无效。");
                localChannel = new GameCollisionPart { Kind = GameCollisionKind.Box, Size = new Vector2(clasp.Length,clasp.ChannelWidth) }.Bake();
            }
            var channel = Collision.Transform(localChannel,target.transform.position.x,target.transform.position.y,
                Math.Cos(ownerAngle),Math.Sin(ownerAngle),ownerScale);
            var center = new Vector3((float)channel.A.X,(float)channel.A.Y,moving.transform.position.z);
            var probe = (Vector2)moving.transform.InverseTransformPoint(center);
            var shapes = root != null ? root.GetComponentsInChildren<GameShape>(true) : UnityEngine.Object.FindObjectsByType<GameShape>(FindObjectsSortMode.None);
            var clasps = root != null ? root.GetComponentsInChildren<GameClasp>(true) : UnityEngine.Object.FindObjectsByType<GameClasp>(FindObjectsSortMode.None);
            var sourceParts = Parts(moving,Vector3.zero,0,1);
            var obstacles = Obstacles(moving,owner,clasp,shapes,clasps,group);
            double best = double.PositiveInfinity;
            string firstError = null;
            for (int i = 0; i < moving.BodyPartCount; i++)
            {
                if (bodyIndex >= 0 && i != bodyIndex) continue;
                var part = moving.CollisionParts[i]; part.Bake(); Vector2 anchor, tangent; float width;
                if (part.Kind == GameCollisionKind.Ring)
                {
                    var direction = probe-part.Center;
                    if (!rotate)
                    {
                        float a = (float)(Math.Atan2(channel.Axis.Y,channel.Axis.X)-sourceAngle);
                        var normal = new Vector2(-Mathf.Sin(a),Mathf.Cos(a));
                        direction = Vector2.Dot(direction,normal) < 0 ? -normal : normal;
                    }
                    if (direction.sqrMagnitude < 1e-12f) direction = Vector2.right; else direction.Normalize();
                    anchor = part.Center+direction*part.RingRadius; tangent = new Vector2(-direction.y,direction.x); width = part.Radius*2;
                }
                else if (part.Kind == GameCollisionKind.Capsule)
                {
                    anchor = (part.Center+part.End)/2; tangent = part.End-part.Center;
                    if (tangent.sqrMagnitude < 1e-12f) tangent = Vector2.right; else tangent.Normalize(); width = part.Radius*2;
                }
                else
                {
                    anchor = part.Center; float a = (part.Angle+(part.Size.y > part.Size.x ? 90 : 0))*Mathf.Deg2Rad;
                    tangent = new Vector2(Mathf.Cos(a),Mathf.Sin(a)); width = Mathf.Min(part.Size.x,part.Size.y);
                }
                double skin = Math.Max(moving.CollisionSkin,owner != null ? owner.CollisionSkin : 0.0005f);
                if (double.IsNaN(skin) || double.IsInfinity(skin) || skin <= 0) throw new ArgumentException("Collision Skin 必须为有限正数。");
                if (width*sourceScale+skin*2 >= channel.HalfHeight*2)
                { if (firstError == null) firstError = "本体过粗，净通道必须比本体厚度大，并留出 Collision Skin 间距。"; continue; }
                float angle = (float)(sourceAngle*180/Math.PI)+Mathf.Atan2(tangent.y,tangent.x)*Mathf.Rad2Deg;
                float turn = rotate ? Mathf.DeltaAngle(angle,(float)(Math.Atan2(channel.Axis.Y,channel.Axis.X)*180/Math.PI)) : 0;
                if (turn > 90) turn -= 180; else if (turn < -90) turn += 180;
                var rotation = rotate ? Quaternion.AngleAxis(turn,Vector3.forward)*moving.transform.rotation : moving.transform.rotation;
                var localWorld = Quaternion.AngleAxis((float)(sourceAngle*180/Math.PI)+turn,Vector3.forward)*(Vector3)(anchor*(float)sourceScale);
                var candidate = new GameShapeAlignmentPose { Position = new Vector3(center.x-localWorld.x,center.y-localWorld.y,moving.transform.position.z), Rotation = rotation, BodyIndex = i };
                string failure;
                if (!Fits(sourceParts,candidate,sourceScale,obstacles,out failure)) { if (firstError == null) firstError = failure; continue; }
                if (group != null && !GroupFits(moving,group,candidate,obstacles,out failure)) { if (firstError == null) firstError = failure; continue; }
                double distance = ((Vector2)moving.transform.TransformPoint(anchor)-(Vector2)center).sqrMagnitude;
                if (distance < best) { best = distance; pose = candidate; }
            }
            if (double.IsPositiveInfinity(best)) throw new ArgumentException(firstError ?? "没有可放入的本体段。");
            return true;
        }
        catch (ArgumentException e) { error = e.Message; return false; }
    }
    private struct Obstacle
    {
        public string Name;
        public Collision.Part[] Parts;
        public Collision.Bounds Bounds;
    }
    private static System.Collections.Generic.List<Obstacle> Obstacles(GameShape moving,GameShape owner,GameClasp targetClasp,GameShape[] shapes,GameClasp[] clasps,GameShape[] group = null)
    {
        var result = new System.Collections.Generic.List<Obstacle>(shapes.Length+clasps.Length);
        foreach (var other in shapes)
        {
            if (other == null || other == moving || (group != null && Array.IndexOf(group,other) >= 0) || other.gameObject.scene != moving.gameObject.scene || (other != owner && (!other.isActiveAndEnabled || (group == null && (!moving.BlockMovement || !other.BlockMovement))))) continue;
            double scale,angle; ReadMatrix(other.transform.localToWorldMatrix,out scale,out angle);
            var parts = Parts(other,other.transform.position,angle,scale);
            var bounds = parts[0].Bounds; for (int i = 1; i < parts.Length; i++) bounds.Include(parts[i].Bounds);
            result.Add(new Obstacle { Name = other.name, Parts = parts, Bounds = bounds });
        }
        foreach (var clasp in clasps)
        {
            if (clasp == null || clasp.gameObject.scene != moving.gameObject.scene || (clasp != targetClasp && (!clasp.isActiveAndEnabled || (group == null && !moving.BlockMovement)))) continue;
            double scale,angle; ReadMatrix(clasp.transform.localToWorldMatrix,out scale,out angle);
            Collision.Part lower,upper;
            if (!Collision.TryClaspRails(clasp.Length,clasp.Width,clasp.ChannelWidth,out lower,out upper)) throw new ArgumentException("场景中存在非法卡扣尺寸。");
            lower = Collision.Transform(lower,clasp.transform.position.x,clasp.transform.position.y,Math.Cos(angle),Math.Sin(angle),scale);
            upper = Collision.Transform(upper,clasp.transform.position.x,clasp.transform.position.y,Math.Cos(angle),Math.Sin(angle),scale);
            var bounds = lower.Bounds; bounds.Include(upper.Bounds);
            result.Add(new Obstacle { Name = clasp.name, Parts = new[] { lower,upper }, Bounds = bounds });
        }
        return result;
    }
    private static bool Fits(Collision.Part[] source,GameShapeAlignmentPose pose,double scale,System.Collections.Generic.List<Obstacle> obstacles,out string error)
    {
        error = null; double angle = pose.Rotation.eulerAngles.z*Math.PI/180;
        var candidate = new Collision.Part[source.Length];
        for (int i = 0; i < source.Length; i++) candidate[i] = Collision.Transform(source[i],pose.Position.x,pose.Position.y,Math.Cos(angle),Math.Sin(angle),scale);
        var bounds = candidate[0].Bounds; for (int i = 1; i < candidate.Length; i++) bounds.Include(candidate[i].Bounds);
        foreach (var obstacle in obstacles)
        {
            if (!bounds.Overlaps(obstacle.Bounds)) continue;
            foreach (var a in candidate) foreach (var b in obstacle.Parts)
                if (a.Bounds.Overlaps(b.Bounds) && Collision.Clearance(a,b) < -GameLevelRelations.PenetrationTolerance)
                { error = "无法放入：本体、连接件或炸弹会与「"+obstacle.Name+"」的实体轮廓重叠。可换本体段或调整尺寸。"; return false; }
        }
        return true;
    }
    private static Collision.Part[] Parts(GameShape shape,Vector3 position,double angle,double scale)
    {
        if (shape.CollisionParts == null || shape.CollisionParts.Length == 0) throw new ArgumentException(shape.name+" 缺少碰撞数据。");
        var bombs = shape.GetComponentsInChildren<GameBomb>(true);
        var result = new System.Collections.Generic.List<Collision.Part>(shape.CollisionParts.Length+bombs.Length);
        foreach (var part in shape.CollisionParts) result.Add(Collision.Transform(part.Bake(),position.x,position.y,Math.Cos(angle),Math.Sin(angle),scale));
        var proposed = Matrix4x4.TRS(position,Quaternion.Euler(0,0,(float)(angle*180/Math.PI)),new Vector3((float)scale,(float)scale,1));
        foreach (var bomb in bombs)
        {
            if (!bomb.enabled || !ActiveBelow(bomb.transform,shape.transform) || bomb.Spent || bomb.GetComponentInParent<GameShape>(true) != shape) continue;
            var matrix = proposed*shape.transform.worldToLocalMatrix*bomb.transform.localToWorldMatrix;
            double bombScale,bombAngle; ReadMatrix(matrix,out bombScale,out bombAngle);
            var c = matrix.MultiplyPoint3x4(bomb.CenterOffset);
            var part = new GameCollisionPart { Kind = GameCollisionKind.Capsule, Center = c, End = c, Radius = bomb.Radius*(float)bombScale }.Bake(); result.Add(part);
        }
        return result.ToArray();
    }
    private static bool ActiveBelow(Transform child,Transform parent)
    { for (var t = child; t != parent; t = t.parent) if (!t.gameObject.activeSelf) return false; return true; }
    private static void ReadMatrix(Matrix4x4 matrix,out double scale,out double angle)
    {
        Vector3 x = matrix.GetColumn(0),y = matrix.GetColumn(1),z = matrix.GetColumn(2);
        scale = new Vector2(x.x,x.y).magnitude; angle = Math.Atan2(x.y,x.x);
        if (double.IsNaN(scale) || double.IsInfinity(scale) || scale < 0.000001 || Math.Abs(y.magnitude-scale) > scale*0.0001 ||
            Math.Abs(Vector3.Dot(x,y)) > scale*scale*0.0001 || Math.Abs(x.z)+Math.Abs(y.z) > scale*0.0001 ||
            x.x*y.y-x.y*y.x <= 0 || z.z <= 0 || float.IsNaN(matrix.m03) || float.IsInfinity(matrix.m03) || float.IsNaN(matrix.m13) || float.IsInfinity(matrix.m13))
            throw new ArgumentException("仅支持 XY 平面和正的均匀缩放，不支持倾斜、镜像或剪切。");
    }
    public static bool Apply(GameShape moving,GameShape owner,int headIndex,int bodyIndex,bool rotate,out string error)
    {
        GameShapeAlignmentPose pose; if (!TrySolve(moving,owner,headIndex,bodyIndex,rotate,out pose,out error)) return false;
        ApplyPose(moving,pose,rotate); return true;
    }
    public static bool Apply(GameShape moving,GameClasp clasp,int bodyIndex,bool rotate,out string error)
    {
        GameShapeAlignmentPose pose; if (!TrySolve(moving,clasp,bodyIndex,rotate,out pose,out error)) return false;
        ApplyPose(moving,pose,rotate); return true;
    }
    private static void ApplyPose(GameShape moving,GameShapeAlignmentPose pose,bool rotate)
    {
        Undo.RecordObject(moving.transform,"Shape 对齐到通道");
        if (rotate) moving.transform.SetPositionAndRotation(pose.Position,pose.Rotation);
        else moving.transform.position = pose.Position;
        PrefabUtility.RecordPrefabInstancePropertyModifications(moving.transform);
        EditorUtility.SetDirty(moving.transform); EditorSceneManager.MarkSceneDirty(moving.gameObject.scene);
        SceneView.RepaintAll();
    }
}

public sealed class GameShapeAlignmentWindow : EditorWindow
{
    [SerializeField] private GameShape owner,moving;
    [SerializeField] private GameClasp clasp;
    [SerializeField] private int targetMode,headIndex,bodyIndex = -1;
    [SerializeField] private bool rotate;
    [SerializeField] private bool wholeGroup;
    private GameShape[] previewGroup = Array.Empty<GameShape>();
    public static void OpenGroup(GameShape source)
    {
        var window = GetWindow<GameShapeAlignmentWindow>("通道自动对齐"); window.minSize = new Vector2(440,300);
        window.wholeGroup = true; window.moving = source; window.owner = null; window.clasp = null;
        window.targetMode = 0; window.headIndex = 0; window.bodyIndex = -1; window.rotate = false; window.Show();
    }
    [MenuItem("Tools/Game/连接头自动对齐")]
    public static void OpenMenu() { Open(null,0,false); }
    [MenuItem("Tools/Game/固定卡扣自动对齐")]
    public static void OpenClaspMenu() { OpenClasp(null,false); }
    public static void Open(GameShape target,int head) { Open(target,head,false); }
    public static void Open(GameShape target,int head,bool allowRotation)
    {
        var window = GetWindow<GameShapeAlignmentWindow>("通道自动对齐"); window.minSize = new Vector2(440,300);
        window.wholeGroup = false; window.targetMode = 0; window.rotate = allowRotation;
        if (target != null) { window.owner = target; window.headIndex = head; } window.Show();
    }
    public static void OpenClasp(GameClasp target,bool allowRotation = false)
    {
        var window = GetWindow<GameShapeAlignmentWindow>("通道自动对齐"); window.minSize = new Vector2(440,300);
        window.wholeGroup = false; window.targetMode = 1; window.rotate = allowRotation;
        if (target != null) window.clasp = target; window.Show();
    }
    private void OnEnable() { SceneView.duringSceneGui += DrawGuide; }
    private void OnDisable() { SceneView.duringSceneGui -= DrawGuide; }
    private bool Solve(out GameShapeAlignmentPose pose,out string error)
    {
        if (wholeGroup) return GameShapeAlignment.TrySolveGroup(moving,targetMode == 0 ? (Component)owner : clasp,headIndex,bodyIndex,rotate,out pose,out previewGroup,out error);
        previewGroup = Array.Empty<GameShape>();
        return targetMode == 0 ? GameShapeAlignment.TrySolve(moving,owner,headIndex,bodyIndex,rotate,out pose,out error) :
            GameShapeAlignment.TrySolve(moving,clasp,bodyIndex,rotate,out pose,out error);
    }
    private void OnGUI()
    {
        wholeGroup = EditorGUILayout.Toggle("带上整个连接头关联组",wholeGroup);
        targetMode = EditorGUILayout.Popup("对齐目标",targetMode,new[] { "连接头（接受所有 Shape 类型）","固定卡扣（仅非环类）" });
        if (targetMode == 0)
        {
            owner = (GameShape)EditorGUILayout.ObjectField("连接头所属 Shape",owner,typeof(GameShape),true);
            if (owner != null && owner.HeadChannels != null && owner.HeadChannels.Length > 0)
            {
                var choices = new string[owner.HeadChannels.Length];
                for (int i = 0; i < choices.Length; i++) choices[i] = "连接头 "+(owner.HeadChannels[i].ConnectionIndex+1)+"，净宽 "+owner.HeadChannels[i].ChannelWidth.ToString("0.###");
                headIndex = EditorGUILayout.Popup("目标连接头",Mathf.Clamp(headIndex,0,choices.Length-1),choices);
            }
            else EditorGUILayout.HelpBox("请选择已烘焙开放连接头的 Shape。",MessageType.Info);
        }
        else
        {
            clasp = (GameClasp)EditorGUILayout.ObjectField("固定卡扣",clasp,typeof(GameClasp),true);
            EditorGUILayout.HelpBox("允许门、7、Z、直线；不允许完整圆环与 C 环。卡扣始终固定，不建立 Shape 绑定。",MessageType.Info);
        }
        moving = (GameShape)EditorGUILayout.ObjectField("待放 Shape",moving,typeof(GameShape),true);
        if (GUILayout.Button("用当前选择作为待放 Shape"))
        { if (Selection.activeGameObject != null) { moving = Selection.activeGameObject.GetComponentInParent<GameShape>(); bodyIndex = -1; } }
        if (moving != null && moving.BodyPartCount > 0 && moving.CollisionParts != null && moving.BodyPartCount <= moving.CollisionParts.Length)
        {
            var choices = new string[moving.BodyPartCount+1]; choices[0] = "自动选择最近的可放入本体段";
            for (int i = 0; i < moving.BodyPartCount; i++) choices[i+1] = "本体段 "+(i+1)+" ("+moving.CollisionParts[i].Kind+")";
            bodyIndex = EditorGUILayout.Popup("对齐本体",Mathf.Clamp(bodyIndex+1,0,choices.Length-1),choices)-1;
        }
        rotate = EditorGUILayout.Popup("角度处理",rotate ? 1 : 0,new[] { "保持当前角度，只移动","旋转并沿通道对齐" }) == 1;
        EditorGUILayout.HelpBox("尺寸、层级和位移轴保持不变。保持角度模式不会修改 Transform 的旋转；若当前方向放不进去，会提示失败。对齐后请重新分析和导出关卡。",MessageType.Info);
        GameShapeAlignmentPose pose; string error; bool valid = Solve(out pose,out error);
        if (wholeGroup && previewGroup.Length > 0)
        {
            EditorGUILayout.LabelField("整体移动 Shape 数",previewGroup.Length.ToString());
            foreach (var member in previewGroup) EditorGUILayout.LabelField("  #"+member.Id+" "+member.name);
            EditorGUILayout.HelpBox("连接头关联递归包含两个方向。所有 Shape 作同一刚体变换；卡扣固定，炸弹随 Owner。卡扣类型限制只针对实际套入的当前 Shape。",MessageType.Info);
        }
        if (!valid) EditorGUILayout.HelpBox(error,MessageType.Warning);
        else EditorGUILayout.LabelField("将使用本体段",(pose.BodyIndex+1).ToString());
        using (new EditorGUI.DisabledScope(!valid)) if (GUILayout.Button(rotate ? "旋转并对齐放入" : "保持角度对齐放入"))
        {
            bool applied = wholeGroup ? GameShapeAlignment.ApplyGroup(moving,targetMode == 0 ? (Component)owner : clasp,headIndex,bodyIndex,rotate,out error) :
                targetMode == 0 ? GameShapeAlignment.Apply(moving,owner,headIndex,bodyIndex,rotate,out error) : GameShapeAlignment.Apply(moving,clasp,bodyIndex,rotate,out error);
            if (!applied) Debug.LogWarning(error); Repaint();
        }
    }
    private void DrawGuide(SceneView view)
    {
        Matrix4x4 matrix; Vector3 size;
        if (targetMode == 0)
        {
            if (owner == null || owner.HeadChannels == null || headIndex < 0 || headIndex >= owner.HeadChannels.Length) return;
            var head = owner.HeadChannels[headIndex];
            matrix = owner.transform.localToWorldMatrix*Matrix4x4.TRS(head.Center,Quaternion.Euler(0,0,head.Angle),Vector3.one);
            size = new Vector3(head.Length,head.ChannelWidth,0);
        }
        else
        {
            if (clasp == null) return;
            matrix = clasp.transform.localToWorldMatrix; size = new Vector3(clasp.Length,clasp.ChannelWidth,0);
        }
        using (new Handles.DrawingScope(Color.cyan,matrix))
        { Handles.DrawWireCube(Vector3.zero,size); Handles.DrawLine(Vector3.left*size.x/2,Vector3.right*size.x/2); }
        GameShapeAlignmentPose pose; string error;
        if (Solve(out pose,out error)) using (new Handles.DrawingScope(Color.green))
        {
            Handles.DrawDottedLine(moving.transform.position,pose.Position,5); Handles.DrawWireDisc(pose.Position,Vector3.forward,HandleUtility.GetHandleSize(pose.Position)*0.08f);
            foreach (var member in previewGroup)
            {
                var turn = pose.Rotation*Quaternion.Inverse(moving.transform.rotation);
                var position = pose.Position+turn*(member.transform.position-moving.transform.position);
                Handles.DrawDottedLine(member.transform.position,position,5);
                Handles.DrawWireDisc(position,Vector3.forward,HandleUtility.GetHandleSize(position)*0.08f);
            }
        }
    }
}

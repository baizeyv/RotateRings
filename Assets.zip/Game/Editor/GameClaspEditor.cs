using UnityEditor;
using UnityEngine;
using WordTile.Game;

[CustomEditor(typeof(GameClasp))]
public sealed class GameClaspEditor : Editor
{
    public override void OnInspectorGUI()
    {
        var clasp = (GameClasp)target;
        EditorGUI.BeginChangeCheck(); DrawDefaultInspector();
        bool changed = EditorGUI.EndChangeCheck();
        bool refresh = GUILayout.Button("刷新卡扣");
        if (changed || refresh)
        {
            Undo.RecordObject(clasp.GetComponent<SpriteRenderer>(), "刷新固定卡扣");
            clasp.Refresh(); EditorUtility.SetDirty(clasp); EditorUtility.SetDirty(clasp.GetComponent<SpriteRenderer>());
            SceneView.RepaintAll();
        }
        EditorGUILayout.HelpBox("局部 X 是通道方向。卡扣固定在场景中，仅通过两侧轨道阻挡；无需绑定 Shape，不会改变物件位移方向。", MessageType.Info);
        if (GUILayout.Button("保持角度对齐到此卡扣")) GameShapeAlignmentWindow.OpenClasp(clasp,false);
        if (GUILayout.Button("旋转并对齐到此卡扣")) GameShapeAlignmentWindow.OpenClasp(clasp,true);
        if (clasp.Error != null) EditorGUILayout.HelpBox(clasp.Error, MessageType.Error);
    }

    private void OnSceneGUI()
    {
        if (Application.isPlaying) return;
        var clasp = (GameClasp)target; Vector3 center = clasp.transform.position;
        float size = HandleUtility.GetHandleSize(center)*0.065f;
        using (new Handles.DrawingScope(Color.cyan))
            if (Handles.Button(center,Quaternion.identity,size,size*1.6f,Handles.DotHandleCap)) GameShapeAlignmentWindow.OpenClasp(clasp,false);
    }

    [MenuItem("GameObject/Game/固定卡扣", false, 10)]
    private static void Create(MenuCommand command)
    {
        var go = new GameObject("固定卡扣");
        var context = command.context as GameObject;
        if (context != null)
        {
            go.transform.position = context.transform.position;
            UnityEngine.SceneManagement.SceneManager.MoveGameObjectToScene(go, context.scene);
        }
        var clasp = go.AddComponent<GameClasp>();
        foreach (var asset in AssetDatabase.LoadAllAssetsAtPath("Assets/RotateRings/Ring2D/Textures/ringextra_2d.png"))
            if (asset is Sprite sprite && sprite.name == "RingClasp_C") { clasp.ClaspSprite = sprite; break; }
        clasp.Refresh(); Undo.RegisterCreatedObjectUndo(go, "创建固定卡扣"); Selection.activeGameObject = go;
    }
}

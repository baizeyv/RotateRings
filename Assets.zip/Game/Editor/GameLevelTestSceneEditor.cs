using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using RotateRings;
using WordTile.Game;
using WordTile.PM;

public static class GameLevelTestSceneEditor
{
    public const string ScenePath = "Assets/Game/Scenes/GameLevelTest.unity";
    public const string DataPath = "Assets/Game/TestLevelAssets/GameLevelTest.asset";
    private const string ResourcesPath = "Assets/Game/TestLevelAssets";
    [MenuItem("Tools/Game/打开关卡测试场景")]
    public static void Open()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        if (File.Exists(ScenePath)) EditorSceneManager.OpenScene(ScenePath); else Build();
    }
    [MenuItem("Tools/Game/重建关卡测试场景")]
    private static void Rebuild()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        Build();
    }
    public static void Build()
    {
        Directory.CreateDirectory("Assets/Game/Scenes"); Directory.CreateDirectory(ResourcesPath); AssetDatabase.Refresh();
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        var camera = new GameObject("Main Camera").AddComponent<Camera>(); camera.tag = "MainCamera";
        camera.transform.position = new Vector3(0,0,-20); camera.orthographic = true; camera.orthographicSize = 5.3f;
        camera.clearFlags = CameraClearFlags.SolidColor; camera.backgroundColor = new Color(0.94f,0.95f,0.97f);
        camera.gameObject.AddComponent<AudioListener>();
        var urp = Type.GetType("UnityEngine.Rendering.Universal.UniversalAdditionalCameraData, Unity.RenderPipelines.Universal.Runtime");
        if (urp != null) camera.gameObject.AddComponent(urp);
        var source = new GameObject("Level Design - edit and export here").AddComponent<GameLevelAuthoring>();
        var ring = Config(Ring2DShape.Circle,0.85f,0.18f);
        ring.Connections = new[] { new Ring2DConnection { AngleDegrees = 0, Direction = Ring2DConnectionDirection.Outward, ToCenter = false,
            Length = 0.4f, RodWidth = 0.12f, HeadWidth = 0.95f, HeadDepth = 0.55f, HeadChannelWidth = 0.30f } };
        var owner = Shape(source.transform,1,"Locked ring",new Vector2(-5.4f,2.3f),ring,new Color(0.91f,0.24f,0.46f));
        var passer = Shape(source.transform,2,"Pull up to unlock ring",new Vector2(-5.4f+owner.HeadChannels[0].Center.x,2.3f),
            Config(Ring2DShape.Straight,1.3f,0.15f),new Color(0.18f,0.44f,0.96f));
        passer.transform.rotation = Quaternion.Euler(0,0,90); passer.MovementDirection = Vector2.up; passer.Initialize();
        Shape(source.transform,3,"Free C ring",new Vector2(3.5f,2.3f),Config(Ring2DShape.CShape,0.9f,0.18f),new Color(0.05f,0.66f,0.73f));
        var disabled = Shape(source.transform,4,"Disabled bar",new Vector2(6,2.3f),Config(Ring2DShape.Straight,0.9f,0.22f),new Color(0.54f,0.57f,0.62f)); disabled.AllowDrag = false;
        var headBar = Config(Ring2DShape.Straight,2.2f,0.16f);
        headBar.Connections = new[] { new Ring2DConnection { PathPosition = 1, Direction = Ring2DConnectionDirection.Outward, ToCenter = false,
            Length = 0.05f, HeadWidth = 0.50f, HeadDepth = 0.50f, RodWidth = 0.12f, AllowRingBodyPassage = false } };
        Shape(source.transform,5,"Slide through fixed clasp",new Vector2(-4.7f,-2.2f),headBar,new Color(0.13f,0.67f,0.35f));
        var clasp = new GameObject("101 Fixed clasp").AddComponent<GameClasp>(); clasp.transform.SetParent(source.transform,false);
        clasp.transform.localPosition = new Vector3(-4,-2.2f,0); clasp.Id = 101; clasp.Length = 0.65f; clasp.Width = 0.62f; clasp.ChannelWidth = 0.32f;
        foreach (var asset in AssetDatabase.LoadAllAssetsAtPath("Assets/RotateRings/Ring2D/Textures/ringextra_2d.png"))
            if (asset is Sprite sprite && sprite.name == "RingClasp_C") clasp.ClaspSprite = sprite;
        if (clasp.ClaspSprite == null) throw new InvalidOperationException("Missing RingClasp_C Sprite.");
        clasp.RenderMaterial = MaterialAsset("Clasp",new Color(0.32f,0.36f,0.43f)); clasp.Refresh();
        var bombOwner = Shape(source.transform,6,"Bomb owner - fixed for demo",new Vector2(2.5f,-2.3f),Config(Ring2DShape.Straight,1.4f,0.16f),new Color(0.78f,0.57f,0.18f)); bombOwner.AllowDrag = false;
        var bombObject = new GameObject("201 Owned bomb"); bombObject.transform.SetParent(bombOwner.transform,false); bombObject.transform.localPosition = new Vector3(0.9f,0,0);
        var bomb = bombObject.AddComponent<GameBomb>(); bomb.Id = 201; bomb.Sprite = AssetDatabase.LoadAssetAtPath<Sprite>("Assets/tex_boom_01.png"); bomb.Refresh();
        Shape(source.transform,7,"Drag left into bomb",new Vector2(5.6f,-2.35f),Config(Ring2DShape.Straight,1.2f,0.16f),new Color(0.96f,0.39f,0.12f));
        var data = GameLevelExporter.Export(source,DataPath);
        var controller = new GameObject("Level Controller - loads exported data").AddComponent<GameLevelController>(); controller.Data = data;
        var input = new GameObject("GameShape Input").AddComponent<GameShapeInput>(); input.InputCamera = camera;
        var panel = new GameObject("Test Instructions and Reset").AddComponent<GameLevelTestPanel>(); panel.Controller = controller; panel.ViewCamera = camera;
        EditorSceneManager.SaveScene(scene,ScenePath); AssetDatabase.SaveAssets(); Selection.activeGameObject = source.gameObject;
        Debug.Log("GAME_LEVEL_TEST_SCENE_BUILT: " + ScenePath);
    }
    private static PMShapeConfig Config(Ring2DShape shape, float size, float thickness)
    {
        return new PMShapeConfig { Settings = new Ring2DSettings { Shape = shape, Radius = size, Width = size, Height = 1,
            Thickness = thickness, CornerRadius = 0.25f, StartDegrees = 45, SweepDegrees = 270 } };
    }
    private static GameShape Shape(Transform parent,int id,string name,Vector2 position,PMShapeConfig config,Color color)
    {
        var obj = new GameObject(id+" "+name); obj.transform.SetParent(parent,false); obj.transform.localPosition = position;
        var shape = obj.AddComponent<GameShape>(); shape.Id = id; GameShapeType type; int count; GameHeadChannel[] heads;
        shape.CollisionParts = GameShapeEditor.BakeCollisionParts(config,48,out type,out count,out heads);
        shape.ShapeType = type; shape.BodyPartCount = count; shape.HeadChannels = heads; shape.MetadataVersion = 1;
        shape.Operation = GameLevelData.IsRing(type) ? GameShapeOperation.Rotate : GameShapeOperation.Translate;
        shape.ShapeMesh = MeshAsset(id,shape.CollisionParts); shape.ShapeMaterial = MaterialAsset(id.ToString(),color);
        shape.GetComponent<MeshRenderer>().sortingOrder = id; shape.Initialize(); return shape;
    }
    private static Material MaterialAsset(string name,Color color)
    {
        string path = ResourcesPath+"/"+name+".mat"; var material = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (material == null)
        {
            var shader = Shader.Find("RotateRings/Ring 2D"); if (shader == null) throw new InvalidOperationException("Missing Game display shader.");
            material = new Material(shader); AssetDatabase.CreateAsset(material,path);
        }
        material.SetColor("_Color",color); material.SetColor("_RendererColor",Color.white); EditorUtility.SetDirty(material); return material;
    }
    // Test meshes show the exact cached collision outline, including empty head channels.
    private static Mesh MeshAsset(int id,GameCollisionPart[] parts)
    {
        var vertices = new List<Vector3>(); var triangles = new List<int>();
        foreach (var part in parts)
        {
            if (part.Kind == GameCollisionKind.Ring)
            {
                int start = vertices.Count;
                for (int i = 0; i <= 96; i++)
                {
                    var direction = new Vector2(Mathf.Cos(i*Mathf.PI/48),Mathf.Sin(i*Mathf.PI/48));
                    vertices.Add(part.Center+direction*(part.RingRadius-part.Radius)); vertices.Add(part.Center+direction*(part.RingRadius+part.Radius));
                    if (i > 0) { int a = start+(i-1)*2; triangles.AddRange(new[] {a,a+1,a+2,a+1,a+3,a+2}); }
                }
                continue;
            }
            var polygon = new List<Vector2>();
            if (part.Kind == GameCollisionKind.Box)
            {
                float angle = part.Angle*Mathf.Deg2Rad; var x = new Vector2(Mathf.Cos(angle),Mathf.Sin(angle))*part.Size.x/2;
                var y = new Vector2(-Mathf.Sin(angle),Mathf.Cos(angle))*part.Size.y/2;
                polygon.Add(part.Center-x-y); polygon.Add(part.Center+x-y); polygon.Add(part.Center+x+y); polygon.Add(part.Center-x+y);
            }
            else
            {
                Vector2 axis = part.End-part.Center; float angle = Mathf.Atan2(axis.y,axis.x);
                for (int i = 0; i <= 16; i++) { float a = angle-Mathf.PI/2+i*Mathf.PI/16; polygon.Add(part.End+new Vector2(Mathf.Cos(a),Mathf.Sin(a))*part.Radius); }
                for (int i = 0; i <= 16; i++) { float a = angle+Mathf.PI/2+i*Mathf.PI/16; polygon.Add(part.Center+new Vector2(Mathf.Cos(a),Mathf.Sin(a))*part.Radius); }
            }
            int center = vertices.Count; Vector2 midpoint = part.Kind == GameCollisionKind.Box ? part.Center : (part.Center+part.End)/2;
            vertices.Add(midpoint); foreach (var point in polygon) vertices.Add(point);
            for (int i = 0; i < polygon.Count; i++) { triangles.Add(center); triangles.Add(center+1+i); triangles.Add(center+1+(i+1)%polygon.Count); }
        }
        string path = ResourcesPath+"/Shape"+id+".asset"; var mesh = AssetDatabase.LoadAssetAtPath<Mesh>(path);
        if (mesh == null) { mesh = new Mesh(); AssetDatabase.CreateAsset(mesh,path); }
        mesh.Clear(); mesh.SetVertices(vertices); mesh.SetTriangles(triangles,0);
        var uv = new Vector2[vertices.Count]; var colors = new Color32[vertices.Count]; for (int i = 0; i < colors.Length; i++) colors[i] = Color.white;
        mesh.uv = uv; mesh.colors32 = colors; mesh.RecalculateBounds(); EditorUtility.SetDirty(mesh); return mesh;
    }
}

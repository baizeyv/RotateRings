using System;
using System.Collections.Generic;
using RotateRings;
using UnityEditor;
using UnityEngine;
using WordTile.Game;
using WordTile.PM;

[CustomEditor(typeof(GameShape))]
public sealed class GameShapeEditor : Editor
{
    private int arcSegments = 48;
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();
        EditorGUILayout.HelpBox("圆环/C 环拖动旋转，其余形状沿 Movement Direction 拖动。输入由一个 GameShapeInput 处理；JSON 仅在此处烘焙。", MessageType.Info);
        arcSegments = EditorGUILayout.IntSlider("烘焙曲线分段上限", arcSegments, 16, 96);
        var shape = (GameShape)target;
        EditorGUILayout.LabelField("当前状态", shape.OperationState.ToString());
        if (shape.MetadataVersion != 1) EditorGUILayout.HelpBox("关卡导出需要类型、本体数量及连接头通道元数据。请从 PM JSON 重新烘焙，或填写后应用手动配置。", MessageType.Warning);
        if (GUILayout.Button("添加所属炸弹")) GameBombEditor.Add(shape);
        if (GUILayout.Button("保持角度对齐到我的连接头")) GameShapeAlignmentWindow.Open(shape,0,false);
        if (GUILayout.Button("旋转并对齐到我的连接头")) GameShapeAlignmentWindow.Open(shape,0,true);
        if (GUILayout.Button("从 PM JSON 烘焙碰撞并应用资源")) Bake(shape);
        if (GUILayout.Button("应用手动 Collision Parts"))
        {
            Record(shape);
            if (shape.ShapeType != GameShapeType.Unknown && shape.BodyPartCount > 0 && shape.BodyPartCount <= shape.CollisionParts.Length && shape.HeadChannels != null)
                shape.MetadataVersion = 1;
            shape.Initialize(); EditorUtility.SetDirty(shape);
        }
    }
    private static void Record(GameShape shape)
    {
        Undo.RecordObjects(new UnityEngine.Object[] { shape, shape.GetComponent<MeshFilter>(), shape.GetComponent<MeshRenderer>() }, "配置 GameShape");
    }
    private void OnSceneGUI()
    {
        var shape = (GameShape)target;
        if (shape.HeadChannels == null || Application.isPlaying) return;
        for (int i = 0; i < shape.HeadChannels.Length; i++)
        {
            var head = shape.HeadChannels[i]; Vector3 center = shape.transform.TransformPoint(head.Center);
            float size = HandleUtility.GetHandleSize(center)*0.065f;
            using (new Handles.DrawingScope(Color.cyan))
            {
                if (Handles.Button(center,Quaternion.identity,size,size*1.6f,Handles.DotHandleCap)) GameShapeAlignmentWindow.Open(shape,i);
                Handles.Label(center+Vector3.up*size*2,"连接头 "+(head.ConnectionIndex+1));
            }
        }
    }
    private void Bake(GameShape shape)
    {
        try
        {
            if (shape.ShapeConfig == null) throw new ArgumentException("请选择 PM 导出的 JSON。");
            var config = JsonUtility.FromJson<PMShapeConfig>(shape.ShapeConfig.text);
            GameShapeType type; int bodyCount; GameHeadChannel[] heads;
            var parts = BakeCollisionParts(config, arcSegments, out type, out bodyCount, out heads);
            Record(shape); shape.CollisionParts = parts; shape.ShapeType = type; shape.BodyPartCount = bodyCount; shape.HeadChannels = heads; shape.MetadataVersion = 1;
            shape.Operation = config.Settings.Shape == Ring2DShape.Circle || config.Settings.Shape == Ring2DShape.CShape ? GameShapeOperation.Rotate : GameShapeOperation.Translate;
            shape.Initialize();
            EditorUtility.SetDirty(shape); SceneView.RepaintAll();
        }
        catch (ArgumentException e) { Debug.LogError("碰撞烘焙失败：" + e.Message, shape); }
    }
    /// <summary>编辑器离线烘焙；连接头通道和固定卡扣使用同一个矩形轨道定义。</summary>
    public static GameCollisionPart[] BakeCollisionParts(PMShapeConfig config, int arcSegments = 48)
    {
        GameShapeType type; int bodyCount; GameHeadChannel[] heads;
        return BakeCollisionParts(config, arcSegments, out type, out bodyCount, out heads);
    }
    public static GameCollisionPart[] BakeCollisionParts(PMShapeConfig config, int arcSegments, out GameShapeType type, out int bodyCount, out GameHeadChannel[] heads)
    {
        PMShapeWorkbench.ValidateConfig(config);
        if (arcSegments < 8 || arcSegments > 128) throw new ArgumentException("曲线分段须在 8–128 之间。");
        var parts = new List<GameCollisionPart>();
        var settings = config.Settings;
        switch (settings.Shape)
        {
            case Ring2DShape.Circle: type = GameShapeType.Circle; break;
            case Ring2DShape.CShape: type = GameShapeType.CShape; break;
            case Ring2DShape.Gate: type = GameShapeType.Gate; break;
            case Ring2DShape.Seven: type = GameShapeType.Seven; break;
            case Ring2DShape.ZShape: type = GameShapeType.ZShape; break;
            default: type = GameShapeType.Straight; break;
        }
        var channels = new List<GameHeadChannel>();
        if (settings.Shape == Ring2DShape.Circle)
            parts.Add(new GameCollisionPart { Kind = GameCollisionKind.Ring, RingRadius = settings.Radius, Radius = settings.Thickness / 2 });
        else
        {
            // 只在编辑器复用 PM 的尺寸/路径定义，运行时与旧玩法/碰撞实现完全独立。
            var path = Ring2DGeometry.ColliderPath(settings, arcSegments);
            float curveRadius = settings.Shape == Ring2DShape.CShape ? settings.Radius : settings.CornerRadius;
            float error = settings.Shape == Ring2DShape.Straight ? 0 : curveRadius * (1 - Mathf.Cos(Mathf.PI / (arcSegments / 4 * 4)));
            for (int i = 1; i < path.Length; i++)
                parts.Add(new GameCollisionPart { Kind = GameCollisionKind.Capsule, Center = Point(path[i - 1]), End = Point(path[i]), Radius = settings.Thickness / 2 + error });
        }
        bodyCount = parts.Count;
        for (int connectionIndex = 0; connectionIndex < config.Connections.Length; connectionIndex++)
        {
            var c = config.Connections[connectionIndex];
            var pose = Ring2DGeometry.ConnectionPose(settings, c);
            float angle = Mathf.Atan2((float)pose.DY, (float)pose.DX) * Mathf.Rad2Deg;
            if (pose.Length > 0.00001)
                parts.Add(new GameCollisionPart { Kind = GameCollisionKind.Box, Center = (Point(pose.Start) + Point(pose.End)) / 2,
                    Size = new Vector2((float)pose.Length, c.RodWidth), Angle = angle });
            if (!c.ShowHead) continue;
            if (!c.AllowRingBodyPassage)
                parts.Add(new GameCollisionPart { Kind = GameCollisionKind.Box, Center = Point(pose.Head), Size = new Vector2(c.HeadWidth, c.HeadDepth), Angle = angle - 90 });
            else
            {
                GameCollision2D.Part lower, upper;
                if (!GameCollision2D.TryClaspRails(c.HeadWidth, c.HeadDepth, c.ResolvedHeadChannelWidth, out lower, out upper))
                    throw new ArgumentException("连接头通道尺寸无效。");
                Vector2 center = Point(pose.Head), normal = new Vector2((float)pose.DX, (float)pose.DY);
                channels.Add(new GameHeadChannel { ConnectionIndex = connectionIndex, Center = center, Angle = angle - 90,
                    Length = c.HeadWidth, ChannelWidth = c.ResolvedHeadChannelWidth });
                parts.Add(new GameCollisionPart { Kind = GameCollisionKind.Box, Center = center + normal * (float)lower.A.Y,
                    Size = new Vector2((float)(lower.HalfWidth * 2), (float)(lower.HalfHeight * 2)), Angle = angle - 90 });
                parts.Add(new GameCollisionPart { Kind = GameCollisionKind.Box, Center = center + normal * (float)upper.A.Y,
                    Size = new Vector2((float)(upper.HalfWidth * 2), (float)(upper.HalfHeight * 2)), Angle = angle - 90 });
            }
        }
        heads = channels.ToArray(); return parts.ToArray();
    }
    private static Vector2 Point(Ring2DPoint p) { return new Vector2((float)p.X, (float)p.Y); }
}


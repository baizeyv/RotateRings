using System;
using System.Collections.Generic;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using WordTile.Game;

/// <summary>Authoring-only renderer sorting; no scene hierarchy or runtime relation changes.</summary>
public static class GameLevelSorting
{
    public static string Arrange(GameLevelAuthoring source)
    {
        if (source == null || Application.isPlaying) throw new ArgumentException("请在编辑模式选择关卡设计根对象。");
        if (source.GetComponentsInChildren<GameLevelAuthoring>(true).Length != 1) throw new ArgumentException("关卡设计根对象不能嵌套。");
        var shapes = source.GetComponentsInChildren<GameShape>(true);
        var clasps = source.GetComponentsInChildren<GameClasp>(true);
        var bombs = source.GetComponentsInChildren<GameBomb>(true);
        int n = shapes.Length; if (n == 0) throw new ArgumentException("关卡中没有 Shape。");
        var renderers = new MeshRenderer[n]; var oldLayer = new int[n]; var oldOrder = new int[n];
        var indices = new Dictionary<GameShape,int>();
        var undo = new List<UnityEngine.Object> { source };
        for (int i = 0; i < n; i++)
        {
            var shape = shapes[i];
            if (shape.MetadataVersion != 1 || shape.BodyPartCount <= 0 || shape.CollisionParts == null || shape.BodyPartCount > shape.CollisionParts.Length || shape.HeadChannels == null)
                throw new ArgumentException(shape.name + " 缺少本体/连接头元数据，请先重新烘焙。");
            CheckGrouping(shape.transform,source.transform);
            if (!shape.Initialize()) throw new ArgumentException(shape.name + " 的碰撞数据或 Transform 无效。");
            renderers[i] = shape.GetComponent<MeshRenderer>(); undo.Add(renderers[i]); indices.Add(shape,i);
            oldLayer[i] = SortingLayer.GetLayerValueFromID(renderers[i].sortingLayerID); oldOrder[i] = renderers[i].sortingOrder;
        }
        foreach (var clasp in clasps)
        {
            CheckGrouping(clasp.transform,source.transform);
            undo.Add(clasp); undo.Add(clasp.GetComponent<SpriteRenderer>());
        }
        int offset = 0;
        foreach (var bomb in bombs)
        {
            var owner = bomb.GetComponentInParent<GameShape>(true);
            if (owner == null || !indices.ContainsKey(owner)) throw new ArgumentException(bomb.name + " 没有本关卡的所属 Shape。");
            CheckGrouping(bomb.transform,source.transform); offset = Math.Max(offset,bomb.SortingOffset);
            foreach (var renderer in bomb.GetComponentsInChildren<SpriteRenderer>(true))
                if (renderer.GetComponentInParent<GameBomb>(true) == bomb) undo.Add(renderer);
        }
        var graph = new GameLevelRelations(shapes,clasps); graph.Rebuild();
        var edges = new bool[n,n]; var incoming = new int[n];
        for (int owner = 0; owner < n; owner++) for (int head = 0; head < shapes[owner].HeadChannels.Length; head++)
            for (int body = 0; body < n; body++) if (graph.HeadOccupied(owner,head,body) && !edges[body,owner])
            { edges[body,owner] = true; incoming[owner]++; }
        var sequence = new int[n]; var selected = new bool[n];
        for (int rank = 0; rank < n; rank++)
        {
            int next = -1;
            for (int i = 0; i < n; i++) if (!selected[i] && incoming[i] == 0 &&
                (next < 0 || oldLayer[i] < oldLayer[next] || (oldLayer[i] == oldLayer[next] && oldOrder[i] < oldOrder[next]))) next = i;
            if (next < 0)
            {
                var cycle = new StringBuilder(); for (int i = 0; i < n; i++) if (!selected[i]) cycle.Append(shapes[i].name).Append("；");
                throw new ArgumentException("穿入关系存在循环，无法同时满足上下层要求；显示排序未修改。请检查：" + cycle);
            }
            sequence[rank] = next; selected[next] = true;
            for (int i = 0; i < n; i++) if (edges[next,i]) incoming[i]--;
        }
        long stride = (long)offset + 1;
        long claspStart = (n-1)*stride + offset + 1;
        if (claspStart + Math.Max(0,clasps.Length-1) > short.MaxValue)
            throw new ArgumentException("Shape 数量或炸弹 Sorting Offset 超过显示排序范围，请减小 Sorting Offset。");
        for (int i = 0; i < n; i++) foreach (var bomb in bombs)
            if (bomb.GetComponentInParent<GameShape>(true) == shapes[sequence[i]] && (long)i*stride + bomb.SortingOffset < short.MinValue)
                throw new ArgumentException(bomb.name + " 的 Sorting Offset 超过显示排序范围。");
        int layerId = renderers[0].sortingLayerID; string layerName = SortingLayer.IDToName(layerId);
        Undo.IncrementCurrentGroup(); int group = Undo.GetCurrentGroup(); Undo.SetCurrentGroupName("自动排列关卡显示层级");
        Undo.RecordObjects(undo.ToArray(),"自动排列关卡显示层级");
        var text = new StringBuilder("自动显示排序完成：统一 Sorting Layer = " + layerName + "。卡扣置顶，穿入者在连接头所属 Shape 下方。\n");
        for (int rank = 0; rank < n; rank++)
        {
            int index = sequence[rank]; renderers[index].sortingLayerID = layerId; renderers[index].sortingOrder = (int)(rank*stride);
            Save(renderers[index]); text.AppendLine(shapes[index].name + "：Order " + renderers[index].sortingOrder);
        }
        foreach (var bomb in bombs)
        {
            var ownerRenderer = renderers[indices[bomb.GetComponentInParent<GameShape>(true)]];
            foreach (var renderer in bomb.GetComponentsInChildren<SpriteRenderer>(true)) if (renderer.GetComponentInParent<GameBomb>(true) == bomb)
            { renderer.sortingLayerID = layerId; renderer.sortingOrder = ownerRenderer.sortingOrder + bomb.SortingOffset; Save(renderer); }
        }
        for (int c = 0; c < clasps.Length; c++)
        {
            var clasp = clasps[c]; clasp.SortingLayer = layerName; clasp.SortingOrder = (int)claspStart+c;
            var renderer = clasp.GetComponent<SpriteRenderer>(); renderer.sortingLayerID = layerId; renderer.sortingOrder = clasp.SortingOrder;
            Save(clasp); Save(renderer); text.AppendLine(clasp.name + "：Order " + clasp.SortingOrder + "（卡扣）");
        }
        text.AppendLine("支持 Undo/Redo；请重新导出关卡资产保存排序。"); source.AnalysisReport = text.ToString(); Save(source);
        Undo.CollapseUndoOperations(group); EditorSceneManager.MarkSceneDirty(source.gameObject.scene); SceneView.RepaintAll();
        return source.AnalysisReport;
    }
    private static void CheckGrouping(Transform element,Transform root)
    {
        for (var t = element; t != null && t != root; t = t.parent)
            if (t.GetComponent<SortingGroup>() != null) throw new ArgumentException(element.name + " 位于独立 SortingGroup 中，请先移除该分组后自动排序。");
    }
    private static void Save(UnityEngine.Object obj)
    { EditorUtility.SetDirty(obj); PrefabUtility.RecordPrefabInstancePropertyModifications(obj); }
}

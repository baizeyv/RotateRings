using UnityEditor;
using UnityEngine;
using WordTile.Game;

[CustomEditor(typeof(GameBomb))]
public sealed class GameBombEditor : Editor
{
    private void OnEnable()
    {
        var bomb = (GameBomb)target;
        if (bomb.Sprite == null) bomb.Sprite = AssetDatabase.LoadAssetAtPath<Sprite>("Assets/tex_boom_01.png");
        bomb.Refresh();
    }
    public override void OnInspectorGUI()
    {
        EditorGUI.BeginChangeCheck(); DrawDefaultInspector();
        var bomb = (GameBomb)target;
        if (EditorGUI.EndChangeCheck()) { bomb.Refresh(); EditorUtility.SetDirty(bomb); }
        if (bomb.Owner == null) EditorGUILayout.HelpBox("请放在 GameShape 子对象上。", MessageType.Error);
        else if (!bomb.Armed && !bomb.Spent) EditorGUILayout.HelpBox("炸弹未启用或尺寸/缩放无效。仅支持正的均匀 XY 缩放。", MessageType.Warning);
        EditorGUILayout.LabelField("状态", bomb.Spent ? "已使用" : "未使用");
        if (GUILayout.Button("刷新外观与碰撞")) bomb.Refresh();
        if (GUILayout.Button("重置炸弹（不激活根对象）")) bomb.ResetBomb();
    }
    [MenuItem("GameObject/Game/所属炸弹", false, 10)]
    private static void Create(MenuCommand command)
    {
        var context = command.context as GameObject;
        var owner = context != null ? context.GetComponentInParent<GameShape>() : null;
        if (owner == null && Selection.activeGameObject != null) owner = Selection.activeGameObject.GetComponentInParent<GameShape>();
        if (owner == null) { Debug.LogWarning("请先选择所属 GameShape。"); return; }
        Add(owner);
    }
    public static void Add(GameShape owner)
    {
        var obj = new GameObject("Bomb"); obj.SetActive(false); obj.transform.SetParent(owner.transform, false);
        var bomb = obj.AddComponent<GameBomb>();
        bomb.Sprite = AssetDatabase.LoadAssetAtPath<Sprite>("Assets/tex_boom_01.png");
        bomb.Refresh(); obj.SetActive(true);
        Undo.RegisterCreatedObjectUndo(obj, "添加所属炸弹"); Selection.activeGameObject = obj;
    }
}

using System;
using System.Collections.Generic;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using WordTile.Game;

[CustomEditor(typeof(GameLevelAuthoring))]
public sealed class GameLevelAuthoringEditor : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector(); var source = (GameLevelAuthoring)target;
        EditorGUILayout.HelpBox("在此根对象下摆放 GameShape 和独立 GameClasp；炸弹放在所属 Shape 下。设计对象默认在 Play 时隐藏，请用单独的关卡加载器加载资产。", MessageType.Info);
        using (new EditorGUI.DisabledScope(Application.isPlaying))
            if (GUILayout.Button("自动排列显示层级"))
            {
                try { source.AnalysisReport = GameLevelSorting.Arrange(source); }
                catch (ArgumentException e) { source.AnalysisReport = "排序失败：" + e.Message; }
                EditorUtility.SetDirty(source);
            }
        if (GUILayout.Button("分析关卡"))
        {
            try { string report; var data = GameLevelExporter.Analyze(source, out report); source.AnalysisReport = report; DestroyImmediate(data); }
            catch (ArgumentException e) { source.AnalysisReport = "错误：" + e.Message; }
            EditorUtility.SetDirty(source);
        }
        if (GUILayout.Button("导出关卡资产"))
        {
            string path = source.Output != null ? AssetDatabase.GetAssetPath(source.Output) : "";
            if (string.IsNullOrEmpty(path)) path = EditorUtility.SaveFilePanelInProject("导出关卡", "GameLevel", "asset", "选择保存位置");
            if (!string.IsNullOrEmpty(path))
            {
                try { GameLevelExporter.Export(source, path); }
                catch (ArgumentException e) { source.AnalysisReport = "错误：" + e.Message; Debug.LogError(source.AnalysisReport, source); }
            }
        }
        if (!string.IsNullOrEmpty(source.AnalysisReport)) EditorGUILayout.TextArea(source.AnalysisReport);
    }
    [MenuItem("GameObject/Game/关卡设计根对象", false, 10)]
    private static void CreateAuthoring()
    {
        var obj = new GameObject("Level Authoring"); obj.AddComponent<GameLevelAuthoring>();
        Undo.RegisterCreatedObjectUndo(obj, "创建关卡设计对象"); Selection.activeGameObject = obj;
    }
    [MenuItem("GameObject/Game/关卡加载器", false, 10)]
    private static void CreateController()
    {
        var obj = new GameObject("Level Controller"); obj.AddComponent<GameLevelController>();
        Undo.RegisterCreatedObjectUndo(obj, "创建关卡加载器"); Selection.activeGameObject = obj;
    }
}

public static class GameLevelExporter
{
    public static GameLevelData Analyze(GameLevelAuthoring source, out string report)
    {
        if (source == null) throw new ArgumentNullException(nameof(source));
        if (source.GetComponentsInChildren<GameLevelAuthoring>(true).Length != 1) throw new ArgumentException("关卡设计根对象不能嵌套。");
        var changes = AssignIds(source);
        var shapes = source.GetComponentsInChildren<GameShape>(true);
        var clasps = source.GetComponentsInChildren<GameClasp>(true);
        var bombs = source.GetComponentsInChildren<GameBomb>(true);
        var data = ScriptableObject.CreateInstance<GameLevelData>();
        try
        {
            data.Shapes = new GameShapeRecord[shapes.Length]; data.Clasps = new GameClaspRecord[clasps.Length]; data.Bombs = new GameBombRecord[bombs.Length];
            var rings = new List<int>(); var others = new List<int>(); var ownedShapes = new HashSet<GameShape>(shapes);
            for (int i = 0; i < shapes.Length; i++)
            {
                var s = shapes[i];
                if (s.transform == source.transform || s.transform.parent.GetComponentInParent<GameShape>(true) != null)
                    throw new ArgumentException("Shape " + s.Id + " 必须为独立物件，不能位于另一个 Shape 下或与关卡根对象共用对象。");
                if (s.MetadataVersion != 1) throw new ArgumentException("Shape " + s.Id + " 缺少连接头元数据，请从 PM JSON 重新烘焙或补充手动配置。");
                var renderer = s.GetComponent<MeshRenderer>();
                data.Shapes[i] = new GameShapeRecord { Id = s.Id, Name = s.name, Type = s.ShapeType, Pose = GameElementPose.Capture(s.transform, source.transform),
                    Active = s.gameObject.activeInHierarchy, Enabled = s.enabled, AllowDrag = s.AllowDrag, BlockMovement = s.BlockMovement,
                    Operation = s.Operation, MovementDirection = s.MovementDirection, CollisionSkin = s.CollisionSkin,
                    Mesh = s.ShapeMesh != null ? s.ShapeMesh : s.GetComponent<MeshFilter>().sharedMesh,
                    Material = s.ShapeMaterial != null ? s.ShapeMaterial : renderer.sharedMaterial, CollectionSprite = s.CollectionSprite,
                    SortingLayerId = renderer.sortingLayerID, SortingOrder = renderer.sortingOrder,
                    CollisionParts = s.CollisionParts == null ? null : (GameCollisionPart[])s.CollisionParts.Clone(), BodyPartCount = s.BodyPartCount,
                    HeadChannels = s.HeadChannels == null ? null : (GameHeadChannel[])s.HeadChannels.Clone() };
                (GameLevelData.IsRing(s.ShapeType) ? rings : others).Add(s.Id);
            }
            for (int c = 0; c < clasps.Length; c++)
            {
                var clasp = clasps[c];
                if (clasp.GetComponentInParent<GameShape>(true) != null) throw new ArgumentException("卡扣 " + clasp.Id + " 必须独立于 Shape，避免跟随移动。");
                data.Clasps[c] = new GameClaspRecord { Id = clasp.Id, Name = clasp.name, Pose = GameElementPose.Capture(clasp.transform, source.transform),
                    Active = clasp.gameObject.activeInHierarchy, Enabled = clasp.enabled, Sprite = clasp.ClaspSprite, Material = clasp.RenderMaterial, Color = clasp.Color,
                    Length = clasp.Length, Width = clasp.Width, ChannelWidth = clasp.ChannelWidth, SortingLayer = clasp.SortingLayer, SortingOrder = clasp.SortingOrder };
            }
            for (int b = 0; b < bombs.Length; b++)
            {
                var bomb = bombs[b]; var owner = bomb.GetComponentInParent<GameShape>(true);
                if (owner == null || !ownedShapes.Contains(owner)) throw new ArgumentException("炸弹 " + bomb.Id + " 没有本关卡的所属 Shape。");
                data.Bombs[b] = new GameBombRecord { Id = bomb.Id, OwnerShapeId = owner.Id, Name = bomb.name, Pose = GameElementPose.Capture(bomb.transform, owner.transform),
                    Active = LocalActive(bomb.transform, owner.transform), Enabled = bomb.enabled, Sprite = bomb.Sprite, ImageWidth = bomb.ImageWidth,
                    Radius = bomb.Radius, CenterOffset = bomb.CenterOffset, SortingOffset = bomb.SortingOffset };
            }
            rings.Sort(); others.Sort(); data.RingShapeIds = rings.ToArray(); data.OtherShapeIds = others.ToArray(); data.Validate();
            for (int i = 0; i < shapes.Length; i++) if (!shapes[i].Initialize()) throw new ArgumentException("Shape " + shapes[i].Id + " 的世界 Transform 无效。");
            for (int c = 0; c < clasps.Length; c++) if (!clasps[c].Refresh()) throw new ArgumentException("卡扣 " + clasps[c].Id + " 的世界 Transform 无效。");
            GameLevelRelations.ValidateInitialGeometry(shapes, clasps);
            var graph = new GameLevelRelations(shapes, clasps); graph.Rebuild();
            data.InitialHeadRelations = graph.CaptureHeads(); data.InitialClaspRelations = graph.CaptureClasps();
            var text = new StringBuilder(changes); text.AppendLine("Shape " + shapes.Length + "，卡扣 " + clasps.Length + "，炸弹 " + bombs.Length);
            int operable = 0;
            for (int i = 0; i < shapes.Length; i++)
            {
                var state = graph.State(i); data.Shapes[i].InitialState = state;
                if (state == GameOperationState.Move || state == GameOperationState.Rotate) operable++;
                text.AppendLine("Shape " + shapes[i].Id + " (" + shapes[i].name + ")：" + StateName(state));
                foreach (var relation in data.InitialHeadRelations) if (relation.OwnerShapeId == shapes[i].Id)
                    text.AppendLine("  连接头 " + (shapes[i].HeadChannels[relation.HeadIndex].ConnectionIndex + 1) + " 被 Shape " + relation.BodyShapeId + " 穿入");
                foreach (var relation in data.InitialClaspRelations) if (relation.ShapeId == shapes[i].Id)
                    text.AppendLine("  穿过固定卡扣 " + relation.ClaspId);
            }
            foreach (var bomb in data.Bombs) text.AppendLine("炸弹 " + bomb.Id + " → Shape " + bomb.OwnerShapeId);
            if (HasCycle(data)) text.AppendLine("警告：存在循环穿入锁定，请检查是否有解锁路径。");
            if (operable == 0) text.AppendLine("警告：开局没有可操作的 Shape。");
            text.AppendLine("收集 Sprite 仅保存引用，不显示或触发收集。");
            report = text.ToString(); return data;
        }
        catch { UnityEngine.Object.DestroyImmediate(data); throw; }
    }
    private static bool LocalActive(Transform child, Transform owner)
    {
        for (var t = child; t != owner; t = t.parent) if (!t.gameObject.activeSelf) return false;
        return true;
    }
    private static string AssignIds(GameLevelAuthoring source)
    {
        var all = source.GetComponentsInChildren<MonoBehaviour>(true); var reserved = new HashSet<int>(); var used = new HashSet<int>();
        foreach (var c in all) { int id = Id(c); if (id > 0) reserved.Add(id); }
        var text = new StringBuilder(); int next = 1;
        foreach (var c in all)
        {
            if (!(c is GameShape) && !(c is GameClasp) && !(c is GameBomb)) continue;
            int old = Id(c); if (old > 0 && used.Add(old)) continue;
            while (reserved.Contains(next)) next++;
            Undo.RecordObject(c, "分配关卡元素 ID");
            if (c is GameShape shape) shape.Id = next; else if (c is GameClasp clasp) clasp.Id = next; else ((GameBomb)c).Id = next;
            used.Add(next); reserved.Add(next); EditorUtility.SetDirty(c); text.AppendLine(c.name + " ID " + old + " → " + next); next++;
        }
        if (text.Length > 0 && !Application.isPlaying && source.gameObject.scene.IsValid()) EditorSceneManager.MarkSceneDirty(source.gameObject.scene);
        return text.ToString();
    }
    private static int Id(MonoBehaviour c)
    { if (c is GameShape s) return s.Id; if (c is GameClasp clasp) return clasp.Id; if (c is GameBomb bomb) return bomb.Id; return 0; }
    private static string StateName(GameOperationState state)
    { return state == GameOperationState.Move ? "可位移" : state == GameOperationState.Rotate ? "可旋转" : state == GameOperationState.HeadLocked ? "连接头锁定" : "未启用"; }
    private static bool HasCycle(GameLevelData data)
    {
        int n = data.Shapes.Length; var edges = new bool[n,n]; var indices = new Dictionary<int,int>();
        for (int i = 0; i < n; i++) indices.Add(data.Shapes[i].Id, i);
        foreach (var relation in data.InitialHeadRelations) edges[indices[relation.OwnerShapeId], indices[relation.BodyShapeId]] = true;
        for (int k = 0; k < n; k++) for (int i = 0; i < n; i++) if (edges[i,k]) for (int j = 0; j < n; j++) edges[i,j] |= edges[k,j];
        for (int i = 0; i < n; i++) if (edges[i,i]) return true;
        return false;
    }
    public static GameLevelData Export(GameLevelAuthoring source, string path)
    {
        if (string.IsNullOrEmpty(path) || !path.StartsWith("Assets/", StringComparison.Ordinal) || !path.EndsWith(".asset", StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("请选择 Assets 下的 .asset 文件。");
        var existing = AssetDatabase.LoadMainAssetAtPath(path);
        if (existing != null && !(existing is GameLevelData)) throw new ArgumentException("目标路径已被其他类型的资源占用。");
        string report; var generated = Analyze(source, out report);
        generated.name = System.IO.Path.GetFileNameWithoutExtension(path);
        try
        {
            foreach (var s in generated.Shapes) { RequireAsset(s.Mesh); RequireAsset(s.Material); if (s.CollectionSprite != null) RequireAsset(s.CollectionSprite); }
            foreach (var c in generated.Clasps) { RequireAsset(c.Sprite); if (c.Material != null) RequireAsset(c.Material); }
            foreach (var b in generated.Bombs) RequireAsset(b.Sprite);
            GameLevelData result;
            if (existing != null) { result = (GameLevelData)existing; Undo.RecordObject(result, "更新关卡资产"); EditorUtility.CopySerialized(generated, result); EditorUtility.SetDirty(result); }
            else { result = UnityEngine.Object.Instantiate(generated); result.name = generated.name; AssetDatabase.CreateAsset(result, path); }
            Undo.RecordObject(source, "设置关卡资产"); source.Output = result; source.AnalysisReport = report; EditorUtility.SetDirty(source);
            if (!Application.isPlaying && source.gameObject.scene.IsValid()) EditorSceneManager.MarkSceneDirty(source.gameObject.scene);
            AssetDatabase.SaveAssets(); return result;
        }
        finally { UnityEngine.Object.DestroyImmediate(generated); }
    }
    private static void RequireAsset(UnityEngine.Object asset)
    { if (!EditorUtility.IsPersistent(asset)) throw new ArgumentException("资源尚未保存为资产：" + asset.name + "。请先导出 PM 资源或保存资源。"); }
}

using System;

namespace WordTile.Game
{
    public enum GameCollisionKind { Ring, Capsule, Box }

    /// <summary>纯数值碰撞核心。Ring 是圆环，不是实心圆。</summary>
    public static class GameCollision2D
    {
        public struct Point
        {
            public double X, Y;
            public Point(double x, double y) { X = x; Y = y; }
            public static Point operator +(Point a, Point b) { return new Point(a.X + b.X, a.Y + b.Y); }
            public static Point operator -(Point a, Point b) { return new Point(a.X - b.X, a.Y - b.Y); }
            public static Point operator *(Point a, double s) { return new Point(a.X * s, a.Y * s); }
        }
        public struct Bounds
        {
            public double MinX, MinY, MaxX, MaxY;
            public bool Overlaps(Bounds b) { return MinX <= b.MaxX && MaxX >= b.MinX && MinY <= b.MaxY && MaxY >= b.MinY; }
            public double GapSquared(Bounds b)
            {
                double x = Math.Max(0, Math.Max(MinX - b.MaxX, b.MinX - MaxX));
                double y = Math.Max(0, Math.Max(MinY - b.MaxY, b.MinY - MaxY));
                return x * x + y * y;
            }
            public void Include(Bounds b)
            {
                MinX = Math.Min(MinX, b.MinX); MinY = Math.Min(MinY, b.MinY);
                MaxX = Math.Max(MaxX, b.MaxX); MaxY = Math.Max(MaxY, b.MaxY);
            }
        }
        public struct Part
        {
            public GameCollisionKind Kind;
            public Point A, B, Axis;
            public double Radius, RingRadius, HalfWidth, HalfHeight;
            public bool RotationInvariant;
            public Bounds Bounds;
            public void UpdateBounds()
            {
                double x, y;
                if (Kind == GameCollisionKind.Capsule)
                {
                    Bounds.MinX = Math.Min(A.X, B.X) - Radius; Bounds.MaxX = Math.Max(A.X, B.X) + Radius;
                    Bounds.MinY = Math.Min(A.Y, B.Y) - Radius; Bounds.MaxY = Math.Max(A.Y, B.Y) + Radius; return;
                }
                if (Kind == GameCollisionKind.Ring) x = y = RingRadius + Radius;
                else { x = Math.Abs(Axis.X) * HalfWidth + Math.Abs(Axis.Y) * HalfHeight; y = Math.Abs(Axis.Y) * HalfWidth + Math.Abs(Axis.X) * HalfHeight; }
                Bounds.MinX = A.X - x; Bounds.MaxX = A.X + x; Bounds.MinY = A.Y - y; Bounds.MaxY = A.Y + y;
            }
        }
        public static double Dot(Point a, Point b) { return a.X * b.X + a.Y * b.Y; }
        private static double Length(Point p) { return Math.Sqrt(Dot(p, p)); }
        private static double Clamp(double v, double min, double max) { return Math.Max(min, Math.Min(max, v)); }
        private static double PointSegmentSquared(Point p, Point a, Point b)
        {
            Point d = b - a; double length = Dot(d, d);
            Point q = p - (a + d * (length > 1e-24 ? Clamp(Dot(p - a, d) / length, 0, 1) : 0)); return Dot(q, q);
        }
        private static double SegmentSquared(Point a, Point b, Point c, Point d)
        {
            Point u = b - a, v = d - c, w = a - c;
            double uu = Dot(u, u), vv = Dot(v, v), uv = Dot(u, v), uw = Dot(u, w), vw = Dot(v, w), s = 0, t = 0;
            if (uu < 1e-24) t = vv > 1e-24 ? Clamp(vw / vv, 0, 1) : 0;
            else if (vv < 1e-24) s = Clamp(-uw / uu, 0, 1);
            else
            {
                double denominator = uu * vv - uv * uv;
                s = denominator > 1e-24 ? Clamp((uv * vw - uw * vv) / denominator, 0, 1) : 0;
                t = (uv * s + vw) / vv;
                if (t < 0) { t = 0; s = Clamp(-uw / uu, 0, 1); }
                else if (t > 1) { t = 1; s = Clamp((uv - uw) / uu, 0, 1); }
            }
            Point gap = w + u * s - v * t; return Dot(gap, gap);
        }
        private static Point BoxLocal(Point p, in Part box)
        {
            p = p - box.A; return new Point(Dot(p, box.Axis), -p.X * box.Axis.Y + p.Y * box.Axis.X);
        }
        private static double PointBoxSquared(Point p, double x, double y)
        {
            double dx = Math.Max(0, Math.Abs(p.X) - x), dy = Math.Max(0, Math.Abs(p.Y) - y); return dx * dx + dy * dy;
        }
        private static double SegmentBoxSquared(Point a, Point b, in Part box)
        {
            a = BoxLocal(a, box); b = BoxLocal(b, box); double x = box.HalfWidth, y = box.HalfHeight;
            if (PointBoxSquared(a, x, y) == 0 || PointBoxSquared(b, x, y) == 0) return 0;
            var p0 = new Point(-x, -y); var p1 = new Point(x, -y); var p2 = new Point(x, y); var p3 = new Point(-x, y);
            return Math.Min(Math.Min(SegmentSquared(a, b, p0, p1), SegmentSquared(a, b, p1, p2)), Math.Min(SegmentSquared(a, b, p2, p3), SegmentSquared(a, b, p3, p0)));
        }
        private static double BoxAxisGap(in Part a, in Part b, Point axis)
        {
            double ra = Math.Abs(Dot(a.Axis, axis)) * a.HalfWidth + Math.Abs(a.Axis.X * axis.Y - a.Axis.Y * axis.X) * a.HalfHeight;
            double rb = Math.Abs(Dot(b.Axis, axis)) * b.HalfWidth + Math.Abs(b.Axis.X * axis.Y - b.Axis.Y * axis.X) * b.HalfHeight;
            return Math.Abs(Dot(b.A - a.A, axis)) - ra - rb;
        }
        public static double Clearance(in Part a, in Part b)
        {
            if (b.Kind == GameCollisionKind.Ring && a.Kind != GameCollisionKind.Ring) return Clearance(b, a);
            if (a.Kind == GameCollisionKind.Ring)
            {
                if (b.Kind == GameCollisionKind.Ring)
                {
                    double centers = Length(a.A - b.A);
                    return Math.Max(0, Math.Max(centers - a.RingRadius - b.RingRadius, Math.Abs(a.RingRadius - b.RingRadius) - centers)) - a.Radius - b.Radius;
                }
                double min, max, radius = a.Radius;
                if (b.Kind == GameCollisionKind.Capsule)
                {
                    min = Math.Sqrt(PointSegmentSquared(a.A, b.A, b.B)); max = Math.Max(Length(a.A - b.A), Length(a.A - b.B)); radius += b.Radius;
                }
                else
                {
                    Point p = BoxLocal(a.A, b); min = Math.Sqrt(PointBoxSquared(p, b.HalfWidth, b.HalfHeight));
                    double x = Math.Abs(p.X) + b.HalfWidth, y = Math.Abs(p.Y) + b.HalfHeight; max = Math.Sqrt(x * x + y * y);
                }
                return Math.Max(0, Math.Max(min - a.RingRadius, a.RingRadius - max)) - radius;
            }
            if (a.Kind == GameCollisionKind.Capsule && b.Kind == GameCollisionKind.Capsule)
                return Math.Sqrt(SegmentSquared(a.A, a.B, b.A, b.B)) - a.Radius - b.Radius;
            if (a.Kind == GameCollisionKind.Box && b.Kind == GameCollisionKind.Box)
                return Math.Max(Math.Max(BoxAxisGap(a, b, a.Axis), BoxAxisGap(a, b, new Point(-a.Axis.Y, a.Axis.X))), Math.Max(BoxAxisGap(a, b, b.Axis), BoxAxisGap(a, b, new Point(-b.Axis.Y, b.Axis.X))));
            if (a.Kind == GameCollisionKind.Box) return Math.Sqrt(SegmentBoxSquared(b.A, b.B, a)) - b.Radius;
            return Math.Sqrt(SegmentBoxSquared(a.A, a.B, b)) - a.Radius;
        }
        /// <summary>Circle against a capsule, box or hollow ring: world contact on the other surface.</summary>
        public static Point CircleContact(in Part circle, in Part other)
        {
            Point center = circle.A, closest;
            if (other.Kind == GameCollisionKind.Box)
            {
                Point p = BoxLocal(center, other);
                closest = other.A + other.Axis * Clamp(p.X, -other.HalfWidth, other.HalfWidth) +
                    new Point(-other.Axis.Y, other.Axis.X) * Clamp(p.Y, -other.HalfHeight, other.HalfHeight);
                return closest;
            }
            if (other.Kind == GameCollisionKind.Ring)
            {
                Point d = center - other.A; double length = Length(d);
                double radius = other.RingRadius + (length < other.RingRadius ? -other.Radius : other.Radius);
                return other.A + (length > 1e-12 ? d * (radius / length) : new Point(radius, 0));
            }
            Point axis = other.B - other.A; double squared = Dot(axis, axis);
            closest = other.A + axis * (squared > 1e-24 ? Clamp(Dot(center - other.A, axis) / squared, 0, 1) : 0);
            Point direction = center - closest; double distance = Length(direction);
            return closest + (distance > 1e-12 ? direction * (other.Radius / distance) : new Point(other.Radius, 0));
        }
        /// <summary>Closest surface point on the obstacle; approximate for general curved pairs.</summary>
        public static Point ContactPoint(in Part moving, in Part obstacle)
        {
            var probe = new Part { Kind = GameCollisionKind.Capsule, A = moving.A };
            Point point = moving.A;
            for (int i = 0; i < 16; i++)
            {
                probe.A = point; point = CircleContact(probe, obstacle);
                probe.A = point; point = CircleContact(probe, moving);
            }
            probe.A = point; return CircleContact(probe, obstacle);
        }
        public static Part Transform(Part part, double x, double y, double cosine, double sine, double scale)
        {
            double ax = part.A.X, ay = part.A.Y, bx = part.B.X, by = part.B.Y, ux = part.Axis.X, uy = part.Axis.Y;
            part.A = new Point(x + scale * (cosine * ax - sine * ay), y + scale * (sine * ax + cosine * ay));
            part.B = new Point(x + scale * (cosine * bx - sine * by), y + scale * (sine * bx + cosine * by));
            part.Axis = new Point(cosine * ux - sine * uy, sine * ux + cosine * uy);
            part.Radius *= scale; part.RingRadius *= scale; part.HalfWidth *= scale; part.HalfHeight *= scale;
            part.UpdateBounds(); return part;
        }
        /// <summary>局部 X 是通道方向，Y 是总宽度方向。无数组或引用对象分配。</summary>
        public static bool TryClaspRails(double length, double width, double channelWidth, out Part lower, out Part upper)
        {
            lower = upper = default(Part);
            if (double.IsNaN(length) || double.IsInfinity(length) || double.IsNaN(width) || double.IsInfinity(width) ||
                double.IsNaN(channelWidth) || double.IsInfinity(channelWidth) || length <= 0 || channelWidth <= 0 || width <= channelWidth) return false;
            double halfRail = (width - channelWidth) / 4, offset = (width + channelWidth) / 4;
            lower = new Part { Kind = GameCollisionKind.Box, A = new Point(0, -offset), Axis = new Point(1, 0), HalfWidth = length / 2, HalfHeight = halfRail };
            upper = lower; upper.A.Y = offset;
            lower.UpdateBounds(); upper.UpdateBounds(); return true;
        }
        public static double Advance(double fraction, double clearance, double travel, double skin)
        {
            return Math.Min(1, fraction + Math.Max(skin * 0.25, (clearance - skin) * 0.9) / travel);
        }
        /// <summary>First entry into the contact band under translation, including hollow-ring exits.</summary>
        public static double SweepTranslation(in Part a, in Part b, Point motion, double skin)
        {
            double start = Clearance(a, b);
            if (start < -skin) return 0;
            double threshold = Math.Min(skin, start) - 1e-10;
            if (start - threshold >= Length(motion)) return 1;
            if (a.Kind == GameCollisionKind.Box && b.Kind == GameCollisionKind.Box)
            {
                double enter = 0, exit = 1;
                if (!SweepAxis(a, b, motion, a.Axis, threshold, ref enter, ref exit) ||
                    !SweepAxis(a, b, motion, new Point(-a.Axis.Y, a.Axis.X), threshold, ref enter, ref exit) ||
                    !SweepAxis(a, b, motion, b.Axis, threshold, ref enter, ref exit) ||
                    !SweepAxis(a, b, motion, new Point(-b.Axis.Y, b.Axis.X), threshold, ref enter, ref exit)) return 1;
                return enter < exit ? enter : 1;
            }
            // Exterior distance to a convex core is convex along a line. Within a ring hole,
            // the contained body's maximum radius is convex, so the safe interval ends once.
            bool inside = false;
            if (a.Kind == GameCollisionKind.Ring || b.Kind == GameCollisionKind.Ring)
            {
                var ring = a.Kind == GameCollisionKind.Ring ? a : b;
                var body = a.Kind == GameCollisionKind.Ring ? b : a;
                inside = body.Kind == GameCollisionKind.Ring ? Length(ring.A - body.A) < Math.Abs(ring.RingRadius - body.RingRadius) :
                    RingMaximum(ring, body) < ring.RingRadius;
            }
            double lo = 0, hi = 1;
            if (inside)
            {
                if (TranslationGap(a, b, motion, 1, true) >= threshold) return 1;
            }
            else
            {
                // Bracket the global minimum rather than taking skin-sized movement steps.
                const double ratio = 0.6180339887498948482;
                double left = 0, right = 1, x = right - ratio, y = ratio;
                double gx = TranslationGap(a, b, motion, x, false), gy = TranslationGap(a, b, motion, y, false);
                for (int i = 0; i < 48; i++)
                {
                    if (gx < gy) { right = y; y = x; gy = gx; x = right - ratio * (right - left); gx = TranslationGap(a, b, motion, x, false); }
                    else { left = x; x = y; gx = gy; y = left + ratio * (right - left); gy = TranslationGap(a, b, motion, y, false); }
                }
                hi = gx < gy ? x : y;
                if (Math.Min(gx, gy) >= threshold) return 1;
            }
            for (int i = 0; i < 48; i++)
            {
                double mid = (lo + hi) * 0.5;
                if (TranslationGap(a, b, motion, mid, inside) < threshold) hi = mid; else lo = mid;
            }
            return lo;
        }
        private static bool SweepAxis(in Part a, in Part b, Point motion, Point axis, double skin, ref double enter, ref double exit)
        {
            double center = Dot(a.A - b.A, axis), speed = Dot(motion, axis);
            double extent = -BoxAxisGap(a, b, axis) + Math.Abs(center) + skin;
            if (Math.Abs(speed) < 1e-20) return Math.Abs(center) < extent;
            double t0 = (-extent - center) / speed, t1 = (extent - center) / speed;
            enter = Math.Max(enter, Math.Min(t0, t1)); exit = Math.Min(exit, Math.Max(t0, t1));
            return enter < exit;
        }
        private static double RingMaximum(in Part ring, in Part body)
        {
            if (body.Kind == GameCollisionKind.Capsule) return Math.Max(Length(ring.A - body.A), Length(ring.A - body.B));
            Point p = BoxLocal(ring.A, body);
            return Length(new Point(Math.Abs(p.X) + body.HalfWidth, Math.Abs(p.Y) + body.HalfHeight));
        }
        private static double TranslationGap(Part a, in Part b, Point motion, double t, bool inside)
        {
            a.A = a.A + motion * t; a.B = a.B + motion * t;
            if (a.Kind != GameCollisionKind.Ring && b.Kind != GameCollisionKind.Ring) return Clearance(a, b);
            var ring = a.Kind == GameCollisionKind.Ring ? a : b;
            var body = a.Kind == GameCollisionKind.Ring ? b : a;
            if (body.Kind == GameCollisionKind.Ring)
                return (inside ? Math.Abs(ring.RingRadius - body.RingRadius) - Length(ring.A - body.A) :
                    Length(ring.A - body.A) - ring.RingRadius - body.RingRadius) - ring.Radius - body.Radius;
            double radius = ring.Radius + (body.Kind == GameCollisionKind.Capsule ? body.Radius : 0);
            if (inside) return ring.RingRadius - RingMaximum(ring, body) - radius;
            double minimum = body.Kind == GameCollisionKind.Capsule ? Math.Sqrt(PointSegmentSquared(ring.A, body.A, body.B)) :
                Math.Sqrt(PointBoxSquared(BoxLocal(ring.A, body), body.HalfWidth, body.HalfHeight));
            return minimum - ring.RingRadius - radius;
        }
    }
}


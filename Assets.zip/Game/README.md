# GameShape：移动 / 旋转操作与阻挡

目标：Android 6.0+，约 100 个 Shape。运行时不依赖 PM/RotateRings、Physics2D、Jobs 或 Burst。单个 GameShapeInput 统一处理触摸/鼠标，GameShape 本身没有 Update。暂不包含连接头通行或关卡玩法。

## 接入

给 Mesh 对象添加 GameShape。指定同一次 PM 导出的 Mesh、材质、JSON，点击「从 PM JSON 烘焙碰撞并应用资源」，再保存 Prefab。完整圆环烘焙成一个解析 Ring；直线/曲线使用 Capsule；连接杆使用实心 Box。开启通行的连接头烘焙为两个 Box 轨道，中间留空；关闭通行的头仍为实心 Box。编辑器读取已有 PM 参数/路径定义，运行时只使用烘焙后的 Collision Parts，不解析 JSON、不重建 Mesh。

也可直接手动填写 Collision Parts，再点击「应用手动 Collision Parts」。Scene 开启 Gizmos 并选中对象查看轮廓。本体绿色，矩形黄色。仅支持 XY 平面、正的均匀缩放。

## 拖动操作

重新烘焙 JSON 会自动设置 Operation：圆环 / C 环为 Rotate（绕对象中心旋转），直线 / 门形 / 7 / Z 为 Translate。位移类的 Movement Direction 是世界坐标移动轴，默认 `(1,0)` 左右，设为 `(0,1)` 上下，也支持斜向。不随对象自身旋转。手工碰撞对象直接设置 Operation；关闭 Allow Drag 可禁止指针操作。

运行时第一个允许拖动的 Shape 会自动创建一个跨场景的 GameShapeInput。也可提前在场景中放置一个 GameShapeInput 并指定 Input Camera；默认使用 MainCamera。保留项目当前旧 Input API，Android 使用单指，编辑器使用鼠标左键。

只有按下时拾取一次对象，按 MeshRenderer 的 Sorting Layer / Order 选择上层对象；圆环内孔不会被拾取。按在 UI 上不开始拖动。捕获后始终跟随同一手指，不因第二根手指切换或重复处理模拟鼠标。释放、触摸取消、应用失焦/暂停、对象禁用会结束操作。指针经过旋转中心时使用死区避免角度跳变。

拖动始终经过下方的阻挡接口。每次记录实际指针位置，碰撞截断后丢弃剩余请求，反向拖动可立即退出。输入循环不使用 Input.touches、LINQ 或临时集合；每帧只操作捕获的 Shape。

```csharp
float fraction = shape.RequestMovement(worldDisplacement);
float fraction = shape.RequestRotation(deltaDegrees);
float fraction = shape.RequestMotion(worldDisplacement, deltaDegrees);
```

返回实际执行比例，1 完整执行，0 未执行。需要碰撞约束的位移/旋转都须经过这些接口；直接改 Transform 属于瞬移，不做路径阻挡。允许从安全接触位置反向退出；初始深度穿插停止运动，请修正关卡摆放。关闭 Block Movement 后对象不参与阻挡。LastObstacle、LastSweepIterations、LastPairChecks 用于定位开销。

## 连接头通道

在 PM 工作台选中每个连接点，开启「连接头中间允许物件穿过」并设置「连接头净通道宽度」（px）。净宽须小于连接头厚度；0 表示自动取厚度的 60%，也用于兼容缺少 HeadChannelWidth 字段的旧 JSON。新建连接点默认头厚度 40 px、净通道宽度 24 px。

PM 预览默认开启「预览头通道」：蓝色半透明区域及边框表示净通道，金色边框表示两侧轨道，选中连接点显示实际净宽 px。标记随物件移动/旋转，并使用上一次成功应用的参数；关闭自动应用时点击「应用当前参数」后更新。此标记仅用于玩法预览，不写入导出 Mesh 或材质。

通道沿连接头横向贯通，两侧轨道随所属 Shape 一起移动/旋转。连接杆保持实心；Show Head 关闭时不生成头轨道。Game 按真实几何判定宽度、角度和曲率是否能穿过，旧 PassageAngleDegrees 仅保留给旧 RotateRings 演示使用，Game 不使用角度豁免。

修改后重新导出 JSON，并在 GameShape 中重新烘焙、保存 Prefab。显示 Mesh 不因净通道宽度改变而重建；Scene 中的碰撞预览会显示实际两条轨道。连接头阻挡报告 LastObstacle 为所属 Shape，LastClaspObstacle 为 null。

## 独立固定卡扣

通过 `GameObject > Game > 固定卡扣` 创建独立对象（默认使用现有 RingClasp_C 图），或给空对象添加 GameClasp 并指定 Clasp Sprite。卡扣不作为 Shape 子对象，也不绑定 Shape。局部 X 是通道，Length 是沿通道长度，Width 是总宽度，Channel Width 是净通道宽度；旋转卡扣可调整方向。尺寸或外观修改后调用 Refresh()，Inspector 修改会自动刷新。

两条矩形轨道是实心障碍，中间留空。Shape 的 Movement Direction 保持原配置；直段宽度小于通道且保留 Collision Skin 余量时可滑过，连接头、圆角、过粗本体或方向错位由实际几何阻挡。所有启用 Block Movement 的 Shape 都参与，无需配置所属关系。卡扣不接受拖动，也不会在物件完全退出后自动消失；禁用或删除对象移除障碍。

选中卡扣并开启 Gizmos，可看到青色轨道轮廓和绿色通道方向。非法尺寸或不支持的 Transform 不使用旧碰撞数据；Inspector 显示 Error。仅支持 XY 平面及正的均匀缩放。

卡扣阻挡时 `LastObstacle == null`、`LastClaspObstacle` 指向卡扣，原 `CollisionBlocked` 事件参数为 null；Shape 阻挡时反之，完整运动执行后两个属性均清空。每个卡扣只缓存两个矩形，无运行时 Update；运动请求中只在配置或 Transform 改变时更新轮廓。

## 性能与精度

- 完整圆环无分段，环心保持空洞；解析计算圆环与圆环/胶囊/矩形间距。
- 对象和碰撞件两级 AABB 筛选；世界碰撞数据只在 Transform 改变时更新。
- 初始化时建立值类型数组和 128 容量的候选列表；约 100 个对象的常规运动请求不创建数组、闭包、LINQ 或临时引用对象。用户事件回调的分配由调用方负责。
- 连续运动采用间距驱动的保守推进，同时处理位移和旋转，不只检测终点。最多 64 次；达到上限停在已验证位置，可能只执行部分请求。盒盒距离使用 SAT 的保守下界。
- 曲线只在编辑器采样，并扩大胶囊半径补偿弦高误差；精度与件数取舍可调整烘焙分段上限。完整圆环不受此设置影响。
- 每次请求扫描约 100 个对象的包围盒，不做复杂空间索引。若对象数明显增加再根据真机 Profiler 升级。

Tools/Test-GameCollision.ps1 可独立执行碰撞、卡扣和拖动数值检查、电脑基准与玩家/编辑器编译。Tools/GameShapeChecks.cs 在 Play 模式检查实际组件的拾取、拖动、独立卡扣阻挡、事件报告、禁用/删除和稳定分配。

已在独立 Unity 2022.3 项目中通过 Play 模式集成检查。桌面 Unity Mono 测量：100 个静止 Shape 加一个通道中的移动对象，10,000 次运动请求累计约 350.53 ms，测得托管分配 0 字节；这是该测试场景的电脑结果，不代表 Android 真机。Android 主线程耗时、GC.Alloc 与 IL2CPP 表现仍须在目标设备验证。此次不修改现有发布配置。



## 所属炸弹

选择 GameShape，在 Inspector 点击「添加所属炸弹」，或使用 `GameObject > Game > 所属炸弹`。GameBomb 自动归属最近的父级 GameShape，默认使用 `Assets/tex_boom_01.png`；图片宽 0.5、圆形半径 0.2、中心偏移 (0,-0.05)，排序层继承 Shape、顺序 +5。独立 Bomb Visual 子对象只负责图片，Image Width 不改变碰撞尺寸。选中炸弹可预览红色圆形。

炸弹圆形随所属 Shape 移动/旋转，也可用于拾取所属 Shape。同属本体、连接件和炸弹互不触发；不同 Shape 的本体/连接件接触炸弹，或双方炸弹互撞，均使用连续检测，关闭 Block Movement 仍会触发。普通障碍更早接触时截断运动，不引爆后方炸弹；固定卡扣只作阻挡。

触发时先标记 Spent，再通知 `Exploded(GameBomb bomb, GameShape other, Vector3 point)`，最后隐藏双方 GameShape 的整个根对象并立即结束拖动。point 为世界空间接触点；事件异常会记录日志，双方仍会隐藏。炸弹互撞锁定双方状态并分别通知，不增加范围或连锁反应；同时接触按注册顺序选择一对。物件通过 SetActive(false) 隐藏，未 Destroy。

初始化 Start 检查重叠。常规运动使用 RequestMovement/RequestRotation/RequestMotion；直接改 Transform、重新布置关卡后可显式调用 `GameShape.CheckBombContacts()`。`ResetBomb()` 恢复未使用状态，根对象激活由关卡负责；激活后再次调用 CheckBombContacts 检查新布局。尺寸或外观配置后可调用 Refresh，Inspector 自动刷新；局部位置、半径、禁用、删除或换父级会更新碰撞缓存。不支持非法半径及非均匀 XY 缩放，不保留旧圆形。无每炸弹 Update 或 Physics2D Collider。

Tools/GameBombChecks.cs 已在隔离 Unity 2022.3 Play 模式检查自身忽略、高速移动/旋转、圆环空洞、炸弹互撞、普通障碍优先、Block Movement 关闭、同时接触、重置、初始重叠、禁用/删除/换父级、均匀缩放、视觉尺寸独立、拖动取消和异常回调。100 个 Shape、99 颗炸弹，10,000 次稳定混合位移/旋转请求测得托管分配 0 字节，桌面 Unity Mono 总耗时约 1,200–1,440 ms。该场景的电脑耗时不代表 Android 真机；Android 6.0+ 主线程耗时及 IL2CPP/GC.Alloc 须单独验证。

## 关卡设计与加载

1. 使用 `GameObject > Game > 关卡设计根对象` 创建 GameLevelAuthoring，在其下摆放独立 GameShape 与 GameClasp；可用空对象分组，但 Shape 不嵌套，卡扣不放在 Shape 下。炸弹放在所属 Shape 下，识别最近的父级 Shape。
2. 现有 Shape 从 PM JSON **重新烘焙一次**，补齐 Shape Type、Body Part Count 和 Head Channels。纯手动 Shape 必须明确填写类型、本体件数量和开放连接头净通道，再点击「应用手动 Collision Parts」。缺失元数据不会按 Mesh 或对象名字猜测。
3. 点击根对象 Inspector 的「分析关卡」，自动分配或修复 ID；保留第一个有效 ID，复制产生的重复项获得新 ID，并显示变更记录。Shape、卡扣、炸弹共用关卡内唯一的正整数 ID。之后再次分析不改变有效 ID。
4. 报告显示每个 Shape 的初始状态、连接头对应的穿入者 ID、固定卡扣关联，以及炸弹归属。点击「导出关卡资产」保存 GameLevelData；再次导出到同一资产保留其 GUID。Mesh、材质及 Sprite 必须已保存为 Unity 资源；非法尺寸、缺少资源、嵌套 Shape、绑定在 Shape 下的卡扣、无所属炸弹或初始实心轮廓重叠会阻止导出。循环锁定、开局无可操作 Shape 只显示警告，不进行关卡求解。
5. 使用 `GameObject > Game > 关卡加载器` 创建独立 GameLevelController，指定 Data。默认 Start 加载；也可关闭 Load On Start，显式调用 `Load(data)`、`Unload()` 或 `TryGetShape(id, out shape)`。设计根对象默认在 Play 时隐藏，避免设计对象与加载后的实例同时参与碰撞。加载器不要放在设计根对象下。

关卡资产保存根对象坐标系下的布局、初始启用状态、操作配置、排序、本体/连接件碰撞、开放连接头通道、卡扣、炸弹相对 Owner 的布局和资源引用。运行时直接建立 Game 元素，Mesh/材质/Sprite 共享，不生成 Mesh、不读 PM JSON；每个实例拥有独立配置数组。加载器的 Transform 可平移、在 XY 平面旋转或均匀缩放，但 **Movement Direction 仍是原配置的世界轴**。

RingShapeIds 包含 Circle 与 CShape，OtherShapeIds 包含 Gate、Seven、ZShape、Straight；两组按 ID 排序并覆盖全部 Shape，分类不随 Operation 改变。圆环的 Collection Sprite 可为空，只保存引用，不创建视觉子对象或触发收集。

## 穿入锁定与更新

其他 Shape 的本体进入某个开放连接头净通道内部，即锁住该连接头的 Owner；不要求贯穿两端。关系有方向：A 的头被 B 穿入，只锁 A，B 根据自身连接头判断。自身本体、其他物件的连接杆/连接头和炸弹不计入穿入者；圆环内孔、入口附近或恰好擦碰通道边界不算穿入。使用现有解析圆环、烘焙胶囊和矩形轮廓，排除不超过 0.00001 世界单位的边界浮点误差。

任意头仍有穿入者就保持锁定，全部退出后立即解锁。GameShape.IsHeadLocked、CanOperate 和 OperationState 提供当前状态；状态包括 Move（可位移）、Rotate（可旋转）、HeadLocked（连接头锁定）、Disabled（未启用/不允许拖动）。普通碰撞可能限制运动，不将其当作连接头锁定。锁定时拖动立即取消，RequestMovement/RequestRotation/RequestMotion 返回 0；不改 AllowDrag、Operation 或 Movement Direction。

固定卡扣保持独立且固定，仅记录哪些 Shape 本体进入通道，不产生逻辑锁定。`controller.Relations.HeadOccupied(ownerIndex, headIndex, bodyIndex)`、`ClaspOccupied(claspIndex, shapeIndex)` 可查询关系，`LockCount(shapeIndex)` 查询占用的头/本体关系数量。索引对应 controller.Shapes/Clasps 和 Shape.HeadChannels；需要 ID 时用元素.Id。`StateChanged` 在状态变化后通知，炸弹双方完整隐藏后才统一发布。

成功运动只更新移动者的头对其他本体、其他头对移动者本体，以及移动者的卡扣关联；禁用、隐藏或删除也会立即更新。卡扣 Refresh/禁用只更新该卡扣关联。直接改 Transform、重置布局或重新启用后可调用 `controller.RefreshRelations()`；修改碰撞配置或通道参数后先调用对应 Shape.Initialize()。没有逐帧 Transform 扫描，也没有逐帧全量关系重建。开局先处理炸弹重叠，再按实际存活对象建立关系；资产中的 InitialState/InitialHeadRelations/InitialClaspRelations 是设计快照，运行时重新计算。

Tools/GameLevelChecks.cs 在隔离 Unity 2022.3 Play 中验证 PM 元数据、重复 ID 修复和稳定性、导出加载往返、资源/配置共享边界、归属、部分穿入/完全退出、边界与空洞排除、连接件/炸弹排除、多穿入者、双向循环锁定、禁用/删除、炸弹隐藏事务及导出错误/警告。100 个 Shape、100 个连接头，10,000 次混合位移/旋转及增量关系更新测得托管分配 0 字节；桌面 Unity Mono 此测试累计约 402 ms，不代表 Android。Android 6.0+ 真机 CPU/GC.Alloc 与 IL2CPP 表现仍需单独验证。

## 可运行的关卡测试场景

打开 `Assets/Game/Scenes/GameLevelTest.unity`，或菜单 `Tools > Game > 打开关卡测试场景`，点击 Play。建议使用横屏 Game View；场景顶部显示 Shape ID 与当前状态，右上角 Reset level 恢复初始布局。使用鼠标或单指拖动。

- 左上：粉色圆环 #1 的开放连接头被蓝色直线 #2 穿入，#1 开局 HeadLocked。将 #2 向上拖出，#1 立即解锁并可旋转。
- 右上：青色 C 环 #3 可直接旋转；灰色 #4 设置 Allow Drag=false，用于检查 Disabled 状态。
- 左下：绿色 #5 的直段穿过固定卡扣 #101，向左拖时右端粗头受阻，反向向右可退出；卡扣始终固定。
- 右下：#201 炸弹归属金色 #6，金色条在此示例关闭拖动。将橙色 #7 向左拖到炸弹，#6、#7 的完整根对象一起隐藏。

场景保留可编辑的 Level Design 根对象，并引用 `Assets/Game/TestLevelAssets/GameLevelTest.asset`；Play 时设计对象隐藏，由独立 Level Controller 加载数据。资源目录下的 Mesh/材质是编辑器生成的测试资源，显示实际碰撞轮廓（连接头中心留空）；运行时不生成 Mesh。源物件使用显式类型、本体范围和烘焙通道元数据。修改布局后，在设计根对象上重新分析和导出。菜单「重建关卡测试场景」会覆盖此测试场景及对应测试资源。

Tools/GameLevelSceneChecks.cs 已在隔离 Unity 2022.3 图形 Play 环境验证该实际场景的加载、初始状态、指针拖动解锁、C 环旋转、固定卡扣粗头阻挡/反向退出、炸弹隐藏和重新加载恢复，并检查截图显示。GameLevelTestPanel 是测试专用 IMGUI 状态/重置面板；测量碰撞与关系更新核心时可禁用它，避免把调试 GUI 的开销算入核心。

## 编辑器连接头自动对齐

选择连接头所属 GameShape，在 Inspector 点击「保持角度对齐到我的连接头」或「旋转并对齐到我的连接头」，或在 Scene 中点击开放连接头中心的青色圆点。也可从 `Tools > Game > 连接头自动对齐` 打开工具。

1. 在工具中选择目标连接头；列表按原连接点编号显示并标明净宽，Scene 显示青色净通道轮廓。
2. 将要穿入的场景 Shape 拖入「待放 Shape」；也可以在 Hierarchy/Scene 选中它后点击「用当前选择作为待放 Shape」。
3. 默认自动选最近的可放入本体段；门/7/Z/C 等多段物件也可以手动指定本体段。点击「对齐并放入连接头」。支持 Undo/Redo，并保存 Prefab 实例 Transform 覆盖。

工具仅用于编辑模式，只改整个待放 Shape 的世界位置和旋转，保持尺寸、父级、ID、操作类型、位移轴及所属炸弹关系。直段将中点沿通道方向居中；完整圆环使用最近弧点与切线，C 环使用实际烘焙本体段，不把圆心或缺口当成环身。默认「保持当前角度，只移动」，也可在「角度处理」中选择「旋转并沿通道对齐」。保持角度模式只设置位置，不重新写入旋转，因此父级下的局部旋转也保持不变；完整圆环选择切线适合通道的弧点，不旋转整个物件。若需要沿通道拖出，Movement Direction 仍需按原规则配置。

应用前使用同一数值碰撞核心检查本体厚度、安全间距以及整个 Shape（包含连接件和已启用炸弹）对目标、其他阻挡 Shape、固定卡扣的实体轮廓。过粗、曲率不合适或有实体冲突时显示原因并保持原布局，不自动缩放或绑定对象；预览不修改场景。两个物件必须位于同一个关卡设计根对象下，并已有本体/连接头元数据。工具在一次求解中缓存障碍轮廓、先用包围盒筛选；全部代码在 Editor 文件夹，不进入 Android 玩家或运动循环。

对齐后在关卡设计根对象重新「分析关卡」和「导出关卡资产」，Play 才会使用更新后的布局。Tools/GameShapeAlignmentChecks.cs 已在隔离 Unity 2022.3 编辑器验证测试场景真实放入与穿入识别、预览不修改、撤销/重做、保持轴/尺寸/父级、多头多段选择、圆/C 切线、变换父级及过粗/弯曲/第三方物件/炸弹冲突拒绝。

固定卡扣也支持同样的两种模式：选中 GameClasp，点击「保持角度对齐到此卡扣」或「旋转并对齐到此卡扣」，或点击 Scene 中卡扣中心的青色圆点。菜单 `Tools > Game > 固定卡扣自动对齐` 可直接打开。通道方向取卡扣局部 X；只移动待放 Shape，不移动/旋转卡扣，不修改尺寸、父级或位移轴，也不绑定 Owner。

卡扣对齐仅接受 Gate、Seven、ZShape、Straight，明确拒绝 Circle、CShape 和未确定类型。连接头对齐对所有 Shape 类型开放；是否能放入仍取决于净宽、曲率、当前方向及完整实体轮廓。保持角度模式放不进去时提示失败，不偷偷旋转物件；卡扣自身轨道始终参与目标适配检查，即使待放 Shape 关闭普通 Block Movement。

## 自动排列显示层级

GameLevelAuthoring Inspector 的「自动排列显示层级」按当前连接头穿入关系设置 Renderer 的 Sorting Layer / Order，包含多层依赖：B 的本体穿入 A 的连接头，B 在 A 下方；若 C 同时穿入 B，得到 C < B < A。多个连接头重复产生同一关系时只计算一次，不会重复增加依赖。没有上下层约束的物件尽量保持原有显示顺序，同优先级按场景层级顺序稳定排列。

为让 Sorting Order 能跨不同物件统一比较，所有 Shape、所属炸弹和固定卡扣统一使用第一个 Shape 的 Sorting Layer（结果报告显示层名）。炸弹保留 Sorting Offset，并为每个 Shape 预留偏移空间；卡扣的配置与 SpriteRenderer 均设置到全部 Shape/炸弹上方。位置、旋转、尺寸、父子层级和操作配置不变。该功能只在编辑器按钮点击时执行，不增加运行时扫描。

排序支持 Undo/Redo、Prefab 实例覆盖；点击后重新「导出关卡资产」让加载器使用新排序。缺失元数据、排序值超出范围或有独立 SortingGroup 时会提示修复。若穿入关系形成循环，上下层要求无法同时成立，会列出需要检查的物件并保持原显示排序，不强行分配。关卡根对象上的共同 SortingGroup 可保留。

Tools/GameLevelSortingChecks.cs 已通过 Unity 2022.3 编辑器检查：实际测试场景、连接头所属 Shape 在穿入者上方、卡扣高于 Shape 和炸弹、炸弹偏移保留、重复排序稳定、Undo/Redo、导出与加载排序一致、多头去重、多层依赖及循环/缺失元数据失败不部分修改排序。

## 松手清理与关卡完成

GameShapeInput 的正常鼠标/触摸松手（EndDrag）调用关卡 ReleaseShape。没有连接头或卡扣关联的 Shape 隐藏整个根对象，所属炸弹随之隐藏。依赖检查包括自己的连接头内有其他本体、自己的本体穿入其他连接头、自己的本体进入卡扣；不改变位移轴或操作配置。拖动开始及过程中缓存曾关联的邻居，松手时继续隐藏其中已独立的 Shape 和已无穿入者的卡扣；仍有其他穿入者的连接头所属 Shape / 卡扣保留。不全场清理原本无关的独立物件。

CancelDrag 用于触摸取消、失去焦点、禁用、炸弹隐藏或操作被锁定等情况，只结束捕获，不执行松手清理。自定义输入先调用 GameLevelController.BeginOperation(shape)，运动仍用 Request 接口，正常结束调用 ReleaseShape(shape)，取消调用 CancelOperation()。直接改 Transform 后仍需 RefreshRelations()。

关卡内所有 Shape、卡扣和炸弹对象都已不在场上时，IsCompleted 置为 true，Console 输出「关卡所有物品已消失。」，并触发一次 LevelCompleted 事件。炸弹双方隐藏批次完成后才判断；Load / Unload 重置完成状态。禁用操作但仍显示的物件仍计入场上物品。候选标记在加载时分配，运动与松手复用缓冲；不增加 Update 或全场每帧扫描。完成日志、UI 和用户回调不属于零分配数值核心。
Tools/GameLevelSceneChecks.cs 已在隔离 Unity 2022.3 Play 模式验证：关联未解除时保留、取消不隐藏、退出连接头后双方隐藏、空卡扣消失、多个穿入者保留所属 Shape / 卡扣、无关物件保留、完成通知只触发一次及重新加载重置；连续 10,000 次仍有关联的开始/松手操作测得 0 托管字节。Android 真机耗时仍需设备验证。

## 接触后的纯位移滑动

RequestMovement / degrees 为 0 的 RequestMotion 使用逐几何对的连续位移检测。Box/Box 用连续 SAT 区间；Capsule 与圆环外侧的凸距离用有界最小值求解定位接触区间，再二分最早进入时间；位于圆环内孔时按内部安全区间求首次退出。沿接触面滑动或远离时不再按 CollisionSkin 的微小步长反复推进；途中出现拐角或其他障碍仍取最早接触。C 环沿用烘焙胶囊段，卡扣使用相同的矩形轨道检测。保留原 CollisionSkin，不推动其他物件；旋转/混合请求仍走原连续推进路径。

GameShape.MeasureMotionTiming 默认关闭；开启后可读取 LastCollisionTicks、LastRelationTicks、LastBlockedCallbackTicks，秒数为 ticks / System.Diagnostics.Stopwatch.Frequency。LastPairChecks 统计几何对调用，纯位移 LastSweepIterations 为 0；这些接口不自动输出日志。用于区分几何计算、关卡关系更新和外部 CollisionBlocked 回调耗时。诊断字段不需要重新烘焙或重新导出关卡。

Tools/GameCollisionChecks.cs 覆盖全部几何组合的高速接触、对称性、反向退出、内孔、切向滑动，并保留旧推进算法作比较。桌面 Mono 的矩形贴边 10000 次：旧方法约 190 ms、平均执行 8% 位移，新方法约 4 ms、执行 100%，0 托管分配。隔离 Unity Play 的 100+ Shape 场景中 A 垂直接触 B 后，B 连续 10000 次水平滑动均完整执行，0 托管分配，约 334 ms（包含运行时候选扫描及诊断计时）。炸弹、连接头、卡扣、100 Shape 关系更新回归均通过。以上是桌面测试，不替代 Android 6.0+ 真机耗时。

## 关联组整体套入

GameShape Inspector 新增「将当前 Shape 和关联组整体套入其他通道」。打开窗口后选择组外 Shape 的连接头或固定卡扣，再选择当前 Shape 的本体段。默认保持角度只移动，也可选择旋转并沿通道对齐。窗口显示所有随行成员及场景位移预览。

随行范围是当前 Shape 所在的整个连接头关联组，按两个方向递归查找：既包含自己连接头内的穿入者，也包含自己的本体穿入的其他 Shape；多层、双向与循环关联每个成员只移动一次。固定卡扣不参与关联组，炸弹随所属 Shape 的子层级移动。目标不能位于关联组中。卡扣只限制实际套入的当前 Shape 为非环类，组中的其他成员可包含环。

整组作同一平移/旋转，保持相对布局、尺寸、父子关系、ID、位移轴与操作配置。放入前检查所有成员的本体、连接件和炸弹与组外物件、目标及固定卡扣的实体轮廓；组内原有相对接触保持不变。不只判断当前 Shape 能否通过；另一个成员放不进去时显示原因并保持原布局。关联 Shape 下若嵌套固定卡扣或未关联 Shape，会要求先分离层级，避免意外移动它们。支持整个操作一次 Undo/Redo；完成后重新分析和导出关卡。功能只在 Editor 中运行，不增加 Android 运动循环成本。

## 连接头拖拽拾取

拖拽拾取使用 ContainsInteractionPoint：除本体、连接杆和两侧轨道外，也接受烘焙 HeadChannels 中的净通道区域，点击连接头中间即可操作所属 Shape。ContainsPoint 仍表示实际实体轮廓，连接头通道保持物理中空，圆环内孔不会因此变成拾取区域。沿用排序优先级、AllowDrag、连接头锁定及原有位移轴/旋转配置，不新增 Collider 或每帧扫描。旧 Shape 若没有 HeadChannels，需要重新烘焙并导出关卡后才能点击空通道区域。

using System.Text;
using UnityEngine;

namespace WordTile.Game
{
    /// <summary>Test scene UI only; state text is rebuilt on changes, not in the collision loop.</summary>
    [DefaultExecutionOrder(200)]
    public sealed class GameLevelTestPanel : MonoBehaviour
    {
        public GameLevelController Controller;
        public Camera ViewCamera;
        private string states;
        private GUIStyle title, label;
        private void Start() { Controller.StateChanged += Changed; RefreshText(); }
        private void OnDestroy() { if (Controller != null) Controller.StateChanged -= Changed; }
        private void Changed(GameShape shape) { RefreshText(); }
        private void RefreshText()
        {
            var text = new StringBuilder();
            foreach (var shape in Controller.Shapes)
                if (shape != null) text.Append('#').Append(shape.Id).Append(' ').Append(shape.OperationState).Append("    ");
            states = text.ToString();
        }
        private void OnGUI()
        {
            if (Controller == null || ViewCamera == null) return;
            if (title == null)
            {
                title = new GUIStyle(GUI.skin.label) { fontSize = 19, fontStyle = FontStyle.Bold };
                label = new GUIStyle(GUI.skin.label) { fontSize = 14 };
                title.normal.textColor = label.normal.textColor = new Color(0.12f,0.16f,0.23f);
            }
            GUI.Label(new Rect(18,8,Screen.width-190,26), "GAME LEVEL TEST  |  drag with mouse / one finger", title);
            if (GUI.Button(new Rect(Screen.width-150,8,132,30), "Reset level")) { Controller.Load(Controller.Data); RefreshText(); }
            GUI.Label(new Rect(18,42,Screen.width-36,28), states ?? "Loading...", label);
            Caption(new Vector2(-6.6f,4.15f), "1 / LOCK: slide blue #2 UP, then rotate pink #1");
            Caption(new Vector2(1.6f,4.15f), "2 / ROTATE: cyan C #3  |  gray #4 is disabled");
            Caption(new Vector2(-6.6f,-0.55f), "3 / CLASP: green #5 LEFT = head blocked, RIGHT = exit");
            Caption(new Vector2(1.6f,-0.55f), "4 / BOMB: orange #7 LEFT = hide #6 + #7");
        }
        private void Caption(Vector2 world, string text)
        {
            var p = ViewCamera.WorldToScreenPoint(world);
            GUI.Label(new Rect(p.x,Screen.height-p.y,500,44),text,label);
        }
    }
}

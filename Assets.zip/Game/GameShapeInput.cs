using UnityEngine;
using UnityEngine.EventSystems;

namespace WordTile.Game
{
    /// <summary>整场景一个输入循环；单指/鼠标捕获一次对象后，始终通过阻挡接口驱动。</summary>
    [DisallowMultipleComponent, DefaultExecutionOrder(100)]
    public sealed class GameShapeInput : MonoBehaviour
    {
        public Camera InputCamera;
        [Min(0)] public float PickPadding = 0.02f;
        [Min(0.0001f), Tooltip("旋转拖动经过中心时的世界坐标死区，避免角度跳变。")]
        public float RotationDeadRadius = 0.02f;
        public GameShape DraggedShape { get; private set; }
        private static GameShapeInput instance;
        private Camera cachedCamera;
        private Vector3 lastPoint;
        private int fingerId = int.MinValue;

        internal static void Cancel(GameShape shape) { if (instance != null && instance.DraggedShape == shape) instance.CancelDrag(); }
        internal static void EnsureCreated()
        {
            if (instance != null) return;
            instance = FindFirstObjectByType<GameShapeInput>(FindObjectsInactive.Include);
            if (instance == null)
            {
                instance = new GameObject("GameShape Input").AddComponent<GameShapeInput>();
                DontDestroyOnLoad(instance.gameObject);
            }
        }
        private void Awake()
        {
            if (instance != null && instance != this) { enabled = false; return; }
            instance = this;
        }
        private void OnDisable() { CancelDrag(); }
        private void OnDestroy() { if (instance == this) instance = null; }
        private void OnApplicationFocus(bool focus) { if (!focus) CancelDrag(); }
        private void OnApplicationPause(bool paused) { if (paused) CancelDrag(); }

        private void Update()
        {
            if (fingerId != int.MinValue && (DraggedShape == null || !DraggedShape.CanOperate)) CancelDrag();
            int touchCount = Input.touchCount;
            if (fingerId >= 0)
            {
                for (int i = 0; i < touchCount; i++)
                {
                    Touch touch = Input.GetTouch(i);
                    if (touch.fingerId != fingerId) continue;
                    if (touch.phase == TouchPhase.Ended) EndDrag();
                    else if (touch.phase == TouchPhase.Canceled) CancelDrag();
                    else if (touch.phase == TouchPhase.Moved) DragScreen(touch.position);
                    return;
                }
                CancelDrag(); return;
            }
            if (touchCount > 0)
            {
                // 有触摸时不读取模拟鼠标，避免同一次手势被执行两遍。
                if (fingerId == -1) CancelDrag();
                for (int i = 0; i < touchCount; i++)
                {
                    Touch touch = Input.GetTouch(i);
                    if (touch.phase != TouchPhase.Began || OverUI(touch.fingerId)) continue;
                    BeginScreen(touch.position, touch.fingerId); break;
                }
                return;
            }
            if (Input.GetMouseButtonDown(0) && !OverUI(-1)) BeginScreen(Input.mousePosition, -1);
            if (fingerId == -1)
            {
                if (Input.GetMouseButtonUp(0)) EndDrag();
                else if (!Input.GetMouseButton(0)) CancelDrag();
                else DragScreen(Input.mousePosition);
            }
        }
        private static bool OverUI(int id)
        {
            return EventSystem.current != null && EventSystem.current.IsPointerOverGameObject(id);
        }
        private Camera PointerCamera()
        {
            if (InputCamera != null) return InputCamera;
            if (cachedCamera == null) cachedCamera = Camera.main;
            return cachedCamera;
        }
        private void BeginScreen(Vector2 point, int id)
        {
            Camera camera = PointerCamera();
            if (camera != null && BeginDrag(camera.ScreenPointToRay(point))) fingerId = id;
        }
        private void DragScreen(Vector2 point)
        {
            Camera camera = PointerCamera();
            if (camera == null) { CancelDrag(); return; }
            Drag(camera.ScreenPointToRay(point));
        }

        /// <summary>供自定义输入和检查使用；ray 为世界空间指针射线。</summary>
        public bool BeginDrag(Ray ray)
        {
            CancelDrag();
            DraggedShape = GameShape.Pick(ray, Mathf.Max(0, PickPadding), out lastPoint);
            if (DraggedShape != null && DraggedShape.Level != null) DraggedShape.Level.BeginOperation(DraggedShape);
            return DraggedShape != null;
        }
        public void Drag(Ray ray)
        {
            GameShape shape = DraggedShape;
            if (shape == null || !shape.CanOperate) { CancelDrag(); return; }
            Vector3 point;
            if (!GameShape.PointerPoint(ray, shape.transform.position.z, out point)) return;
            if (shape.Operation == GameShapeOperation.Rotate)
            {
                Vector3 center = shape.transform.position;
                float angle;
                if (GameDrag2D.RotationDelta(lastPoint.x - center.x, lastPoint.y - center.y, point.x - center.x, point.y - center.y,
                    Mathf.Max(0.0001f, RotationDeadRadius), out angle) && angle != 0) shape.RequestRotation(angle);
            }
            else
            {
                float x, y;
                if (GameDrag2D.MovementDelta(point.x - lastPoint.x, point.y - lastPoint.y, shape.MovementDirection.x, shape.MovementDirection.y, out x, out y) && (x != 0 || y != 0))
                    shape.RequestMovement(new Vector2(x, y));
            }
            lastPoint = point;
        }
        public void CancelDrag()
        {
            if (DraggedShape != null && DraggedShape.Level != null) DraggedShape.Level.CancelOperation();
            DraggedShape = null; fingerId = int.MinValue;
        }
        public void EndDrag()
        {
            var shape = DraggedShape;
            DraggedShape = null; fingerId = int.MinValue;
            if (shape != null && shape.Level != null) shape.Level.ReleaseShape(shape);
        }
    }
}


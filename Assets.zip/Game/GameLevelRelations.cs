using System;
using System.Collections.Generic;
using Collision = WordTile.Game.GameCollision2D;

namespace WordTile.Game
{
    /// <summary>Directed head/body occupancy. All storage is allocated once per level layout.</summary>
    public sealed class GameLevelRelations
    {
        public const double PenetrationTolerance = 0.00001;
        private readonly GameShape[] shapes;
        private readonly GameClasp[] clasps;
        private readonly int[] headOffsets, lockCounts;
        private readonly bool[] headOccupied, claspOccupied, live;
        private readonly Collision.Part[][] bodies, heads;
        private readonly Collision.Bounds[] bodyBounds;
        private readonly Collision.Part[] claspChannels;
        private readonly bool[] claspLive;
        public int LastPairChecks { get; private set; }

        public GameLevelRelations(GameShape[] shapes, GameClasp[] clasps)
        {
            this.shapes = shapes; this.clasps = clasps;
            int n = shapes.Length; headOffsets = new int[n + 1];
            for (int i = 0; i < n; i++) headOffsets[i + 1] = headOffsets[i] + (shapes[i] != null && shapes[i].HeadChannels != null ? shapes[i].HeadChannels.Length : 0);
            headOccupied = new bool[headOffsets[n] * n]; claspOccupied = new bool[clasps.Length * n];
            lockCounts = new int[n]; live = new bool[n]; bodies = new Collision.Part[n][]; heads = new Collision.Part[n][];
            bodyBounds = new Collision.Bounds[n]; claspChannels = new Collision.Part[clasps.Length]; claspLive = new bool[clasps.Length];
        }
        public bool LayoutChanged()
        {
            for (int i = 0; i < shapes.Length; i++)
                if (shapes[i] != null && (shapes[i].HeadChannels == null ? 0 : shapes[i].HeadChannels.Length) != headOffsets[i + 1] - headOffsets[i]) return true;
            return false;
        }
        public void Rebuild()
        {
            LastPairChecks = 0;
            Array.Clear(headOccupied, 0, headOccupied.Length); Array.Clear(claspOccupied, 0, claspOccupied.Length); Array.Clear(lockCounts, 0, lockCounts.Length);
            for (int i = 0; i < shapes.Length; i++) SyncShape(i);
            for (int c = 0; c < clasps.Length; c++) SyncClasp(c);
            // ponytail: initial O(n²) owner/body scan is bounded to ~100 Shapes; incremental updates are O(n).
            for (int i = 0; i < shapes.Length; i++)
            {
                for (int j = 0; j < shapes.Length; j++) if (i != j) EvaluateHeads(i, j);
                for (int c = 0; c < clasps.Length; c++) EvaluateClasp(c, i);
            }
        }
        public void UpdateShape(int index)
        {
            LastPairChecks = 0; SyncShape(index);
            for (int j = 0; j < shapes.Length; j++) if (j != index) { EvaluateHeads(index, j); EvaluateHeads(j, index); }
            for (int c = 0; c < clasps.Length; c++) EvaluateClasp(c, index);
        }
        public void UpdateClasp(int index)
        {
            LastPairChecks = 0; SyncClasp(index);
            for (int i = 0; i < shapes.Length; i++) EvaluateClasp(index, i);
        }
        private void SyncShape(int i)
        {
            var s = shapes[i]; live[i] = false;
            if (s == null || !s.isActiveAndEnabled || s.BodyPartCount <= 0 || !s.TryRelationGeometry(out bodies[i], out heads[i]) ||
                s.BodyPartCount > s.CollisionParts.Length || heads[i].Length != headOffsets[i + 1] - headOffsets[i]) return;
            live[i] = true; bodyBounds[i] = bodies[i][0].Bounds;
            for (int k = 1; k < s.BodyPartCount; k++) bodyBounds[i].Include(bodies[i][k].Bounds);
        }
        private void SyncClasp(int c)
        {
            var clasp = clasps[c]; claspLive[c] = false;
            if (clasp == null || !clasp.isActiveAndEnabled || !clasp.SyncWorld()) return;
            var delta = clasp.Rail1.A - clasp.Rail0.A;
            claspChannels[c] = new Collision.Part { Kind = GameCollisionKind.Box, A = (clasp.Rail0.A + clasp.Rail1.A) * 0.5,
                Axis = clasp.Rail0.Axis, HalfWidth = clasp.Rail0.HalfWidth,
                HalfHeight = Math.Sqrt(Collision.Dot(delta, delta)) * 0.5 - clasp.Rail0.HalfHeight };
            claspChannels[c].UpdateBounds(); claspLive[c] = true;
        }
        private void EvaluateHeads(int owner, int body)
        {
            for (int h = headOffsets[owner]; h < headOffsets[owner + 1]; h++)
            {
                int slot = h * shapes.Length + body;
                bool occupied = live[owner] && live[body] && InChannel(heads[owner][h - headOffsets[owner]], body);
                if (headOccupied[slot] == occupied) continue;
                headOccupied[slot] = occupied; lockCounts[owner] += occupied ? 1 : -1;
            }
        }
        private void EvaluateClasp(int clasp, int body)
        {
            claspOccupied[clasp * shapes.Length + body] = claspLive[clasp] && live[body] && InChannel(claspChannels[clasp], body);
        }
        private bool InChannel(in Collision.Part channel, int body)
        {
            if (!channel.Bounds.Overlaps(bodyBounds[body])) return false;
            for (int i = 0; i < shapes[body].BodyPartCount; i++)
            {
                ref var part = ref bodies[body][i];
                if (!channel.Bounds.Overlaps(part.Bounds)) continue;
                LastPairChecks++;
                if (Collision.Clearance(channel, part) < -PenetrationTolerance) return true;
            }
            return false;
        }
        public int LockCount(int shapeIndex) { return lockCounts[shapeIndex]; }
        public GameOperationState State(int shapeIndex)
        {
            var shape = shapes[shapeIndex];
            return !live[shapeIndex] || !shape.AllowDrag ? GameOperationState.Disabled : lockCounts[shapeIndex] > 0 ? GameOperationState.HeadLocked :
                shape.Operation == GameShapeOperation.Rotate ? GameOperationState.Rotate : GameOperationState.Move;
        }
        public bool HeadOccupied(int ownerIndex, int headIndex, int bodyIndex)
        { return headOccupied[(headOffsets[ownerIndex] + headIndex) * shapes.Length + bodyIndex]; }
        public bool ClaspOccupied(int claspIndex, int shapeIndex) { return claspOccupied[claspIndex * shapes.Length + shapeIndex]; }
        public static void ValidateInitialGeometry(GameShape[] shapes, GameClasp[] clasps)
        {
            for (int i = 0; i < shapes.Length; i++)
            {
                var shape = shapes[i]; if (!shape.isActiveAndEnabled || !shape.BlockMovement) continue;
                GameCollision2D.Part[] a, unused; shape.TryRelationGeometry(out a, out unused);
                for (int j = i + 1; j < shapes.Length; j++)
                {
                    if (!shapes[j].isActiveAndEnabled || !shapes[j].BlockMovement) continue;
                    GameCollision2D.Part[] b; shapes[j].TryRelationGeometry(out b, out unused);
                    for (int x = 0; x < shape.CollisionParts.Length; x++) for (int y = 0; y < shapes[j].CollisionParts.Length; y++)
                        if (a[x].Bounds.Overlaps(b[y].Bounds) && GameCollision2D.Clearance(a[x], b[y]) < -GameLevelRelations.PenetrationTolerance)
                            throw new ArgumentException("Shape " + shape.Id + " 与 " + shapes[j].Id + " 的实心轮廓初始重叠；请检查摆放。");
                }
                foreach (var clasp in clasps)
                {
                    if (!clasp.isActiveAndEnabled) continue;
                    for (int x = 0; x < shape.CollisionParts.Length; x++)
                        if ((a[x].Bounds.Overlaps(clasp.Rail0.Bounds) && GameCollision2D.Clearance(a[x], clasp.Rail0) < -GameLevelRelations.PenetrationTolerance) ||
                            (a[x].Bounds.Overlaps(clasp.Rail1.Bounds) && GameCollision2D.Clearance(a[x], clasp.Rail1) < -GameLevelRelations.PenetrationTolerance))
                            throw new ArgumentException("Shape " + shape.Id + " 与固定卡扣 " + clasp.Id + " 的实心轨道初始重叠。");
                }
            }
        }
        public GameHeadRelation[] CaptureHeads()
        {
            var result = new List<GameHeadRelation>();
            for (int i = 0; i < shapes.Length; i++)
                for (int h = 0; h < headOffsets[i + 1] - headOffsets[i]; h++)
                    for (int j = 0; j < shapes.Length; j++) if (HeadOccupied(i, h, j))
                        result.Add(new GameHeadRelation { OwnerShapeId = shapes[i].Id, HeadIndex = h, BodyShapeId = shapes[j].Id });
            return result.ToArray();
        }
        public GameClaspRelation[] CaptureClasps()
        {
            var result = new List<GameClaspRelation>();
            for (int c = 0; c < clasps.Length; c++) for (int i = 0; i < shapes.Length; i++) if (ClaspOccupied(c, i))
                result.Add(new GameClaspRelation { ClaspId = clasps[c].Id, ShapeId = shapes[i].Id });
            return result.ToArray();
        }
    }
}

using System;
using UnityEngine;

namespace WordTile.Game
{
    [DisallowMultipleComponent]
    public sealed class GameBomb : MonoBehaviour
    {
        [Min(0)] public int Id;
        public Sprite Sprite;
        [Min(0.0001f)] public float ImageWidth = 0.5f;
        [Min(0.0001f)] public float Radius = 0.2f;
        public Vector2 CenterOffset = new Vector2(0, -0.05f);
        public int SortingOffset = 5;
        public bool ShowCollisionGizmos = true;
        public GameShape Owner { get; private set; }
        public bool Spent { get; private set; }
        public bool Armed { get { GameCollision2D.Part p; return isActiveAndEnabled && !Spent && Owner != null && Owner.isActiveAndEnabled && TryPart(out p); } }
        public event Action<GameBomb, GameShape, Vector3> Exploded;
        [SerializeField, HideInInspector] private SpriteRenderer visual;
        private Matrix4x4 cachedMatrix;
        private float cachedRadius;
        private Vector2 cachedOffset;
        private bool cached;

        private void OnEnable() { Refresh(); }
        private void Start() { if (Owner != null) Owner.CheckBombContacts(); }
        private void OnDisable() { if (Owner != null) Owner.BombsChanged(); }
        private void OnDestroy() { if (Owner != null) Owner.RemoveBomb(this); }
        private void OnTransformParentChanged() { Refresh(); }
        private void OnValidate() { cached = false; if (Owner != null) Owner.BombsChanged(); }
        public void Refresh()
        {
            var owner = GetComponentInParent<GameShape>(true);
            if (owner != Owner)
            {
                if (Owner != null) Owner.RemoveBomb(this);
                Owner = owner;
                if (Owner != null) Owner.AddBomb(this);
            }
            cached = false;
            if (Owner != null) Owner.BombsChanged();
            if (visual == null)
            {
                var child = new GameObject("Bomb Visual"); child.transform.SetParent(transform, false);
                visual = child.AddComponent<SpriteRenderer>();
            }
            visual.sprite = Sprite;
            visual.enabled = Sprite != null && GameCollisionPart.Finite(ImageWidth) && ImageWidth > 0;
            if (visual.enabled && Sprite.bounds.size.x > 0)
                visual.transform.localScale = Vector3.one * (ImageWidth / Sprite.bounds.size.x);
            if (Owner != null)
            {
                var renderer = Owner.GetComponent<MeshRenderer>();
                visual.sortingLayerID = renderer.sortingLayerID;
                visual.sortingOrder = renderer.sortingOrder + SortingOffset;
            }
        }
        public void ResetBomb() { Spent = false; cached = false; if (Owner != null) Owner.BombsChanged(); }
        internal bool Changed()
        {
            var matrix = LocalMatrix();
            if (cached && matrix.Equals(cachedMatrix) && Radius.Equals(cachedRadius) && CenterOffset.Equals(cachedOffset)) return false;
            cached = true; cachedMatrix = matrix; cachedRadius = Radius; cachedOffset = CenterOffset; return true;
        }
        private Matrix4x4 LocalMatrix()
        {
            var matrix = Matrix4x4.identity;
            var current = transform;
            while (current != null && (Owner == null || current != Owner.transform))
            {
                matrix = Matrix4x4.TRS(current.localPosition, current.localRotation, current.localScale) * matrix;
                current = current.parent;
            }
            return matrix;
        }
        internal bool TryPart(out GameCollision2D.Part part)
        {
            part = default(GameCollision2D.Part);
            if (!isActiveAndEnabled || Spent || Owner == null || !GameCollisionPart.Finite(Radius) || Radius <= 0 ||
                !GameCollisionPart.Finite(CenterOffset.x) || !GameCollisionPart.Finite(CenterOffset.y)) return false;
            var m = LocalMatrix();
            Vector3 x = m.GetColumn(0), y = m.GetColumn(1), z = m.GetColumn(2);
            float scale = new Vector2(x.x, x.y).magnitude;
            if (!GameCollisionPart.Finite(scale) || scale < 0.000001f || Mathf.Abs(y.magnitude - scale) > scale * 0.0001f ||
                Mathf.Abs(Vector3.Dot(x, y)) > scale * scale * 0.0001f || Mathf.Abs(x.z) + Mathf.Abs(y.z) > scale * 0.0001f ||
                x.x * y.y - x.y * y.x <= 0 || z.z <= 0) return false;
            Vector3 center = m.MultiplyPoint3x4(CenterOffset);
            if (!GameCollisionPart.Finite(center.x) || !GameCollisionPart.Finite(center.y)) return false;
            part.Kind = GameCollisionKind.Capsule; part.A = part.B = new GameCollision2D.Point(center.x, center.y);
            part.Radius = Radius * scale; part.UpdateBounds(); return true;
        }
        internal static void Detonate(GameBomb a, GameBomb b, GameShape first, GameShape second, Vector3 point)
        {
            var firstLevel = first != null ? first.Level : null;
            var secondLevel = second != null ? second.Level : null;
            if (firstLevel != null) firstLevel.BeginChanges();
            if (secondLevel != null && secondLevel != firstLevel) secondLevel.BeginChanges();
            if (a != null) { a.Spent = true; if (a.Owner != null) a.Owner.BombsChanged(); }
            if (b != null) { b.Spent = true; if (b.Owner != null) b.Owner.BombsChanged(); }
            // Lock both bombs before callbacks; hiding still completes when a subscriber throws.
            try
            {
                if (a != null) a.Notify(a.Owner == first ? second : first, point);
                if (b != null) b.Notify(b.Owner == first ? second : first, point);
            }
            finally
            {
                try
                {
                    if (first != null) first.gameObject.SetActive(false);
                    if (second != null) second.gameObject.SetActive(false);
                }
                finally
                {
                    if (firstLevel != null) firstLevel.EndChanges();
                    if (secondLevel != null && secondLevel != firstLevel) secondLevel.EndChanges();
                }
            }
        }
        private void Notify(GameShape other, Vector3 point)
        {
            try { Exploded?.Invoke(this, other, point); }
            catch (Exception e) { Debug.LogException(e, this); }
        }
#if UNITY_EDITOR
        private void OnDrawGizmosSelected()
        {
            if (!ShowCollisionGizmos || Radius <= 0) return;
            var matrix = Gizmos.matrix; var color = Gizmos.color;
            Gizmos.matrix = transform.localToWorldMatrix; Gizmos.color = Spent ? Color.gray : Color.red;
            Vector3 previous = CenterOffset + Vector2.right * Radius;
            for (int i = 1; i <= 64; i++)
            {
                float angle = i * Mathf.PI / 32;
                Vector3 next = CenterOffset + new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * Radius;
                Gizmos.DrawLine(previous, next); previous = next;
            }
            Gizmos.matrix = matrix; Gizmos.color = color;
        }
#endif
    }
}

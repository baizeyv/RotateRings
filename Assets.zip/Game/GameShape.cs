using System;
using System.Collections.Generic;
using UnityEngine;
using Collision = WordTile.Game.GameCollision2D;

namespace WordTile.Game
{
    [Serializable]
    public struct GameCollisionPart
    {
        public GameCollisionKind Kind;
        public Vector2 Center, End;
        [Min(0.0001f)] public float Radius;
        [Min(0.0001f)] public float RingRadius;
        public Vector2 Size;
        public float Angle;
        public Collision.Part Bake()
        {
            if (!Finite(Center.x) || !Finite(Center.y) || !Finite(End.x) || !Finite(End.y) || !Finite(Angle) ||
                !Finite(Radius) || !Finite(RingRadius) || !Finite(Size.x) || !Finite(Size.y) ||
                !Enum.IsDefined(typeof(GameCollisionKind), Kind) ||
                (Kind != GameCollisionKind.Box && Radius <= 0) ||
                (Kind == GameCollisionKind.Ring && RingRadius <= Radius) ||
                (Kind == GameCollisionKind.Box && (Size.x <= 0 || Size.y <= 0)))
                throw new ArgumentException("碰撞尺寸无效。");
            double radians = Angle * Math.PI / 180;
            var part = new Collision.Part { Kind = Kind, A = new Collision.Point(Center.x, Center.y), B = new Collision.Point(End.x, End.y),
                Axis = new Collision.Point(Math.Cos(radians), Math.Sin(radians)), Radius = Radius, RingRadius = RingRadius,
                HalfWidth = Size.x / 2, HalfHeight = Size.y / 2, RotationInvariant = Kind == GameCollisionKind.Ring && Center.x == 0 && Center.y == 0 };
            part.UpdateBounds(); return part;
        }
        internal static bool Finite(float f) { return !float.IsNaN(f) && !float.IsInfinity(f); }
    }

    /// <summary>二维阻挡及可操作类型；指针输入由一个 GameShapeInput 统一驱动。</summary>
    [DisallowMultipleComponent, RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]
    public sealed class GameShape : MonoBehaviour
    {
        [Min(0)] public int Id;
        public GameShapeType ShapeType;
        public Sprite CollectionSprite;
        [Min(0), Tooltip("Collision Parts 开头连续的本体件数量，不含连接件。")]
        public int BodyPartCount;
        public GameHeadChannel[] HeadChannels = Array.Empty<GameHeadChannel>();
        [HideInInspector] public int MetadataVersion;
        public bool IsHeadLocked { get; private set; }
        public bool CanOperate { get { return Ready && isActiveAndEnabled && AllowDrag && !IsHeadLocked; } }
        public GameOperationState OperationState { get { return !Ready || !isActiveAndEnabled || !AllowDrag ? GameOperationState.Disabled :
            IsHeadLocked ? GameOperationState.HeadLocked : Operation == GameShapeOperation.Rotate ? GameOperationState.Rotate : GameOperationState.Move; } }
        internal GameLevelController Level;
        internal int LevelIndex = -1;
        public Mesh ShapeMesh;
        public Material ShapeMaterial;
#if UNITY_EDITOR
        [Tooltip("只供编辑器烘焙，运行时不读取 JSON。")]
        public TextAsset ShapeConfig;
#endif
        public GameCollisionPart[] CollisionParts = new[] { new GameCollisionPart { Kind = GameCollisionKind.Ring, RingRadius = 1, Radius = 0.1f } };
        public bool BlockMovement = true;
        public bool AllowDrag = true;
        public GameShapeOperation Operation = GameShapeOperation.Rotate;
        [Tooltip("位移类拖动的世界坐标轴，默认左右；(0,1) 为上下。不随对象旋转。")]
        public Vector2 MovementDirection = Vector2.right;
        public bool ShowCollisionGizmos = true;
        [Min(0.00001f), Tooltip("世界坐标安全间距。")]
        public float CollisionSkin = 0.0005f;
        public bool Ready { get; private set; }
        public GameShape LastObstacle { get; private set; }
        public GameClasp LastClaspObstacle { get; private set; }
        public int LastSweepIterations { get; private set; }
        public int LastPairChecks { get; private set; }
        public event Action<GameShape> CollisionBlocked;

        private const int MaxSweepIterations = 64;
        private static readonly List<GameShape> active = new List<GameShape>(128);
        private readonly List<GameShape> candidates = new List<GameShape>(128);
        private readonly List<GameClasp> claspCandidates = new List<GameClasp>(128);
        private Collision.Part[] local, world, trial;
        private Collision.Part[] localHeads, worldHeads;
        internal void SetHeadLocked(bool locked) { IsHeadLocked = locked; if (locked) GameShapeInput.Cancel(this); }
        internal bool TryRelationGeometry(out Collision.Part[] parts, out Collision.Part[] heads)
        {
            parts = world; heads = worldHeads;
            if (!Ready || !SyncWorld()) return false;
            parts = world; heads = worldHeads; return true;
        }
        private readonly List<GameBomb> bombs = new List<GameBomb>(4);
        private GameBomb[] partBombs;
        private bool bombsDirty;
        private GameBomb hitBomb, hitOtherBomb;
        private Vector3 hitPoint;
        internal void AddBomb(GameBomb bomb) { if (!bombs.Contains(bomb)) bombs.Add(bomb); BombsChanged(); }
        internal void RemoveBomb(GameBomb bomb) { bombs.Remove(bomb); BombsChanged(); }
        internal void BombsChanged() { bombsDirty = true; cacheValid = false; }
        private void Start() { CheckBombContacts(); }
        private Collision.Bounds bounds;
        private Matrix4x4 cachedMatrix;
        private bool cacheValid;
        private double localRadius, worldScale;
        private MeshRenderer meshRenderer;

        private void OnEnable()
        {
            active.Add(this); Initialize();
            if (Application.isPlaying && AllowDrag) GameShapeInput.EnsureCreated();
            if (Level != null) Level.ShapeChanged(LevelIndex);
        }
        private void OnDisable() { active.Remove(this); GameShapeInput.Cancel(this); if (Level != null) Level.ShapeChanged(LevelIndex); }
        public bool Initialize()
        {
            Ready = false; cacheValid = false;
            try
            {
                if (CollisionParts == null || CollisionParts.Length == 0) throw new ArgumentException("请先烘焙或配置 Collision Parts。");
                int count = CollisionParts.Length;
                for (int i = 0; i < bombs.Count; i++) { Collision.Part bombPart; if (bombs[i] != null && bombs[i].TryPart(out bombPart)) count++; }
                if (local == null || local.Length != count)
                {
                    local = new Collision.Part[count]; world = new Collision.Part[count]; trial = new Collision.Part[count]; partBombs = new GameBomb[count];
                }
                Array.Clear(partBombs, 0, partBombs.Length);
                for (int i = 0; i < CollisionParts.Length; i++) local[i] = CollisionParts[i].Bake();
                int headCount = HeadChannels == null ? 0 : HeadChannels.Length;
                if (localHeads == null || localHeads.Length != headCount) { localHeads = new Collision.Part[headCount]; worldHeads = new Collision.Part[headCount]; }
                for (int i = 0; i < headCount; i++) localHeads[i] = HeadChannels[i].Bake();
                int index = CollisionParts.Length;
                for (int i = 0; i < bombs.Count; i++)
                {
                    Collision.Part bombPart;
                    if (bombs[i] != null && bombs[i].TryPart(out bombPart)) { local[index] = bombPart; partBombs[index++] = bombs[i]; }
                }
                for (int i = 0; i < bombs.Count; i++) if (bombs[i] != null) bombs[i].Changed();
                bombsDirty = false;
                localRadius = 0;
                for (int i = 0; i < local.Length; i++)
                {
                    var p = local[i];
                    double radius = Math.Sqrt(Collision.Dot(p.A, p.A));
                    if (p.Kind == GameCollisionKind.Ring) radius += p.RingRadius + p.Radius;
                    else if (p.Kind == GameCollisionKind.Capsule) radius = Math.Max(radius, Math.Sqrt(Collision.Dot(p.B, p.B))) + p.Radius;
                    else radius += Math.Sqrt(p.HalfWidth * p.HalfWidth + p.HalfHeight * p.HalfHeight);
                    localRadius = Math.Max(localRadius, radius);
                }
                if (ShapeMesh != null) GetComponent<MeshFilter>().sharedMesh = ShapeMesh;
                meshRenderer = GetComponent<MeshRenderer>();
                if (ShapeMaterial != null) meshRenderer.sharedMaterial = ShapeMaterial;
                Ready = true;
                if (!SyncWorld()) throw new ArgumentException("仅支持 XY 平面、正的均匀缩放；不支持倾斜或父级剪切。");
                return true;
            }
            catch (ArgumentException e) { Ready = false; Debug.LogError("GameShape：" + e.Message, this); return false; }
        }

        private bool SyncWorld()
        {
            for (int i = 0; i < bombs.Count; i++) if (bombs[i] != null && bombs[i].Changed()) bombsDirty = true;
            if (bombsDirty) return Initialize();
            Matrix4x4 matrix = transform.localToWorldMatrix;
            if (cacheValid && matrix.Equals(cachedMatrix)) return true;
            Vector3 x = matrix.GetColumn(0), y = matrix.GetColumn(1), z = matrix.GetColumn(2);
            double scale = Math.Sqrt((double)x.x * x.x + (double)x.y * x.y);
            double otherScale = Math.Sqrt((double)y.x * y.x + (double)y.y * y.y);
            if (!GameCollisionPart.Finite(matrix.m03) || !GameCollisionPart.Finite(matrix.m13) || double.IsNaN(scale) || double.IsInfinity(scale) ||
                double.IsNaN(otherScale) || double.IsInfinity(otherScale) || scale < 0.000001 || Math.Abs(scale - otherScale) > scale * 0.0001 || Math.Abs(Vector3.Dot(x, y)) > scale * scale * 0.0001 ||
                Math.Abs(x.z) > scale * 0.0001 || Math.Abs(y.z) > scale * 0.0001 || x.x * y.y - x.y * y.x <= 0 || z.z <= 0) return false;
            worldScale = scale;
            Fill(world, matrix.m03, matrix.m13, x.x / scale, x.y / scale);
            for (int i = 0; i < localHeads.Length; i++) worldHeads[i] = Collision.Transform(localHeads[i], matrix.m03, matrix.m13, x.x / scale, x.y / scale, worldScale);
            bounds = world[0].Bounds;
            for (int i = 1; i < world.Length; i++) bounds.Include(world[i].Bounds);
            cachedMatrix = matrix; cacheValid = true; return true;
        }
        private void Fill(Collision.Part[] output, double x, double y, double cosine, double sine)
        {
            for (int i = 0; i < local.Length; i++) output[i] = Collision.Transform(local[i], x, y, cosine, sine, worldScale);
        }

        internal static bool PointerPoint(Ray ray, float z, out Vector3 point)
        {
            point = Vector3.zero;
            if (Mathf.Abs(ray.direction.z) < 0.000001f) return false;
            float distance = (z - ray.origin.z) / ray.direction.z;
            if (distance < 0) return false;
            point = ray.GetPoint(distance); return true;
        }
        internal static GameShape Pick(Ray ray, float padding, out Vector3 point)
        {
            GameShape selected = null; point = Vector3.zero;
            int bestLayer = int.MinValue, bestOrder = int.MinValue, bestId = int.MinValue;
            for (int i = 0; i < active.Count; i++)
            {
                GameShape shape = active[i]; Vector3 candidate;
                if (!shape.CanOperate || shape.meshRenderer == null || !shape.meshRenderer.enabled ||
                    !PointerPoint(ray, shape.transform.position.z, out candidate) || !shape.ContainsPoint(candidate, padding)) continue;
                int layer = SortingLayer.GetLayerValueFromID(shape.meshRenderer.sortingLayerID);
                int order = shape.meshRenderer.sortingOrder, id = shape.GetInstanceID();
                if (selected != null && (layer < bestLayer || (layer == bestLayer && (order < bestOrder || (order == bestOrder && id <= bestId))))) continue;
                selected = shape; point = candidate; bestLayer = layer; bestOrder = order; bestId = id;
            }
            return selected;
        }
        public bool ContainsPoint(Vector2 point, float padding = 0)
        {
            if (!Ready || !GameCollisionPart.Finite(point.x) || !GameCollisionPart.Finite(point.y) || !GameCollisionPart.Finite(padding) || padding < 0 || !SyncWorld()) return false;
            var probe = new Collision.Part { Kind = GameCollisionKind.Capsule, A = new Collision.Point(point.x, point.y), B = new Collision.Point(point.x, point.y) };
            probe.UpdateBounds(); double paddingSquared = (double)padding * padding;
            if (bounds.GapSquared(probe.Bounds) > paddingSquared) return false;
            for (int i = 0; i < world.Length; i++)
                if (world[i].Bounds.GapSquared(probe.Bounds) <= paddingSquared && Collision.Clearance(world[i], probe) <= padding) return true;
            return false;
        }

        /// <returns>实际执行比例；1 表示完整执行，0 表示未移动。</returns>
        public float RequestMovement(Vector2 worldDisplacement) { return RequestMotion(worldDisplacement, 0); }
        public float RequestRotation(float degrees) { return RequestMotion(Vector2.zero, degrees); }
        public float RequestMotion(Vector2 displacement, float degrees)
        {
            hitBomb = hitOtherBomb = null;
            LastObstacle = null; LastClaspObstacle = null; LastSweepIterations = LastPairChecks = 0;
            if (!Ready || !isActiveAndEnabled || IsHeadLocked || !GameCollisionPart.Finite(displacement.x) || !GameCollisionPart.Finite(displacement.y) || !GameCollisionPart.Finite(degrees) ||
                !GameCollisionPart.Finite(CollisionSkin) || CollisionSkin <= 0 || !SyncWorld()) return 0;
            double radians = degrees * Math.PI / 180;
            double travel = Math.Sqrt((double)displacement.x * displacement.x + (double)displacement.y * displacement.y) + Math.Abs(radians) * localRadius * worldScale;
            if (travel < 1e-12) return 1;
            Vector3 position = transform.position; Quaternion rotation = transform.rotation;
            double fraction = 1;
            if (BlockMovement || HasBombsInScene())
            {
                candidates.Clear();
                claspCandidates.Clear();
                double radius = localRadius * worldScale + CollisionSkin;
                Collision.Bounds sweepBounds;
                if (degrees == 0)
                    sweepBounds = new Collision.Bounds { MinX = bounds.MinX + Math.Min(0, displacement.x) - CollisionSkin, MaxX = bounds.MaxX + Math.Max(0, displacement.x) + CollisionSkin,
                        MinY = bounds.MinY + Math.Min(0, displacement.y) - CollisionSkin, MaxY = bounds.MaxY + Math.Max(0, displacement.y) + CollisionSkin };
                else
                    sweepBounds = new Collision.Bounds { MinX = Math.Min(position.x, position.x + displacement.x) - radius, MaxX = Math.Max(position.x, position.x + displacement.x) + radius,
                        MinY = Math.Min(position.y, position.y + displacement.y) - radius, MaxY = Math.Max(position.y, position.y + displacement.y) + radius };
                for (int i = 0; i < active.Count; i++)
                {
                    GameShape other = active[i];
                    if (other == this || !other.Ready || !other.SyncWorld() || (!(BlockMovement && other.BlockMovement) && bombs.Count == 0 && other.bombs.Count == 0)) continue;
                    if (sweepBounds.Overlaps(other.bounds)) candidates.Add(other);
                }
                for (int i = 0; BlockMovement && i < GameClasp.Active.Count; i++)
                {
                    GameClasp clasp = GameClasp.Active[i];
                    if (clasp == null || !clasp.isActiveAndEnabled || !clasp.SyncWorld()) continue;
                    if (sweepBounds.Overlaps(clasp.Bounds)) claspCandidates.Add(clasp);
                }
                if (candidates.Count > 0 || claspCandidates.Count > 0)
                {
                    bool rotationOnly = displacement.x == 0 && displacement.y == 0;
                    double startAngle = Math.Atan2(cachedMatrix.m10, cachedMatrix.m00);
                    double distance = Clearance(world, rotationOnly); fraction = 0;
                    // ponytail: 最多 64 次推进控制单次耗时；极端贴边运动可能只执行部分请求。
                    for (int step = 0; step < MaxSweepIterations; step++)
                    {
                        LastSweepIterations++;
                        if (distance < -CollisionSkin) break;
                        double next = Collision.Advance(fraction, distance, travel, CollisionSkin);
                        double angle = startAngle + radians * next;
                        Fill(trial, position.x + displacement.x * next, position.y + displacement.y * next, Math.Cos(angle), Math.Sin(angle));
                        double nextDistance = Clearance(trial, rotationOnly);
                        if (nextDistance < CollisionSkin && nextDistance <= distance + 1e-12) break;
                        fraction = next; distance = nextDistance;
                        if (fraction >= 1) break;
                    }
                }
            }
            if (fraction > 0)
            {
                transform.SetPositionAndRotation(position + new Vector3(displacement.x, displacement.y, 0) * (float)fraction,
                    Quaternion.AngleAxis(degrees * (float)fraction, Vector3.forward) * rotation);
                cacheValid = false;
            }
            if (hitBomb != null || hitOtherBomb != null)
            {
                if (fraction < 1 && hitDistance <= CollisionSkin + 1e-9)
                    GameBomb.Detonate(hitBomb, hitOtherBomb, this, LastObstacle, hitPoint);
            }
            if (fraction > 0 && Level != null) Level.ShapeChanged(LevelIndex);
            if (fraction < 1 && isActiveAndEnabled) CollisionBlocked?.Invoke(LastObstacle);
            else { LastObstacle = null; LastClaspObstacle = null; }
            return (float)fraction;
        }
        private double Clearance(Collision.Part[] parts, bool rotationOnly)
        {
            double minimum = double.PositiveInfinity;
            hitBomb = hitOtherBomb = null;
            hitDistance = double.PositiveInfinity;
            for (int k = 0; k < candidates.Count; k++)
            {
                GameShape other = candidates[k];
                for (int i = 0; i < parts.Length; i++)
                {
                    if (rotationOnly && local[i].RotationInvariant && partBombs[i] == null && other.bombs.Count == 0) continue;
                    for (int j = 0; j < other.world.Length; j++)
                    {
                        GameBomb bomb = partBombs[i], otherBomb = other.partBombs[j];
                        if (bomb == null && otherBomb == null && !(BlockMovement && other.BlockMovement)) continue;
                        ref var a = ref parts[i]; ref var b = ref other.world[j];
                        double gapSquared = a.Bounds.GapSquared(b.Bounds);
                        if (gapSquared > 0 && (minimum <= 0 || gapSquared > minimum * minimum)) continue;
                        LastPairChecks++;
                        double gap = Collision.Clearance(a, b);
                        if (gap < minimum)
                        {
                            minimum = gap; LastObstacle = other; LastClaspObstacle = null;
                            hitBomb = bomb; hitOtherBomb = otherBomb; hitDistance = gap;
                            if (bomb != null || otherBomb != null)
                            {
                                var contact = Collision.CircleContact(bomb != null ? a : b, bomb != null ? b : a);
                                hitPoint = new Vector3((float)contact.X, (float)contact.Y, transform.position.z);
                            }
                        }
                    }
                }
            }
            for (int k = 0; k < claspCandidates.Count; k++)
            {
                GameClasp clasp = claspCandidates[k];
                for (int i = 0; i < parts.Length; i++)
                {
                    if (rotationOnly && local[i].RotationInvariant) continue;
                    ref var a = ref parts[i];
                    TestClaspRail(a, clasp.Rail0, clasp, ref minimum);
                    TestClaspRail(a, clasp.Rail1, clasp, ref minimum);
                }
            }
            return minimum;
        }
        private double hitDistance;
        private static bool HasBombsInScene()
        {
            for (int i = 0; i < active.Count; i++) if (active[i].bombs.Count > 0) return true;
            return false;
        }
        public bool CheckBombContacts()
        {
            if (!Ready || !isActiveAndEnabled || !SyncWorld() || !HasBombsInScene()) return false;
            candidates.Clear(); claspCandidates.Clear();
            for (int i = 0; i < active.Count; i++)
            {
                var other = active[i];
                if (other != this && other.Ready && other.SyncWorld() && bounds.Overlaps(other.bounds)) candidates.Add(other);
            }
            // Overlap checks ignore ordinary obstacles, but preserve the configured movement setting.
            bool blocking = BlockMovement; BlockMovement = false;
            try { Clearance(world, false); }
            finally { BlockMovement = blocking; }
            if ((hitBomb == null && hitOtherBomb == null) || hitDistance > 0) return false;
            GameBomb.Detonate(hitBomb, hitOtherBomb, this, LastObstacle, hitPoint); return true;
        }
        private void TestClaspRail(in Collision.Part a, in Collision.Part b, GameClasp clasp, ref double minimum)
        {
            double gapSquared = a.Bounds.GapSquared(b.Bounds);
            if (gapSquared > 0 && (minimum <= 0 || gapSquared > minimum * minimum)) return;
            LastPairChecks++;
            double gap = Collision.Clearance(a, b);
            if (gap < minimum) { minimum = gap; LastObstacle = null; LastClaspObstacle = clasp; hitBomb = hitOtherBomb = null; hitDistance = gap; }
        }
#if UNITY_EDITOR
        private void OnDrawGizmosSelected()
        {
            if (!ShowCollisionGizmos || CollisionParts == null) return;
            Matrix4x4 previous = Gizmos.matrix; Color color = Gizmos.color;
            Gizmos.matrix = transform.localToWorldMatrix;
            for (int i = 0; i < CollisionParts.Length; i++)
            {
                var p = CollisionParts[i]; Gizmos.color = p.Kind == GameCollisionKind.Box ? Color.yellow : Color.green;
                if (p.Kind == GameCollisionKind.Ring)
                {
                    DrawArc(p.Center, p.RingRadius + p.Radius, 0, 360); DrawArc(p.Center, p.RingRadius - p.Radius, 0, 360);
                }
                else if (p.Kind == GameCollisionKind.Box)
                {
                    Gizmos.matrix = transform.localToWorldMatrix * Matrix4x4.TRS(p.Center, Quaternion.Euler(0, 0, p.Angle), Vector3.one);
                    Gizmos.DrawWireCube(Vector3.zero, new Vector3(p.Size.x, p.Size.y, 0)); Gizmos.matrix = transform.localToWorldMatrix;
                }
                else
                {
                    Vector2 d = (p.End - p.Center).normalized; if (d == Vector2.zero) d = Vector2.right;
                    Vector2 normal = new Vector2(-d.y, d.x) * p.Radius;
                    Gizmos.DrawLine(p.Center + normal, p.End + normal); Gizmos.DrawLine(p.Center - normal, p.End - normal);
                    float angle = Mathf.Atan2(d.y, d.x) * Mathf.Rad2Deg;
                    DrawArc(p.Center, p.Radius, angle + 90, 180); DrawArc(p.End, p.Radius, angle - 90, 180);
                }
            }
            Gizmos.matrix = previous; Gizmos.color = color;
        }
        private static void DrawArc(Vector2 center, float radius, float start, float sweep)
        {
            int count = Mathf.CeilToInt(Mathf.Abs(sweep) / 7.5f);
            Vector3 previous = center + new Vector2(Mathf.Cos(start * Mathf.Deg2Rad), Mathf.Sin(start * Mathf.Deg2Rad)) * radius;
            for (int i = 1; i <= count; i++)
            {
                float angle = (start + sweep * i / count) * Mathf.Deg2Rad;
                Vector3 next = center + new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * radius;
                Gizmos.DrawLine(previous, next); previous = next;
            }
        }
#endif
    }
}



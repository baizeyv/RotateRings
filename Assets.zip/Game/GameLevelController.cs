using System;
using System.Collections.Generic;
using UnityEngine;

namespace WordTile.Game
{
    [DisallowMultipleComponent]
    public sealed class GameLevelController : MonoBehaviour
    {
        public GameLevelData Data;
        public bool LoadOnStart = true;
        public GameShape[] Shapes { get; private set; } = Array.Empty<GameShape>();
        public GameClasp[] Clasps { get; private set; } = Array.Empty<GameClasp>();
        public GameBomb[] Bombs { get; private set; } = Array.Empty<GameBomb>();
        public GameLevelRelations Relations { get; private set; }
        public event Action<GameShape> StateChanged;
        public event Action LevelCompleted;
        public bool IsCompleted { get; private set; }
        private bool[] releaseShapes, releaseClasps;
        private int operatedIndex = -1;
        private readonly Dictionary<int, GameShape> byId = new Dictionary<int, GameShape>();
        private GameObject instanceRoot;
        private bool[] dirtyShapes, dirtyClasps;
        private GameOperationState[] states;
        private int changeDepth;
        private bool loading, flushing;
        private void Start() { if (LoadOnStart && instanceRoot == null && Data != null) Load(Data); }
        private void OnDestroy() { Unload(); }

        public bool TryGetShape(int id, out GameShape shape) { return byId.TryGetValue(id, out shape); }
        public void Load(GameLevelData data)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            data.Validate(); Unload(); Data = data; loading = true;
            try
            {
                instanceRoot = new GameObject("Level Instance"); instanceRoot.SetActive(false); instanceRoot.transform.SetParent(transform, false);
                Shapes = new GameShape[data.Shapes.Length]; Clasps = new GameClasp[data.Clasps.Length]; Bombs = new GameBomb[data.Bombs.Length];
                dirtyShapes = new bool[Shapes.Length]; dirtyClasps = new bool[Clasps.Length]; states = new GameOperationState[Shapes.Length];
                releaseShapes = new bool[Shapes.Length]; releaseClasps = new bool[Clasps.Length];
                for (int i = 0; i < Shapes.Length; i++)
                {
                    var record = data.Shapes[i]; var obj = Element(record.Name, instanceRoot.transform, record.Pose);
                    var shape = obj.AddComponent<GameShape>(); Shapes[i] = shape; shape.Id = record.Id; shape.ShapeType = record.Type;
                    shape.ShapeMesh = record.Mesh; shape.ShapeMaterial = record.Material; shape.CollectionSprite = record.CollectionSprite;
                    shape.CollisionParts = (GameCollisionPart[])record.CollisionParts.Clone(); shape.BodyPartCount = record.BodyPartCount; shape.HeadChannels = (GameHeadChannel[])record.HeadChannels.Clone(); shape.MetadataVersion = 1;
                    shape.Operation = record.Operation; shape.MovementDirection = record.MovementDirection;
                    shape.AllowDrag = record.AllowDrag; shape.BlockMovement = record.BlockMovement; shape.CollisionSkin = record.CollisionSkin;
                    var renderer = obj.GetComponent<MeshRenderer>(); renderer.sortingLayerID = record.SortingLayerId; renderer.sortingOrder = record.SortingOrder;
                    shape.enabled = record.Enabled; shape.Level = this; shape.LevelIndex = i; obj.SetActive(record.Active); byId.Add(shape.Id, shape);
                }
                for (int c = 0; c < Clasps.Length; c++)
                {
                    var record = data.Clasps[c]; var obj = Element(record.Name, instanceRoot.transform, record.Pose);
                    var clasp = obj.AddComponent<GameClasp>(); Clasps[c] = clasp; clasp.Id = record.Id;
                    clasp.ClaspSprite = record.Sprite; clasp.RenderMaterial = record.Material; clasp.Color = record.Color;
                    clasp.Length = record.Length; clasp.Width = record.Width; clasp.ChannelWidth = record.ChannelWidth;
                    clasp.SortingLayer = record.SortingLayer; clasp.SortingOrder = record.SortingOrder;
                    clasp.enabled = record.Enabled; clasp.Level = this; clasp.LevelIndex = c; obj.SetActive(record.Active);
                }
                for (int b = 0; b < Bombs.Length; b++)
                {
                    var record = data.Bombs[b]; var obj = Element(record.Name, byId[record.OwnerShapeId].transform, record.Pose);
                    var bomb = obj.AddComponent<GameBomb>(); Bombs[b] = bomb; bomb.Id = record.Id; bomb.Sprite = record.Sprite;
                    bomb.ImageWidth = record.ImageWidth; bomb.Radius = record.Radius; bomb.CenterOffset = record.CenterOffset; bomb.SortingOffset = record.SortingOffset;
                    bomb.enabled = record.Enabled; bomb.Refresh(); obj.SetActive(record.Active);
                }
                instanceRoot.SetActive(true);
                for (int i = 0; i < Shapes.Length; i++)
                    if (!Shapes[i].Initialize()) throw new ArgumentException("Shape " + Shapes[i].Id + " 无法在当前关卡 Transform 下初始化。");
                for (int c = 0; c < Clasps.Length; c++)
                    if (!Clasps[c].Refresh()) throw new ArgumentException("卡扣 " + Clasps[c].Id + " 初始化失败。");
                for (int i = 0; i < Shapes.Length; i++) Shapes[i].CheckBombContacts();
                Relations = new GameLevelRelations(Shapes, Clasps); Relations.Rebuild();
                Array.Clear(dirtyShapes, 0, dirtyShapes.Length); Array.Clear(dirtyClasps, 0, dirtyClasps.Length);
            }
            catch { Unload(); throw; }
            finally { loading = false; }
            PublishStates();
            CheckCompletion();
        }
        private static GameObject Element(string name, Transform parent, GameElementPose pose)
        {
            var obj = new GameObject(string.IsNullOrEmpty(name) ? "Level Element" : name); obj.SetActive(false);
            obj.transform.SetParent(parent, false); pose.Apply(obj.transform); return obj;
        }
        public void Unload()
        {
            loading = true;
            for (int i = 0; i < Shapes.Length; i++) if (Shapes[i] != null) { Shapes[i].Level = null; Shapes[i].LevelIndex = -1; Shapes[i].SetHeadLocked(false); }
            for (int c = 0; c < Clasps.Length; c++) if (Clasps[c] != null) { Clasps[c].Level = null; Clasps[c].LevelIndex = -1; }
            if (instanceRoot != null)
            {
                instanceRoot.SetActive(false);
                if (Application.isPlaying) Destroy(instanceRoot); else DestroyImmediate(instanceRoot);
            }
            instanceRoot = null; Relations = null; byId.Clear();
            Shapes = Array.Empty<GameShape>(); Clasps = Array.Empty<GameClasp>(); Bombs = Array.Empty<GameBomb>();
            dirtyShapes = dirtyClasps = null; states = null; changeDepth = 0; loading = false;
            releaseShapes = releaseClasps = null; operatedIndex = -1; IsCompleted = false;
        }
        /// <summary>Call before a custom operation to remember dependencies that movement may remove.</summary>
        public void BeginOperation(GameShape shape)
        {
            if (shape == null || Relations == null || shape.Level != this) return;
            Array.Clear(releaseShapes, 0, releaseShapes.Length); Array.Clear(releaseClasps, 0, releaseClasps.Length);
            operatedIndex = shape.LevelIndex; releaseShapes[operatedIndex] = true;
            Relations.MarkNeighbors(operatedIndex, releaseShapes, releaseClasps);
        }
        public void CancelOperation() { operatedIndex = -1; }
        /// <summary>Normal pointer release; only the operated object and its former neighbors are eligible.</summary>
        public void ReleaseShape(GameShape shape)
        {
            if (shape == null || shape.Level != this || Relations == null) return;
            if (operatedIndex != shape.LevelIndex) BeginOperation(shape);
            Relations.MarkNeighbors(shape.LevelIndex, releaseShapes, releaseClasps);
            operatedIndex = -1;
            BeginChanges();
            try
            {
                bool changed;
                do
                {
                    changed = false;
                    for (int i = 0; i < Shapes.Length; i++)
                    {
                        var candidate = Shapes[i];
                        if (!releaseShapes[i] || candidate == null || !candidate.gameObject.activeSelf || Relations.HasDependencies(i)) continue;
                        Relations.MarkNeighbors(i, releaseShapes, releaseClasps);
                        candidate.gameObject.SetActive(false); Relations.UpdateShape(i); changed = true;
                    }
                    for (int c = 0; c < Clasps.Length; c++)
                    {
                        var clasp = Clasps[c];
                        if (!releaseClasps[c] || clasp == null || !clasp.gameObject.activeSelf || Relations.ClaspHasOccupants(c)) continue;
                        clasp.gameObject.SetActive(false); Relations.UpdateClasp(c); changed = true;
                    }
                } while (changed);
            }
            finally { EndChanges(); }
        }
        private void CheckCompletion()
        {
            if (IsCompleted || loading || changeDepth > 0 || instanceRoot == null || !instanceRoot.activeInHierarchy) return;
            for (int i = 0; i < Shapes.Length; i++) if (Shapes[i] != null && Shapes[i].gameObject.activeInHierarchy) return;
            for (int c = 0; c < Clasps.Length; c++) if (Clasps[c] != null && Clasps[c].gameObject.activeInHierarchy) return;
            for (int b = 0; b < Bombs.Length; b++) if (Bombs[b] != null && Bombs[b].gameObject.activeInHierarchy) return;
            IsCompleted = true; Debug.Log("关卡所有物品已消失。", this);
            try { LevelCompleted?.Invoke(); } catch (Exception e) { Debug.LogException(e, this); }
        }
        public void RefreshRelations()
        {
            if (Relations == null || loading) return;
            if (Relations.LayoutChanged()) Relations = new GameLevelRelations(Shapes, Clasps);
            Relations.Rebuild(); Array.Clear(dirtyShapes, 0, dirtyShapes.Length); Array.Clear(dirtyClasps, 0, dirtyClasps.Length);
            if (changeDepth == 0) { PublishStates(); CheckCompletion(); }
        }
        internal void BeginChanges() { changeDepth++; }
        internal void EndChanges() { if (changeDepth > 0) changeDepth--; FlushChanges(); }
        internal void ShapeChanged(int index)
        {
            if (loading || Relations == null || index < 0 || index >= Shapes.Length) return;
            dirtyShapes[index] = true; FlushChanges();
        }
        internal void ClaspChanged(int index)
        {
            if (loading || Relations == null || index < 0 || index >= Clasps.Length) return;
            dirtyClasps[index] = true; FlushChanges();
        }
        private void FlushChanges()
        {
            if (loading || flushing || changeDepth > 0 || Relations == null) return;
            flushing = true;
            try
            {
                bool again;
                do
                {
                    for (int i = 0; i < Shapes.Length; i++) if (dirtyShapes[i])
                    {
                        if (i == operatedIndex) Relations.MarkNeighbors(i, releaseShapes, releaseClasps);
                        dirtyShapes[i] = false; Relations.UpdateShape(i);
                        if (i == operatedIndex) Relations.MarkNeighbors(i, releaseShapes, releaseClasps);
                    }
                    for (int c = 0; c < Clasps.Length; c++) if (dirtyClasps[c]) { dirtyClasps[c] = false; Relations.UpdateClasp(c); }
                    PublishStates(); again = false;
                    for (int i = 0; i < dirtyShapes.Length; i++) again |= dirtyShapes[i];
                    for (int c = 0; c < dirtyClasps.Length; c++) again |= dirtyClasps[c];
                } while (again);
            }
            finally { flushing = false; }
            CheckCompletion();
        }
        private void PublishStates()
        {
            for (int i = 0; i < Shapes.Length; i++) if (Shapes[i] != null)
                Shapes[i].SetHeadLocked(Relations.LockCount(i) > 0);
            for (int i = 0; i < Shapes.Length; i++) if (Shapes[i] != null)
            {
                var state = Relations.State(i); if (states[i] == state) continue; states[i] = state;
                try { StateChanged?.Invoke(Shapes[i]); } catch (Exception e) { Debug.LogException(e, this); }
            }
        }
    }
}

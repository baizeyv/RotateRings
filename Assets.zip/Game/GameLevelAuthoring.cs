using UnityEngine;

namespace WordTile.Game
{
    [DisallowMultipleComponent]
    public sealed class GameLevelAuthoring : MonoBehaviour
    {
        public GameLevelData Output;
        [Tooltip("设计用对象在 Play 时隐藏；用单独的 GameLevelController 加载导出的数据。")]
        public bool DisableAtRuntime = true;
        [HideInInspector] public string AnalysisReport;
        private void Awake() { if (Application.isPlaying && DisableAtRuntime) gameObject.SetActive(false); }
    }
}
